<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../ayudas/pdf_ticket.php';

$pedidoId = (int)($_GET['id'] ?? 0);
if ($pedidoId <= 0) {
    die("ID de ticket no válido.");
}

$database = new Conexion();
$pdo = $database->getConnection();

$sqlPedido = "SELECT p.*, 
                     n.nombre AS negocio_nombre, n.ubicacion AS negocio_ubicacion, n.telefono_contacto AS negocio_tel,
                     c.nombre_cliente, c.nombre_perfil, c.telefono_whatsapp
              FROM pedidos p
              INNER JOIN negocios n ON p.negocio_id = n.id_negocios
              LEFT JOIN clientes c ON p.cliente_id = c.id_clientes
              WHERE p.id_pedidos = :id LIMIT 1";
$stmt = $pdo->prepare($sqlPedido);
$stmt->execute([':id' => $pedidoId]);
$pedido = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$pedido) {
    die("Ticket #$pedidoId no encontrado.");
}

$sqlDetalles = "SELECT dp.*, pr.nombre AS producto_nombre
                FROM detalles_pedido dp
                INNER JOIN productos pr ON dp.producto_id = pr.id_productos
                WHERE dp.pedido_id = :id";
$stmtDet = $pdo->prepare($sqlDetalles);
$stmtDet->execute([':id' => $pedidoId]);
$detalles = $stmtDet->fetchAll(PDO::FETCH_ASSOC);

$clienteNombre = $pedido['nombre_cliente'] ?: ($pedido['nombre_perfil'] ?: 'Cliente Mostrador');
$esWhatsapp = !empty($pedido['telefono_whatsapp']) || (!empty($pedido['notas']) && (
    stripos($pedido['notas'], 'Cita') !== false ||
    stripos($pedido['notas'], 'domicilio') !== false ||
    stripos($pedido['notas'], 'Recoger en tienda') !== false
));
$canal = $esWhatsapp ? 'Chatbot WhatsApp' : 'Punto de Venta';
$folioTexto = '#' . str_pad($pedidoId, 5, '0', STR_PAD_LEFT);
$fechaTexto = $pedido['fecha_pedido'] ?? date('d/m/Y H:i');

// Si se solicita ?formato=pdf, generar y entregar el archivo PDF nativo
if (($_GET['formato'] ?? '') === 'pdf') {
    $pdf = new TicketPDF();
    $pdf->agregarLinea(mb_strtoupper($pedido['negocio_nombre'], 'UTF-8'), true, true, 11);
    $pdf->agregarLinea($pedido['negocio_ubicacion'], false, true, 8);
    $pdf->agregarLinea('Tel: ' . $pedido['negocio_tel'], false, true, 8);
    $pdf->agregarSeparador();

    $pdf->agregarLinea('Folio:   ' . $folioTexto, true);
    $pdf->agregarLinea('Fecha:   ' . $fechaTexto);
    $pdf->agregarLinea('Canal:   ' . $canal);
    $pdf->agregarLinea('Cliente: ' . $clienteNombre);
    if (!empty($pedido['telefono_whatsapp'])) {
        $pdf->agregarLinea('WhatsApp: ' . $pedido['telefono_whatsapp']);
    }
    $pdf->agregarLinea('Entrega: ' . ucfirst($pedido['tipo_pedido'] ?? 'tienda'));
    $pdf->agregarLinea('Pago:    ' . ucfirst($pedido['metodo_pago'] ?? 'Efectivo'));
    $pdf->agregarSeparador();

    $sumaProductos = 0;
    foreach ($detalles as $item) {
        $importe = $item['cantidad'] * $item['precio_unitario'];
        $sumaProductos += $importe;
        $pdf->agregarFilaConcepto((int)$item['cantidad'], $item['producto_nombre'], $importe);
    }

    $pdf->agregarSeparador();

    $envio = max(0, (float)$pedido['total'] - $sumaProductos);
    if ($envio > 0) {
        $pdf->agregarFilaTotal('Subtotal:', $sumaProductos, false, 9);
        $pdf->agregarFilaTotal('Envio:', $envio, false, 9);
    }
    $pdf->agregarFilaTotal('TOTAL MXN:', (float)$pedido['total'], true, 11);

    if (!empty($pedido['notas'])) {
        $pdf->agregarSeparador();
        $pdf->agregarLinea('DETALLES / CITA / ENVIO:', true, false, 8);
        $pdf->agregarLinea($pedido['notas'], false, false, 8);
    }

    $pdf->agregarSeparador();
    $pdf->agregarLinea('Gracias por su preferencia!', true, true, 9);
    $pdf->agregarLinea('Changarro Inteligente', false, true, 8);

    $modo = (($_GET['descargar'] ?? '') === '1') ? 'D' : 'I';
    $pdf->salida('Ticket_' . str_pad($pedidoId, 5, '0', STR_PAD_LEFT) . '.pdf', $modo);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ticket <?= $folioTexto ?> · <?= htmlspecialchars($pedido['negocio_nombre']) ?></title>
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            background: #f3f4f6;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 24px 12px;
            margin: 0;
        }
        .ticket {
            width: 320px;
            background: #ffffff;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.1);
            color: #111827;
            font-size: 13px;
            line-height: 1.4;
        }
        .centrado { text-align: center; }
        .linea { border-top: 1px dashed #374151; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 4px 0; vertical-align: top; }
        .der { text-align: right; }
        .total { font-size: 16px; font-weight: bold; }
        .caja-notas {
            background: #f9fafb;
            border-left: 3px solid #111827;
            padding: 7px 9px;
            margin-top: 8px;
            font-size: 12px;
        }
        .acciones {
            margin-top: 16px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }
        .btn {
            padding: 9px 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-family: system-ui, -apple-system, sans-serif;
            font-size: 13.5px;
            font-weight: 700;
            text-decoration: none;
        }
        .btn-pdf { background: #DC2626; color: #ffffff; }
        .btn-imprimir { background: #111827; color: #ffffff; }
        .btn-volver { background: #e5e7eb; color: #111827; }
        @media print {
            body { background: #ffffff; padding: 0; }
            .ticket { box-shadow: none; width: 100%; border-radius: 0; }
            .acciones { display: none; }
        }
    </style>
</head>
<body>

<div class="ticket">
    <div class="centrado">
        <strong style="font-size:15px;"><?= strtoupper(htmlspecialchars($pedido['negocio_nombre'])) ?></strong><br>
        <span><?= htmlspecialchars($pedido['negocio_ubicacion']) ?></span><br>
        <span>Tel: <?= htmlspecialchars($pedido['negocio_tel']) ?></span>
    </div>

    <div class="linea"></div>

    <div>
        <strong>Folio:</strong> <?= $folioTexto ?><br>
        <strong>Fecha:</strong> <?= htmlspecialchars($fechaTexto) ?><br>
        <strong>Canal:</strong> <?= $canal ?><br>
        <strong>Cliente:</strong> <?= htmlspecialchars($clienteNombre) ?><br>
        <?php if (!empty($pedido['telefono_whatsapp'])): ?>
            <strong>WhatsApp:</strong> <?= htmlspecialchars($pedido['telefono_whatsapp']) ?><br>
        <?php endif; ?>
        <strong>Entrega:</strong> <?= ucfirst(htmlspecialchars($pedido['tipo_pedido'] ?? 'tienda')) ?><br>
        <strong>Pago:</strong> <?= ucfirst(htmlspecialchars($pedido['metodo_pago'] ?? 'Efectivo')) ?>
    </div>

    <div class="linea"></div>

    <table>
        <thead>
            <tr>
                <th>Cant</th>
                <th>Concepto</th>
                <th class="der">Importe</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sumaProductos = 0;
            foreach ($detalles as $item):
                $importe = $item['cantidad'] * $item['precio_unitario'];
                $sumaProductos += $importe;
            ?>
            <tr>
                <td><?= (int)$item['cantidad'] ?></td>
                <td><?= htmlspecialchars($item['producto_nombre']) ?></td>
                <td class="der">$<?= number_format($importe, 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="linea"></div>

    <?php
    $envio = max(0, (float)$pedido['total'] - $sumaProductos);
    if ($envio > 0):
    ?>
    <table>
        <tr>
            <td>Subtotal:</td>
            <td class="der">$<?= number_format($sumaProductos, 2) ?></td>
        </tr>
        <tr>
            <td>Costo de envío:</td>
            <td class="der">$<?= number_format($envio, 2) ?></td>
        </tr>
    </table>
    <?php endif; ?>

    <table>
        <tr class="total">
            <td>TOTAL:</td>
            <td class="der">$<?= number_format((float)$pedido['total'], 2) ?> MXN</td>
        </tr>
    </table>

    <?php if (!empty($pedido['notas'])): ?>
        <div class="caja-notas">
            <strong>Notas / Cita / Envío:</strong><br>
            <?= htmlspecialchars($pedido['notas']) ?>
        </div>
    <?php endif; ?>

    <div class="linea"></div>
    <div class="centrado">
        ¡Gracias por su compra!<br>
        <small>Changarro Inteligente</small>
    </div>
</div>

<div class="acciones">
    <a class="btn btn-pdf" href="index.php?accion=ticket&id=<?= $pedidoId ?>&formato=pdf" target="_blank">📄 Abrir / Guardar PDF</a>
    <button class="btn btn-imprimir" onclick="window.print()">🖨️ Imprimir</button>
    <a class="btn btn-volver" href="index.php?accion=ventas">&larr; Volver a Ventas</a>
</div>

</body>
</html>