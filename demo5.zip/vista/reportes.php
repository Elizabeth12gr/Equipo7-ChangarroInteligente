<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes y Exportación · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
        @media print {
            .navbar, .no-print { display: none !important; }
            body { background: #fff !important; }
            .wrap { max-width: 100%; padding: 0; }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=analisis" class="btn-exit">Demanda</a>
            <a href="index.php?accion=finanzas" class="btn-exit">Finanzas</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <section class="hero">
        <span class="badge">RF-17 y RF-20 · Reportes y Exportación</span>
        <h1>Corte de Ventas (<?= ucfirst(htmlspecialchars($periodo)) ?>)</h1>
        <p>Consulta el resumen operativo de <strong><?= htmlspecialchars($negocio['nombre']) ?></strong> y descárgalo en Excel/CSV o PDF.</p>

        <!-- Selector de periodo (RF-17) y botones de exportación (RF-20) -->
        <div class="no-print" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-top:16px;">
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <a href="index.php?accion=reportes&periodo=diario"
                   class="btn-mini <?= $periodo === 'diario' ? '' : 'btn-edit' ?>">Diario (Hoy)</a>
                <a href="index.php?accion=reportes&periodo=semanal"
                   class="btn-mini <?= $periodo === 'semanal' ? '' : 'btn-edit' ?>">Semanal (7 días)</a>
                <a href="index.php?accion=reportes&periodo=mensual"
                   class="btn-mini <?= $periodo === 'mensual' ? '' : 'btn-edit' ?>">Mensual (Mes actual)</a>
            </div>

            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <a href="index.php?accion=exportar_csv&periodo=<?= urlencode($periodo) ?>" class="btn-mini">
                    Descargar Excel / CSV
                </a>
                <a href="ayudas/reporte_semanal_pdf.php" target="_blank" rel="noopener" class="btn-mini btn-edit">
                    Resumen semanal PDF
                </a>
                <button type="button" onclick="window.print()" class="btn-mini btn-edit">
                    Guardar / Imprimir PDF
                </button>
            </div>
        </div>
    </section>

    <section class="kpis">
        <div class="kpi">
            <span>Total Vendido (<?= ucfirst(htmlspecialchars($periodo)) ?>)</span>
            <strong style="color: var(--primary);">$<?= number_format($totalMonto, 2) ?></strong>
            <small>Excluye operaciones canceladas</small>
        </div>

        <div class="kpi">
            <span>Operaciones Registradas</span>
            <strong><?= $totalOperaciones ?></strong>
            <small>Generado el <?= date('d/m/Y H:i') ?> hrs</small>
        </div>
    </section>

    <section class="list-card">
        <h2 class="sec-title">Detalle de Movimientos (<?= count($ventasPeriodo) ?>)</h2>

        <?php if (empty($ventasPeriodo)): ?>
            <p style="font-size:13.5px; color:var(--muted);">No hay ventas registradas en este periodo.</p>
        <?php else: ?>
            <?php foreach ($ventasPeriodo as $v): ?>
                <?php $est = $v['estado'] ?? 'entregado'; ?>
                <div class="row-item">
                    <div>
                        <strong>
                            Folio #<?= (int)$v['id_pedidos'] ?> — $<?= number_format((float)$v['total'], 2) ?>
                            (<?= htmlspecialchars($v['metodo_pago']) ?>)
                        </strong>
                        <span>
                            <?= !empty($v['fecha_pedido']) ? date('d/m/Y H:i', strtotime($v['fecha_pedido'])) . ' hrs · ' : '' ?>
                            <?= !empty($v['nombre_cliente']) ? 'Cliente: ' . htmlspecialchars($v['nombre_cliente']) : 'Mostrador' ?>
                            <?php if (!empty($v['detalles'])): ?>
                                · <?= (int)$v['detalles'][0]['cantidad'] ?>x <?= htmlspecialchars($v['detalles'][0]['nombre']) ?>
                            <?php endif; ?>
                        </span>
                    </div>
                    <span class="tag-st <?= $est === 'cancelado' ? 'st-warn' : 'st-ok' ?>">
                        <?= ucfirst(htmlspecialchars($est)) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>