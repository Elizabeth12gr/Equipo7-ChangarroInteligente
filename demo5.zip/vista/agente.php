<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agente de WhatsApp · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
        .dias-wrap { display:flex; gap:8px; flex-wrap:wrap; }
        .dias-wrap label { display:flex; align-items:center; gap:5px; font-size:13px; font-weight:600; }
        .chat { display:flex; flex-direction:column; gap:8px; max-height:380px; overflow-y:auto; padding:6px 2px; margin:12px 0; }
        .burbuja { max-width:82%; padding:8px 12px; border-radius:12px; font-size:13.5px; white-space:pre-wrap; word-break:break-word; }
        .b-cliente { background:#fff; border:1px solid #e5e7eb; align-self:flex-start; }
        .b-agente  { background:var(--primary-soft); align-self:flex-end; }
        .b-dueno   { background:#FEF3C7; align-self:flex-end; }
        .burbuja small { display:block; font-size:10.5px; opacity:.6; margin-bottom:2px; }
        .dur-input { width:80px; }
        code.url { display:block; padding:8px 10px; background:#f3f4f6; border-radius:8px; font-size:12.5px; word-break:break-all; }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=agenda" class="btn-exit">Agenda</a>
            <a href="index.php?accion=clientes" class="btn-exit">Clientes</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <!-- CONFIGURACIÓN -->
    <section class="hero">
        <span class="badge">Asistente IA · WhatsApp</span>
        <h1>Agente de WhatsApp</h1>
        <p>Atiende a tus clientes, responde precios y horarios, y agenda <?= $negocio['tipo'] === 'estetica' ? 'citas' : 'entregas' ?> automáticamente en tu Agenda.</p>

        <form method="POST" action="index.php?accion=guardar_agente" style="margin-top:16px;">
            <div class="field">
                <label style="display:flex; align-items:center; gap:8px;">
                    <input type="checkbox" name="agente_activo" value="1" <?= !empty($negocio['agente_activo']) ? 'checked' : '' ?>>
                    <strong>Agente activo</strong> (si lo apagas, los mensajes no se contestan solos)
                </label>
            </div>

            <div class="field">
                <label for="whatsapp_phone_id">Phone number ID (Meta → WhatsApp → API Setup)</label>
                <input type="text" id="whatsapp_phone_id" name="whatsapp_phone_id" class="input-txt" maxlength="30"
                       inputmode="numeric" value="<?= htmlspecialchars($negocio['whatsapp_phone_id'] ?? '') ?>"
                       placeholder="Ej. 123456789012345">
            </div>

            <div class="form-row-2">
                <div class="field">
                    <label for="hora_apertura">Abre</label>
                    <input type="time" id="hora_apertura" name="hora_apertura" class="input-txt" required
                           value="<?= htmlspecialchars(substr($negocio['hora_apertura'], 0, 5)) ?>">
                </div>
                <div class="field">
                    <label for="hora_cierre">Cierra</label>
                    <input type="time" id="hora_cierre" name="hora_cierre" class="input-txt" required
                           value="<?= htmlspecialchars(substr($negocio['hora_cierre'], 0, 5)) ?>">
                </div>
            </div>

            <div class="field">
                <label>Días de atención</label>
                <?php
                    $nombresDias = [1 => 'Lun', 2 => 'Mar', 3 => 'Mié', 4 => 'Jue', 5 => 'Vie', 6 => 'Sáb', 7 => 'Dom'];
                    $diasActivos = array_map('intval', explode(',', $negocio['dias_atencion']));
                ?>
                <div class="dias-wrap">
                    <?php foreach ($nombresDias as $num => $nom): ?>
                        <label><input type="checkbox" name="dias[]" value="<?= $num ?>" <?= in_array($num, $diasActivos, true) ? 'checked' : '' ?>> <?= $nom ?></label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-row-3">
                <div class="field">
                    <label for="capacidad_simultanea">Citas a la vez</label>
                    <input type="number" min="1" max="20" id="capacidad_simultanea" name="capacidad_simultanea" class="input-txt"
                           value="<?= (int)$negocio['capacidad_simultanea'] ?>">
                </div>
                <div class="field">
                    <label for="intervalo_min">Cada (min)</label>
                    <input type="number" min="5" max="240" id="intervalo_min" name="intervalo_min" class="input-txt"
                           value="<?= (int)$negocio['intervalo_min'] ?>">
                </div>
                <div class="field">
                    <label for="anticipacion_min">Anticipación mín. (min)</label>
                    <input type="number" min="0" id="anticipacion_min" name="anticipacion_min" class="input-txt"
                           value="<?= (int)$negocio['anticipacion_min'] ?>">
                </div>
            </div>

            <div class="field">
                <label for="duracion_default_min">Duración por defecto (min) — para productos/entregas sin duración propia</label>
                <input type="number" min="5" max="480" id="duracion_default_min" name="duracion_default_min" class="input-txt"
                       value="<?= (int)$negocio['duracion_default_min'] ?>">
            </div>

            <div class="field">
                <label for="agente_instrucciones">Instrucciones extra para el agente (opcional)</label>
                <textarea id="agente_instrucciones" name="agente_instrucciones" class="input-txt" rows="3" maxlength="1000"
                          placeholder="Ej. Trabajamos solo con cita. No hacemos descuentos. Aceptamos transferencia."><?= htmlspecialchars($negocio['agente_instrucciones'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn-enter" style="background:var(--primary);">Guardar configuración</button>
        </form>

        <p style="font-size:12.5px; margin-top:14px; color:var(--muted);">URL del webhook para pegar en Meta (debe ser HTTPS público):</p>
        <code class="url"><?= htmlspecialchars($webhookUrl) ?></code>
    </section>

    <!-- DURACIÓN POR SERVICIO -->
    <section class="list-card">
        <h2 class="sec-title">Servicios y duración</h2>
        <p style="font-size:13px; color:var(--muted); margin-bottom:10px;">
            Con minutos = <strong>servicio</strong> (ocupa agenda, no descuenta stock). Vacío = <strong>producto</strong> (descuenta stock al agendar).
        </p>
        <?php if (empty($productos)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no tienes productos o servicios. <a href="index.php?accion=productos">Agrégalos aquí</a>.</p>
        <?php else: ?>
            <form method="POST" action="index.php?accion=guardar_duraciones">
                <?php foreach ($productos as $p): ?>
                    <div class="row-item">
                        <div>
                            <strong><?= htmlspecialchars($p['nombre']) ?> — $<?= number_format((float)$p['precio'], 2) ?></strong>
                        </div>
                        <input type="number" min="5" max="480" class="input-txt dur-input"
                               name="duracion[<?= (int)$p['id_productos'] ?>]" placeholder="min"
                               value="<?= $p['duracion_min'] !== null ? (int)$p['duracion_min'] : '' ?>">
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="btn-enter" style="background:var(--primary); margin-top:12px;">Guardar duraciones</button>
            </form>
        <?php endif; ?>
    </section>

    <!-- CONVERSACIONES -->
    <section class="list-card">
        <h2 class="sec-title">Conversaciones recientes</h2>
        <?php if (empty($convs)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Todavía no hay conversaciones.</p>
        <?php else: ?>
            <?php foreach ($convs as $c): ?>
                <div class="row-item">
                    <div>
                        <strong><?= htmlspecialchars($c['nombre_cliente'] ?: 'Cliente') ?> · <?= htmlspecialchars($c['telefono_whatsapp'] ?? $c['wa_id']) ?></strong>
                        <span>
                            <?= date('d/m/Y H:i', strtotime($c['ultimo_mensaje_en'])) ?>
                            <?php if ($c['estado'] === 'humano' && $c['motivo_humano']): ?> · <?= htmlspecialchars($c['motivo_humano']) ?><?php endif; ?>
                        </span>
                    </div>
                    <div class="item-controls">
                        <span class="tag-st <?= $c['estado'] === 'humano' ? 'st-warn' : 'st-ok' ?>">
                            <?= $c['estado'] === 'humano' ? 'Atiende una persona' : 'Atiende el agente' ?>
                        </span>
                        <a class="btn-mini" href="index.php?accion=agente&conv=<?= (int)$c['id_conversaciones'] ?>">Ver</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <?php if ($convSel): ?>
    <section class="list-card" style="border-left:4px solid var(--primary);">
        <h2 class="sec-title">Chat con <?= htmlspecialchars($convSel['nombre_cliente'] ?: 'Cliente') ?></h2>
        <div class="chat">
            <?php foreach ($mensajes as $m): ?>
                <div class="burbuja b-<?= htmlspecialchars($m['rol']) ?>">
                    <small><?= ['cliente' => 'Cliente', 'agente' => 'Agente IA', 'dueno' => 'Tú'][$m['rol']] ?> · <?= date('d/m H:i', strtotime($m['creado_en'])) ?></small>
                    <?= htmlspecialchars($m['contenido']) ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($convSel['estado'] === 'humano'): ?>
            <form method="POST" action="index.php?accion=enviar_mensaje_wa" style="display:flex; gap:8px; margin-bottom:10px;">
                <input type="hidden" name="id_conversaciones" value="<?= (int)$convSel['id_conversaciones'] ?>">
                <input type="text" name="texto" class="input-txt" maxlength="1000" placeholder="Escribe tu respuesta…" required style="flex:1;">
                <button type="submit" class="btn-enter" style="background:var(--primary);">Enviar</button>
            </form>
            <a class="btn-mini" href="index.php?accion=estado_conversacion&id=<?= (int)$convSel['id_conversaciones'] ?>&estado=agente">Devolver al agente</a>
        <?php else: ?>
            <a class="btn-mini" href="index.php?accion=estado_conversacion&id=<?= (int)$convSel['id_conversaciones'] ?>&estado=humano">Tomar yo la conversación</a>
        <?php endif; ?>
    </section>
    <?php endif; ?>
</main>

</body>
</html>
