<?php
require_once __DIR__ . '/../conexion.php';

class Pedido {
    private $conn;
    public $ultimoError = '';

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function crearPedidoCompleto($negocio_id, $cliente_id, $total, $metodo_pago, $lista_productos, $fecha_entrega = null) {
        try {
            $this->conn->beginTransaction();

            $estadoInicial = ($fecha_entrega !== null) ? 'pendiente' : 'entregado';

            $queryPedido = "INSERT INTO pedidos (negocio_id, cliente_id, total, metodo_pago, estado, fecha_entrega) 
                            VALUES (:negocio_id, :cliente_id, :total, :metodo_pago, :estado, :fecha_entrega)";
            $stmtPedido = $this->conn->prepare($queryPedido);
            $stmtPedido->execute([
                ':negocio_id'    => $negocio_id,
                ':cliente_id'    => $cliente_id,
                ':total'         => $total,
                ':metodo_pago'   => $metodo_pago,
                ':estado'        => $estadoInicial,
                ':fecha_entrega' => $fecha_entrega
            ]);

            $pedido_id = $this->conn->lastInsertId();

            $queryDetalle = "INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, precio_unitario) 
                             VALUES (:pedido_id, :producto_id, :cantidad, :precio_unitario)";
            $stmtDetalle = $this->conn->prepare($queryDetalle);

            // Marcadores distintos (:cantidad_restar y :cantidad_min) para evitar SQLSTATE[HY093]
            $queryStock = "UPDATE productos SET stock = stock - :cantidad_restar 
                           WHERE id_productos = :producto_id AND stock >= :cantidad_min";
            $stmtStock = $this->conn->prepare($queryStock);

            foreach ($lista_productos as $item) {
                $stmtDetalle->execute([
                    ':pedido_id'       => $pedido_id,
                    ':producto_id'     => $item['id_producto'],
                    ':cantidad'        => $item['cantidad'],
                    ':precio_unitario' => $item['precio_unitario']
                ]);

                $stmtStock->execute([
                    ':cantidad_restar' => $item['cantidad'],
                    ':producto_id'     => $item['id_producto'],
                    ':cantidad_min'    => $item['cantidad']
                ]);

                if ($stmtStock->rowCount() == 0) {
                    throw new Exception("Stock insuficiente para el producto ID: " . $item['id_producto']);
                }
            }

            $this->conn->commit();
            return $pedido_id;

        } catch (Exception $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->ultimoError = $e->getMessage();
            return false;
        }
    }

    public function obtenerPedido($id_pedidos) {
        $query = "SELECT * FROM pedidos WHERE id_pedidos = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id_pedidos);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPorNegocio($negocio_id) {
        $query = "SELECT p.*, c.nombre_cliente, c.telefono_whatsapp 
                  FROM pedidos p
                  LEFT JOIN clientes c ON p.cliente_id = c.id_clientes
                  WHERE p.negocio_id = :negocio_id 
                  ORDER BY p.id_pedidos DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":negocio_id", $negocio_id);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // RF-17 y RF-20: Filtrar pedidos por periodo ('diario', 'semanal', 'mensual')
    public function obtenerPorPeriodo($negocio_id, $periodo = 'diario') {
        $filtroFecha = "DATE(p.fecha_pedido) = CURDATE()";
        if ($periodo === 'semanal') {
            $filtroFecha = "p.fecha_pedido >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        } elseif ($periodo === 'mensual') {
            $filtroFecha = "YEAR(p.fecha_pedido) = YEAR(CURDATE()) AND MONTH(p.fecha_pedido) = MONTH(CURDATE())";
        }

        try {
            $query = "SELECT p.*, c.nombre_cliente 
                      FROM pedidos p
                      LEFT JOIN clientes c ON p.cliente_id = c.id_clientes
                      WHERE p.negocio_id = :negocio_id AND {$filtroFecha}
                      ORDER BY p.fecha_pedido DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function obtenerAgendados($negocio_id) {
        try {
            $query = "SELECT p.*, c.nombre_cliente, c.telefono_whatsapp 
                      FROM pedidos p
                      LEFT JOIN clientes c ON p.cliente_id = c.id_clientes
                      WHERE p.negocio_id = :negocio_id AND p.fecha_entrega IS NOT NULL
                      ORDER BY p.fecha_entrega ASC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function obtenerRecordatoriosProximos($negocio_id) {
        try {
            $query = "SELECT p.*, c.nombre_cliente, c.telefono_whatsapp 
                      FROM pedidos p
                      LEFT JOIN clientes c ON p.cliente_id = c.id_clientes
                      WHERE p.negocio_id = :negocio_id 
                        AND p.fecha_entrega IS NOT NULL
                        AND p.estado = 'pendiente'
                        AND p.fecha_entrega >= NOW()
                        AND p.fecha_entrega <= DATE_ADD(NOW(), INTERVAL 48 HOUR)
                      ORDER BY p.fecha_entrega ASC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function actualizarFechaEntrega($id_pedidos, $fecha_entrega) {
        try {
            $query = "UPDATE pedidos SET fecha_entrega = :fecha_entrega WHERE id_pedidos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':fecha_entrega', $fecha_entrega);
            $stmt->bindParam(':id', $id_pedidos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function actualizarEstadoPedido($id_pedidos, $nuevo_estado) {
        try {
            $query = "UPDATE pedidos SET estado = :estado WHERE id_pedidos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":estado", $nuevo_estado);
            $stmt->bindParam(":id", $id_pedidos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarPedido($id_pedidos) {
        try {
            $query = "DELETE FROM pedidos WHERE id_pedidos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id_pedidos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function obtenerHorariosPico($negocio_id) {
        try {
            $query = "SELECT HOUR(fecha_pedido) AS hora, COUNT(*) AS total_ventas, SUM(total) AS monto
                      FROM pedidos
                      WHERE negocio_id = :negocio_id
                        AND (estado IS NULL OR estado != 'cancelado')
                      GROUP BY HOUR(fecha_pedido)
                      ORDER BY total_ventas DESC
                      LIMIT 4";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":negocio_id", $negocio_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function obtenerDiasPico($negocio_id) {
        try {
            $query = "SELECT DAYOFWEEK(fecha_pedido) AS dia_num, COUNT(*) AS total_ventas, SUM(total) AS monto
                      FROM pedidos
                      WHERE negocio_id = :negocio_id
                        AND (estado IS NULL OR estado != 'cancelado')
                      GROUP BY DAYOFWEEK(fecha_pedido)
                      ORDER BY monto DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":negocio_id", $negocio_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}
?>