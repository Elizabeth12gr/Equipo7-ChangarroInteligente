<?php
require_once __DIR__ . '/../conexion.php';

class AgenteModelo {
    private $conn;

    public function __construct() {
        $this->conn = (new Conexion())->getConnection();
    }

    public function guardarConfig($id, array $c) {
        try {
            $st = $this->conn->prepare("UPDATE negocios SET agente_activo = :act, whatsapp_phone_id = :pid,
                    hora_apertura = :ap, hora_cierre = :ci, dias_atencion = :dias, capacidad_simultanea = :cap,
                    duracion_default_min = :dur, intervalo_min = :int, anticipacion_min = :ant,
                    agente_instrucciones = :ins WHERE id_negocios = :id");
            return $st->execute([
                ':act' => $c['activo'], ':pid' => $c['phone_id'], ':ap' => $c['apertura'], ':ci' => $c['cierre'],
                ':dias' => $c['dias'], ':cap' => $c['capacidad'], ':dur' => $c['duracion'],
                ':int' => $c['intervalo'], ':ant' => $c['anticipacion'], ':ins' => $c['instrucciones'], ':id' => $id,
            ]);
        } catch (PDOException $e) {
            return false; // p. ej. phone_id duplicado en otro negocio
        }
    }

    public function actualizarDuracion($productoId, $negocioId, $min) {
        $st = $this->conn->prepare("UPDATE productos SET duracion_min = :d WHERE id_productos = :id AND negocio_id = :n");
        return $st->execute([':d' => $min, ':id' => $productoId, ':n' => $negocioId]);
    }

    public function conversaciones($negocioId) {
        $st = $this->conn->prepare("SELECT c.*, cl.nombre_cliente, cl.telefono_whatsapp
                FROM conversaciones c LEFT JOIN clientes cl ON cl.id_clientes = c.cliente_id
                WHERE c.negocio_id = :n ORDER BY (c.estado = 'humano') DESC, c.ultimo_mensaje_en DESC LIMIT 30");
        $st->execute([':n' => $negocioId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public function conversacion($id, $negocioId) {
        $st = $this->conn->prepare("SELECT c.*, cl.nombre_cliente FROM conversaciones c
                LEFT JOIN clientes cl ON cl.id_clientes = c.cliente_id
                WHERE c.id_conversaciones = :id AND c.negocio_id = :n");
        $st->execute([':id' => $id, ':n' => $negocioId]);
        return $st->fetch(PDO::FETCH_ASSOC);
    }

    public function mensajes($convId, $limite = 40) {
        $st = $this->conn->prepare("SELECT * FROM (SELECT * FROM mensajes WHERE conversacion_id = :c
                ORDER BY id_mensajes DESC LIMIT :l) t ORDER BY id_mensajes ASC");
        $st->bindValue(':c', (int)$convId, PDO::PARAM_INT);
        $st->bindValue(':l', (int)$limite, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public function cambiarEstado($convId, $estado) {
        $st = $this->conn->prepare("UPDATE conversaciones SET estado = :e, motivo_humano = IF(:e2 = 'agente', NULL, motivo_humano)
                WHERE id_conversaciones = :id");
        return $st->execute([':e' => $estado, ':e2' => $estado, ':id' => $convId]);
    }

    public function registrarMensajeDueno($convId, $texto) {
        $st = $this->conn->prepare("INSERT INTO mensajes (conversacion_id, rol, contenido) VALUES (:c, 'dueno', :t)");
        return $st->execute([':c' => $convId, ':t' => $texto]);
    }
}
?>
