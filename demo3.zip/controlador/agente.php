<?php
require_once __DIR__ . '/../modelo/agente.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../modelo/productos.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class AgenteController {
    private $agenteModel;
    private $negocioModel;
    private $productoModel;

    public function __construct() {
        $this->agenteModel   = new AgenteModelo();
        $this->negocioModel  = new Negocio();
        $this->productoModel = new Producto();
    }

    private function obtenerContextoNegocio() {
        if (!isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            header('Location: index.php');
            exit;
        }
        $negocio = $this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        return $negocio;
    }

    public function mostrar($error = '', $exito = '') {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];
        $t         = obtenerTemaNegocio($negocio['tipo']);
        $productos = $this->productoModel->obtenerPorNegocio($negocioId);
        $convs     = $this->agenteModel->conversaciones($negocioId);

        $convSel = null;
        $mensajes = [];
        if (isset($_GET['conv'])) {
            $convSel = $this->agenteModel->conversacion((int)$_GET['conv'], $negocioId);
            if ($convSel) {
                $mensajes = $this->agenteModel->mensajes((int)$convSel['id_conversaciones']);
            }
        }

        $esHttps    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        $carpeta    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        $webhookUrl = ($esHttps ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $carpeta . '/webhook_whatsapp.php';

        require __DIR__ . '/../vista/agente.php';
    }

    public function guardarConfig() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $phoneId = preg_replace('/\D/', '', $_POST['whatsapp_phone_id'] ?? '');
        $activo  = isset($_POST['agente_activo']) ? 1 : 0;

        $hhmm = '/^([01]\d|2[0-3]):[0-5]\d$/';
        $ap = trim($_POST['hora_apertura'] ?? '');
        $ci = trim($_POST['hora_cierre'] ?? '');
        if (!preg_match($hhmm, $ap) || !preg_match($hhmm, $ci) || $ap >= $ci) {
            $this->mostrar('Revisa el horario: la hora de apertura debe ser menor a la de cierre.');
            return;
        }

        $dias = [];
        foreach ((array)($_POST['dias'] ?? []) as $d) {
            if (in_array((string)$d, ['1','2','3','4','5','6','7'], true)) $dias[] = (int)$d;
        }
        $dias = array_values(array_unique($dias));
        sort($dias);
        if (empty($dias)) {
            $this->mostrar('Elige al menos un día de atención.');
            return;
        }

        $cap = validarEntero($_POST['capacidad_simultanea'] ?? 1, 1, 20);
        $dur = validarEntero($_POST['duracion_default_min'] ?? 30, 5, 480);
        $int = validarEntero($_POST['intervalo_min'] ?? 30, 5, 240);
        $ant = validarEntero($_POST['anticipacion_min'] ?? 60, 0, 10080);
        if ($cap === null || $dur === null || $int === null || $ant === null) {
            $this->mostrar('Capacidad, duración, intervalo y anticipación deben ser números válidos.');
            return;
        }
        if ($activo && $phoneId === '') {
            $this->mostrar('Para activar el agente captura el "Phone number ID" de tu número de WhatsApp.');
            return;
        }

        $ok = $this->agenteModel->guardarConfig($negocioId, [
            'activo' => $activo, 'phone_id' => $phoneId !== '' ? $phoneId : null,
            'apertura' => $ap . ':00', 'cierre' => $ci . ':00', 'dias' => implode(',', $dias),
            'capacidad' => $cap, 'duracion' => $dur, 'intervalo' => $int, 'anticipacion' => $ant,
            'instrucciones' => limpiarTexto($_POST['agente_instrucciones'] ?? '', 1000) ?: null,
        ]);
        if (!$ok) {
            $this->mostrar('No se pudo guardar. ¿Ese Phone number ID ya está usado por otro negocio?');
            return;
        }
        $this->mostrar('', '¡Configuración del agente guardada!');
    }

    public function guardarDuraciones() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        foreach ((array)($_POST['duracion'] ?? []) as $idProd => $valor) {
            $valor = trim((string)$valor);
            if ($valor === '') {
                $this->agenteModel->actualizarDuracion((int)$idProd, $negocioId, null);
            } else {
                $min = validarEntero($valor, 5, 480);
                if ($min !== null) $this->agenteModel->actualizarDuracion((int)$idProd, $negocioId, $min);
            }
        }
        $this->mostrar('', 'Duraciones actualizadas.');
    }

    public function cambiarEstado() {
        $negocio = $this->obtenerContextoNegocio();
        $conv = $this->agenteModel->conversacion((int)($_GET['id'] ?? 0), (int)$negocio['id_negocios']);
        if ($conv) {
            $nuevo = (($_GET['estado'] ?? '') === 'humano') ? 'humano' : 'agente';
            $this->agenteModel->cambiarEstado((int)$conv['id_conversaciones'], $nuevo);
        }
        header('Location: index.php?accion=agente' . ($conv ? '&conv=' . (int)$conv['id_conversaciones'] : ''));
        exit;
    }

    public function enviarMensaje() {
        $negocio = $this->obtenerContextoNegocio();
        $conv    = $this->agenteModel->conversacion((int)($_POST['id_conversaciones'] ?? 0), (int)$negocio['id_negocios']);
        $texto   = limpiarTexto($_POST['texto'] ?? '', 1000);
        if (!$conv || $texto === '' || empty($negocio['whatsapp_phone_id'])) {
            $this->mostrar('No se pudo enviar el mensaje.');
            return;
        }

        require_once __DIR__ . '/../agente/util.php';
        require_once __DIR__ . '/../agente/WhatsAppClient.php';
        $cfg = require __DIR__ . '/../config_agente.php';
        $enviado = (new WhatsAppClient($cfg))->enviarTexto($negocio['whatsapp_phone_id'], $conv['wa_id'], $texto);

        if (!$enviado) {
            $this->mostrar('WhatsApp rechazó el mensaje (¿pasaron más de 24 h desde el último mensaje del cliente?). Revisa agente/agente.log.');
            return;
        }
        $this->agenteModel->registrarMensajeDueno((int)$conv['id_conversaciones'], $texto);
        $this->agenteModel->cambiarEstado((int)$conv['id_conversaciones'], 'humano');
        header('Location: index.php?accion=agente&conv=' . (int)$conv['id_conversaciones']);
        exit;
    }
}
?>
