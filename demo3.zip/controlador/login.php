<?php
require_once __DIR__ . '/../modelo/dueno.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class AuthController {
    private $duenoModel;
    private $negocioModel;

    public function __construct() {
        $this->duenoModel   = new Dueno();
        $this->negocioModel = new Negocio();
    }

    public function mostrarLogin($error = '', $datos = []) {
        if (isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        require __DIR__ . '/../vista/login.php';
    }

    public function procesarAcceso() {
        $correoRaw = $_POST['correo'] ?? '';
        $passRaw   = $_POST['password'] ?? '';
        $nombre    = limpiarTexto($_POST['nombre'] ?? '', 100);
        $telRaw    = $_POST['telefono'] ?? '';

        $correo = validarCorreo($correoRaw);

        if ($correo === null) {
            $this->mostrarLogin('Ingresa un correo electrónico válido.', $_POST);
            return;
        }
        if (strlen($passRaw) < 6) {
            $this->mostrarLogin('La contraseña debe tener al menos 6 caracteres.', $_POST);
            return;
        }

        $duenoExistente = $this->duenoModel->buscarPorCorreo($correo);

        if ($duenoExistente) {
            if (!password_verify($passRaw, $duenoExistente['password'])) {
                $this->mostrarLogin('Credenciales Incorrectos.', $_POST);
                return;
            }
            $idDueno     = (int)$duenoExistente['id_duenos'];
            $nombreDueno = $duenoExistente['nombre'];
        } else {
            $telefono = validarTelefono($telRaw);

            if (mb_strlen($nombre) < 2) {
                $this->mostrarLogin('Como es tu primera vez, ingresa tu nombre completo.', $_POST);
                return;
            }
            if ($telefono === null) {
                $this->mostrarLogin('Como es tu primera vez, ingresa un teléfono de 10 dígitos.', $_POST);
                return;
            }

            $passwordHash = password_hash($passRaw, PASSWORD_DEFAULT);

            $idDueno = $this->duenoModel->registrarDueno($nombre, $telefono, $correo, $passwordHash);
            if (!$idDueno) {
                $this->mostrarLogin('No se pudo registrar. Verifica que ese teléfono no esté usado con otro correo.', $_POST);
                return;
            }
            $nombreDueno = $nombre;
        }

        $_SESSION['id_duenos']    = $idDueno;
        $_SESSION['dueno_nombre'] = $nombreDueno;

        $negocios = $this->negocioModel->obtenerNegociosPorDueno($idDueno);
        if (!empty($negocios)) {
            $_SESSION['id_negocios'] = (int)$negocios[0]['id_negocios'];
            header('Location: index.php?accion=espacio');
        } else {
            header('Location: index.php?accion=nuevo_negocio');
        }
        exit;
    }

    public function mostrarPerfil($error = '', $exito = '') {
        if (!isset($_SESSION['id_duenos'])) {
            header('Location: index.php');
            exit;
        }
        $dueno = $this->duenoModel->obtenerDueno((int)$_SESSION['id_duenos']);
        if (!$dueno) {
            $this->salir();
        }
        require __DIR__ . '/../vista/perfil_dueno.php';
    }

    public function editarPerfil() {
        if (!isset($_SESSION['id_duenos'])) {
            header('Location: index.php');
            exit;
        }
        $idDueno  = (int)$_SESSION['id_duenos'];
        $nombre   = limpiarTexto($_POST['nombre'] ?? '', 100);
        $telefono = validarTelefono($_POST['telefono'] ?? '');
        $correo   = validarCorreo($_POST['correo'] ?? '');
        $nuevaPass = $_POST['nueva_password'] ?? '';

        if (mb_strlen($nombre) < 2) {
            $this->mostrarPerfil('El nombre debe tener al menos 2 letras.');
            return;
        }
        if ($telefono === null) {
            $this->mostrarPerfil('El teléfono debe tener exactamente 10 dígitos.');
            return;
        }
        if ($correo === null) {
            $this->mostrarPerfil('Ingresa un correo electrónico válido.');
            return;
        }

        $actualizado = $this->duenoModel->actualizarDueno($idDueno, $nombre, $telefono, $correo);
        if (!$actualizado) {
            $this->mostrarPerfil('No se pudo actualizar. Verifica que el correo o teléfono no esté en uso por otra cuenta.');
            return;
        }

        // Si escribió una nueva contraseña, también la actualizamos encriptada
        if ($nuevaPass !== '') {
            if (strlen($nuevaPass) < 6) {
                $this->mostrarPerfil('Datos guardados, pero la nueva contraseña debe tener al menos 6 caracteres.');
                return;
            }
            $this->duenoModel->actualizarPassword($idDueno, password_hash($nuevaPass, PASSWORD_DEFAULT));
        }

        $_SESSION['dueno_nombre'] = $nombre;
        $this->mostrarPerfil('', '¡Tus datos de perfil se actualizaron correctamente!');
    }

    public function eliminarCuenta() {
        if (!isset($_SESSION['id_duenos'])) {
            header('Location: index.php');
            exit;
        }
        $idDueno = (int)$_SESSION['id_duenos'];

        // Intentamos eliminar; si tiene negocios activos, MySQL protege la llave foránea
        $eliminado = $this->duenoModel->eliminarDueno($idDueno);
        if (!$eliminado) {
            $this->mostrarPerfil('No puedes eliminar tu cuenta mientras tengas negocios activos. Elimina primero tus locales desde Configuración.');
            return;
        }

        $this->salir();
    }

    public function salir() {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
?>