<?php
require_once __DIR__ . '/../modelo/pedido.php';
require_once __DIR__ . '/../modelo/detalle_pedido.php';
require_once __DIR__ . '/../modelo/productos.php';
require_once __DIR__ . '/../modelo/cliente.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class PedidoController {
    private $pedidoModel;
    private $detalleModel;
    private $productoModel;
    private $clienteModel;
    private $negocioModel;

    public function __construct() {
        $this->pedidoModel   = new Pedido();
        $this->detalleModel  = new DetallePedido();
        $this->productoModel = new Producto();
        $this->clienteModel  = new Cliente();
        $this->negocioModel  = new Negocio();
    }

    private function obtenerContextoNegocio() {
        if (!isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            header('Location: index.php');
            exit;
        }
        $negocio = $this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        return $negocio;
    }

    public function mostrarVentas($error = '', $exito = '') {
        $negocio     = $this->obtenerContextoNegocio();
        $negocioId   = (int)$negocio['id_negocios'];
        $t           = obtenerTemaNegocio($negocio['tipo']);
        $productos   = $this->productoModel->obtenerPorNegocio($negocioId);
        $clientes    = $this->clienteModel->obtenerTodos();
        $pedidos     = $this->pedidoModel->obtenerPorNegocio($negocioId);
        $masVendidos = $this->detalleModel->obtenerMasVendidosPorNegocio($negocioId, 3);

        foreach ($pedidos as &$ped) {
            $ped['detalles'] = $this->detalleModel->obtenerDetallesPorPedido((int)$ped['id_pedidos']);
        }
        unset($ped);

        require __DIR__ . '/../vista/ventas.php';
    }

    public function registrarVenta() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $idProducto   = (int)($_POST['producto_id'] ?? 0);
        $cantidad     = validarEntero($_POST['cantidad'] ?? 1, 1, 10000);
        $metodoPago   = validarOpcion($_POST['metodo_pago'] ?? 'Efectivo', ['Efectivo', 'Transferencia', 'Tarjeta'], 'Efectivo');
        $clienteRaw   = trim($_POST['cliente_id'] ?? '');
        $clienteId    = ($clienteRaw !== '') ? (int)$clienteRaw : null;
        $fechaRaw     = trim($_POST['fecha_entrega'] ?? '');
        $fechaEntrega = ($fechaRaw !== '') ? validarFechaHora($fechaRaw) : null;

        if ($fechaRaw !== '' && $fechaEntrega === null) {
            $this->mostrarVentas('La fecha y hora de entrega no tiene un formato válido.');
            return;
        }
        if ($idProducto <= 0 || $cantidad === null) {
            $this->mostrarVentas('Selecciona un producto y una cantidad válida.');
            return;
        }

        $prod = $this->productoModel->obtenerProducto($idProducto);
        if (!$prod || (int)$prod['negocio_id'] !== $negocioId) {
            $this->mostrarVentas('El producto seleccionado no pertenece a este negocio.');
            return;
        }

        if ((int)$prod['stock'] < $cantidad) {
            $this->mostrarVentas("Stock insuficiente: solo quedan {$prod['stock']} unidades de {$prod['nombre']}.");
            return;
        }

        $precioUnitario = (float)$prod['precio'];
        $totalVenta     = $precioUnitario * $cantidad;

        $listaProductos = [
            [
                'id_producto'     => $idProducto,
                'cantidad'        => $cantidad,
                'precio_unitario' => $precioUnitario
            ]
        ];

        $pedidoId = $this->pedidoModel->crearPedidoCompleto(
            $negocioId,
            $clienteId,
            $totalVenta,
            $metodoPago,
            $listaProductos,
            $fechaEntrega
        );

        if (!$pedidoId) {
            $this->mostrarVentas('No se pudo procesar la venta: ' . $this->pedidoModel->ultimoError);
            return;
        }

        // Redirige directo al ticket con botón de PDF e impresión
        header("Location: index.php?accion=ticket&id=" . (int)$pedidoId);
        exit;
    }

    public function cambiarEstado() {
        $negocio  = $this->obtenerContextoNegocio();
        $idPedido = (int)($_POST['id_pedidos'] ?? 0);
        $estado   = validarOpcion($_POST['estado'] ?? 'entregado', ['pendiente', 'entregado', 'cancelado'], 'entregado');

        $pedido = $this->pedidoModel->obtenerPedido($idPedido);
        if (!$pedido || (int)$pedido['negocio_id'] !== (int)$negocio['id_negocios']) {
            $this->mostrarVentas('El pedido no existe o no pertenece a tu negocio.');
            return;
        }

        $this->pedidoModel->actualizarEstadoPedido($idPedido, $estado);
        $this->mostrarVentas('', "Estado del pedido #{$idPedido} actualizado a '{$estado}'.");
    }

    public function eliminarVenta() {
        $negocio  = $this->obtenerContextoNegocio();
        $idPedido = (int)($_GET['id'] ?? 0);

        $pedido = $this->pedidoModel->obtenerPedido($idPedido);
        if (!$pedido || (int)$pedido['negocio_id'] !== (int)$negocio['id_negocios']) {
            $this->mostrarVentas('No se pudo eliminar el registro.');
            return;
        }

        $this->detalleModel->eliminarDetallesDePedido($idPedido);
        $this->pedidoModel->eliminarPedido($idPedido);

        $this->mostrarVentas('', "Registro #{$idPedido} y su detalle fueron eliminados.");
    }

    public function procesarVozVenta() {
        header('Content-Type: application/json; charset=utf-8');
        if (!isset($_SESSION['id_negocios'])) {
            echo json_encode(['ok' => false, 'mensaje' => 'Sesión no válida.']);
            exit;
        }

        $negocioId = (int)$_SESSION['id_negocios'];
        $comando   = mb_strtolower(trim($_POST['comando'] ?? ''), 'UTF-8');

        $cantidad = 1;
        if (preg_match('/(\d+)/', $comando, $mCant)) {
            $cantidad = max(1, (int)$mCant[1]);
        }

        $metodoPago = 'Efectivo';
        if (str_contains($comando, 'transferencia')) $metodoPago = 'Transferencia';
        if (str_contains($comando, 'tarjeta')) $metodoPago = 'Tarjeta';

        $nombreLimpio = preg_replace('/\b(vendi|vendí|cobrar|venta|de|del|la|el|los|las|piezas|unidades|por|con|en|efectivo|transferencia|tarjeta)\b/u', ' ', $comando);
        $nombreLimpio = preg_replace('/\d+/', '', $nombreLimpio);
        $nombreLimpio = trim(preg_replace('/\s+/', ' ', $nombreLimpio));

        $coincidencias = $this->productoModel->buscarPorNombre($negocioId, $nombreLimpio);

        if (empty($coincidencias)) {
            echo json_encode(['ok' => false, 'mensaje' => "No encontré '{$nombreLimpio}' en tu catálogo."]);
            exit;
        }

        $prod = $coincidencias[0];
        if ((int)$prod['stock'] < $cantidad) {
            echo json_encode(['ok' => false, 'mensaje' => "Stock insuficiente de {$prod['nombre']} (quedan {$prod['stock']})."]);
            exit;
        }

        $total = (float)$prod['precio'] * $cantidad;
        $pedidoId = $this->pedidoModel->crearPedidoCompleto($negocioId, null, $total, $metodoPago, [[
            'id_producto'     => (int)$prod['id_productos'],
            'cantidad'        => $cantidad,
            'precio_unitario' => (float)$prod['precio']
        ]]);

        if (!$pedidoId) {
            echo json_encode(['ok' => false, 'mensaje' => 'Error al guardar la venta por voz.']);
            exit;
        }

        echo json_encode([
            'ok' => true,
            'mensaje' => "¡Venta #{$pedidoId} cobrada! {$cantidad}x {$prod['nombre']} ($" . number_format($total, 2) . ")"
        ]);
        exit;
    }

    public function mostrarAnalisis() {
        $negocio     = $this->obtenerContextoNegocio();
        $negocioId   = (int)$negocio['id_negocios'];
        $t           = obtenerTemaNegocio($negocio['tipo']);
        $masVendidos = $this->detalleModel->obtenerMasVendidosPorNegocio($negocioId, 10);
        $horarios    = $this->pedidoModel->obtenerHorariosPico($negocioId);
        $dias        = $this->pedidoModel->obtenerDiasPico($negocioId);

        $nombresDias = [1 => 'Domingo', 2 => 'Lunes', 3 => 'Martes', 4 => 'Miércoles', 5 => 'Jueves', 6 => 'Viernes', 7 => 'Sábado'];

        require __DIR__ . '/../vista/analisis_ventas.php';
    }

    public function mostrarFinanzas($error = '', $exito = '') {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];
        $t         = obtenerTemaNegocio($negocio['tipo']);

        $productos = $this->productoModel->obtenerPorNegocio($negocioId);
        $balance   = $this->detalleModel->obtenerBalanceFinanciero($negocioId);

        $totalIngresos = 0.0;
        $totalCostos   = 0.0;

        foreach ($balance as &$fila) {
            $ing = (float)$fila['ingresos_producto'];
            $cos = (float)$fila['costos_producto'];
            $fila['utilidad_producto'] = $ing - $cos;

            $totalIngresos += $ing;
            $totalCostos   += $cos;
        }
        unset($fila);

        $utilidadEstimada = $totalIngresos - $totalCostos;
        $margenGlobal     = ($totalIngresos > 0) ? (($utilidadEstimada / $totalIngresos) * 100) : 0;

        require __DIR__ . '/../vista/finanzas.php';
    }

    public function aplicarPrecioSugerido() {
        $negocio     = $this->obtenerContextoNegocio();
        $idProd      = (int)($_POST['producto_id'] ?? 0);
        $nuevoCosto  = validarMonto($_POST['costo'] ?? null, 0.0);
        $nuevoPrecio = validarMonto($_POST['precio_sugerido'] ?? null, 0.01);

        $prod = $this->productoModel->obtenerProducto($idProd);
        if (!$prod || (int)$prod['negocio_id'] !== (int)$negocio['id_negocios']) {
            $this->mostrarFinanzas('Selecciona un producto válido de tu catálogo.');
            return;
        }
        if ($nuevoPrecio === null || $nuevoCosto === null) {
            $this->mostrarFinanzas('El costo y el precio recomendado deben ser válidos.');
            return;
        }

        $this->productoModel->actualizarProducto(
            $idProd,
            $prod['nombre'],
            $prod['descripcion'] ?? '',
            $nuevoPrecio,
            $nuevoCosto,
            $prod['precio_mercado'] ?? null
        );

        $this->mostrarFinanzas('', "¡Precio y costo de '{$prod['nombre']}' actualizados a $" . number_format($nuevoPrecio, 2) . "!");
    }

    public function mostrarAgenda($error = '', $exito = '') {
        $negocio       = $this->obtenerContextoNegocio();
        $negocioId     = (int)$negocio['id_negocios'];
        $t             = obtenerTemaNegocio($negocio['tipo']);
        $productos     = $this->productoModel->obtenerPorNegocio($negocioId);
        $clientes      = $this->clienteModel->obtenerTodos();
        $agendados     = $this->pedidoModel->obtenerAgendados($negocioId);
        $recordatorios = $this->pedidoModel->obtenerRecordatoriosProximos($negocioId);

        foreach ($agendados as &$ag) {
            $ag['detalles'] = $this->detalleModel->obtenerDetallesPorPedido((int)$ag['id_pedidos']);
        }
        unset($ag);

        foreach ($recordatorios as &$rec) {
            $rec['detalles'] = $this->detalleModel->obtenerDetallesPorPedido((int)$rec['id_pedidos']);
        }
        unset($rec);

        require __DIR__ . '/../vista/agenda.php';
    }

    public function guardarAgenda() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $idProducto   = (int)($_POST['producto_id'] ?? 0);
        $cantidad     = validarEntero($_POST['cantidad'] ?? 1, 1, 10000);
        $clienteRaw   = trim($_POST['cliente_id'] ?? '');
        $clienteId    = ($clienteRaw !== '') ? (int)$clienteRaw : null;
        $metodoPago   = validarOpcion($_POST['metodo_pago'] ?? 'Efectivo', ['Efectivo', 'Transferencia', 'Tarjeta'], 'Efectivo');
        $fechaEntrega = validarFechaHora($_POST['fecha_entrega'] ?? '');

        if ($fechaEntrega === null) {
            $this->mostrarAgenda('Selecciona una fecha y hora válida para la cita o entrega.');
            return;
        }
        if ($idProducto <= 0 || $cantidad === null) {
            $this->mostrarAgenda('Selecciona un producto o servicio válido.');
            return;
        }

        $prod = $this->productoModel->obtenerProducto($idProducto);
        if (!$prod || (int)$prod['negocio_id'] !== $negocioId) {
            $this->mostrarAgenda('El artículo no pertenece a este negocio.');
            return;
        }
        if ((int)$prod['stock'] < $cantidad) {
            $this->mostrarAgenda("Stock insuficiente: solo quedan {$prod['stock']} unidades de {$prod['nombre']}.");
            return;
        }

        $total = (float)$prod['precio'] * $cantidad;

        $pedidoId = $this->pedidoModel->crearPedidoCompleto(
            $negocioId,
            $clienteId,
            $total,
            $metodoPago,
            [['id_producto' => $idProducto, 'cantidad' => $cantidad, 'precio_unitario' => (float)$prod['precio']]],
            $fechaEntrega
        );

        if (!$pedidoId) {
            $this->mostrarAgenda('No se pudo agendar: ' . $this->pedidoModel->ultimoError);
            return;
        }

        $this->mostrarAgenda('', "¡Cita / Entrega #{$pedidoId} agendada para el " . date('d/m/Y H:i', strtotime($fechaEntrega)) . "!");
    }

    public function mostrarReportes() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];
        $t         = obtenerTemaNegocio($negocio['tipo']);

        $periodo = validarOpcion($_GET['periodo'] ?? 'diario', ['diario', 'semanal', 'mensual'], 'diario');

        $ventasPeriodo    = $this->pedidoModel->obtenerPorPeriodo($negocioId, $periodo);
        $totalMonto       = 0.0;
        $totalOperaciones = count($ventasPeriodo);

        foreach ($ventasPeriodo as &$v) {
            if (($v['estado'] ?? '') !== 'cancelado') {
                $totalMonto += (float)$v['total'];
            }
            $v['detalles'] = $this->detalleModel->obtenerDetallesPorPedido((int)$v['id_pedidos']);
        }
        unset($v);

        require __DIR__ . '/../vista/reportes.php';
    }

    public function exportarCSV() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $periodo = validarOpcion($_GET['periodo'] ?? 'mensual', ['diario', 'semanal', 'mensual'], 'mensual');

        $ventas        = $this->pedidoModel->obtenerPorPeriodo($negocioId, $periodo);
        $nombreArchivo = 'reporte_' . $periodo . '_' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');

        $salida = fopen('php://output', 'w');
        fprintf($salida, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($salida, ['Folio Venta', 'Fecha', 'Cliente', 'Metodo de Pago', 'Estado', 'Total ($ MXN)']);

        foreach ($ventas as $row) {
            fputcsv($salida, [
                '#' . $row['id_pedidos'],
                $row['fecha_pedido'] ?? '',
                $row['nombre_cliente'] ?: 'Mostrador',
                $row['metodo_pago'],
                $row['estado'] ?? 'entregado',
                number_format((float)$row['total'], 2, '.', '')
            ]);
        }

        fclose($salida);
        exit;
    }
}
?>