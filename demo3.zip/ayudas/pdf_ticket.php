<?php
// ayudas/pdf_ticket.php - Generador nativo de Ticket Térmico en PDF (80mm)

class TicketPDF {
    private $lineas = [];

    private function limpiarTexto($txt) {
        // Convertir UTF-8 a ISO-8859-1 (WinAnsi) para que acentos y ñ se vean bien en PDF nativo
        $txt = str_replace(['—', '–', '•', '·'], ['-', '-', '*', '-'], $txt);
        $conv = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $txt);
        $limpio = ($conv !== false) ? $conv : $txt;
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $limpio);
    }

    public function agregarLinea($texto = '', $negrita = false, $centrado = false, $tamano = 9) {
        // Cortar líneas largas a máximo 38 caracteres para que no se salgan del ticket de 80mm
        $anchoMax = ($tamano >= 11) ? 30 : 38;
        $envuelto = wordwrap($texto, $anchoMax, "\n", true);
        foreach (explode("\n", $envuelto) as $parte) {
            $this->lineas[] = [
                'texto'    => $parte,
                'negrita'  => $negrita,
                'centrado' => $centrado,
                'tamano'   => $tamano
            ];
        }
    }

    public function agregarSeparador() {
        $this->agregarLinea(str_repeat('-', 38), false, true, 9);
    }

    public function agregarFilaConcepto($cant, $nombre, $importe) {
        $izq = $cant . 'x ' . mb_substr($nombre, 0, 21, 'UTF-8');
        $der = '$' . number_format((float)$importe, 2);
        $espacios = max(1, 38 - mb_strlen($izq, 'UTF-8') - mb_strlen($der, 'UTF-8'));
        $this->agregarLinea($izq . str_repeat(' ', $espacios) . $der, false, false, 9);
    }

    public function agregarFilaTotal($etiqueta, $monto, $negrita = true, $tamano = 11) {
        $ancho = ($tamano >= 11) ? 31 : 38;
        $der = '$' . number_format((float)$monto, 2);
        $espacios = max(1, $ancho - mb_strlen($etiqueta, 'UTF-8') - mb_strlen($der, 'UTF-8'));
        $this->agregarLinea($etiqueta . str_repeat(' ', $espacios) . $der, $negrita, false, $tamano);
    }

    public function salida($nombreArchivo = 'ticket.pdf', $modo = 'I') {
        // Ancho ticket térmico 80mm = 226.77 puntos PDF; alto dinámico según renglones
        $anchoPt = 226.77;
        $altoPt  = max(260, 60 + (count($this->lineas) * 14));

        $contenido = "BT\n";
        $y = $altoPt - 24;

        foreach ($this->lineas as $l) {
            $fuente = $l['negrita'] ? '/F2' : '/F1';
            $tam    = $l['tamano'];
            $txtPdf = $this->limpiarTexto($l['texto']);

            $x = 12;
            if ($l['centrado']) {
                $anchoTexto = strlen($l['texto']) * ($tam * 0.6);
                $x = max(10, ($anchoPt - $anchoTexto) / 2);
            }

            $contenido .= sprintf("%s %d Tf\n1 0 0 1 %.2f %.2f Tm\n(%s) Tj\n", $fuente, $tam, $x, $y, $txtPdf);
            $y -= ($tam + 4);
        }
        $contenido .= "ET\n";

        $objetos = [];
        $objetos[] = "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n";
        $objetos[] = "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n";
        $objetos[] = sprintf(
            "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >> endobj\n",
            $anchoPt,
            $altoPt
        );
        $objetos[] = "4 0 obj << /Length " . strlen($contenido) . " >> stream\n" . $contenido . "endstream\nendobj\n";
        $objetos[] = "5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >> endobj\n";
        $objetos[] = "6 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >> endobj\n";

        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objetos as $obj) {
            $offsets[] = strlen($pdf);
            $pdf .= $obj;
        }

        $xrefPos = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objetos) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($objetos); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer << /Size " . (count($objetos) + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xrefPos . "\n%%EOF";

        if (ob_get_length()) {
            ob_end_clean();
        }
        header('Content-Type: application/pdf');
        $disposicion = ($modo === 'D') ? 'attachment' : 'inline';
        header('Content-Disposition: ' . $disposicion . '; filename="' . $nombreArchivo . '"');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    }
}