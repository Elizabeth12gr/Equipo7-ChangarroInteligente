document.addEventListener('DOMContentLoaded', () => {
    // ==========================================
    // 1. MÓDULO DE LOTE (TICKET OCR + VOZ EN CATÁLOGO)
    // ==========================================
    const btnGrabarLote    = document.getElementById('btnGrabarLote');
    const inputTicketOCR   = document.getElementById('inputTicketOCR');
    const previewTicket    = document.getElementById('previewTicket');
    const estadoAsistente  = document.getElementById('estadoAsistente');
    const contenedorLote   = document.getElementById('contenedorLote');
    const cuerpoTablaLote  = document.getElementById('cuerpoTablaLote');
    const totalLoteTexto   = document.getElementById('totalLoteTexto');
    const tituloLote       = document.getElementById('tituloLote');
    const btnAgregarFila   = document.getElementById('btnAgregarFila');
    const btnConfirmarLote = document.getElementById('btnConfirmarLote');
    const ticketPdfArea    = document.getElementById('ticketPdfArea');

    let productosLote = [];
    let accionLote    = 'entrada';

    function renderTablaLote() {
        if (!cuerpoTablaLote) return;
        cuerpoTablaLote.innerHTML = '';
        let total = 0;

        productosLote.forEach((p, idx) => {
            const cant = parseFloat(p.cantidad) || 0;
            const unit = parseFloat(p.precio_unitario) || 0;
            const sub  = cant * unit;
            total += sub;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" class="celda-lote" value="${p.nombre.replace(/"/g, '&quot;')}" data-idx="${idx}" data-campo="nombre"></td>
                <td><input type="number" min="1" class="celda-lote" value="${cant}" data-idx="${idx}" data-campo="cantidad"></td>
                <td><input type="text" class="celda-lote" value="${p.unidad}" data-idx="${idx}" data-campo="unidad"></td>
                <td><input type="number" step="0.01" min="0" class="celda-lote" value="${unit.toFixed(2)}" data-idx="${idx}" data-campo="precio_unitario"></td>
                <td style="font-weight:700;">$${sub.toFixed(2)}</td>
                <td><button type="button" class="btn-mini btn-del" data-quitar="${idx}">X</button></td>
            `;
            cuerpoTablaLote.appendChild(tr);
        });

        if (totalLoteTexto) totalLoteTexto.textContent = '$' + total.toFixed(2);
        if (contenedorLote) contenedorLote.style.display = productosLote.length > 0 ? 'block' : 'none';
    }

    if (cuerpoTablaLote) {
        cuerpoTablaLote.addEventListener('change', (e) => {
            const idx   = e.target.dataset.idx;
            const campo = e.target.dataset.campo;
            if (idx === undefined || !campo) return;

            const val = e.target.value;
            productosLote[idx][campo] = (campo === 'cantidad' || campo === 'precio_unitario')
                ? (parseFloat(val) || 0)
                : val;
            renderTablaLote();
        });

        cuerpoTablaLote.addEventListener('click', (e) => {
            const q = e.target.dataset.quitar;
            if (q === undefined) return;
            productosLote.splice(parseInt(q, 10), 1);
            renderTablaLote();
        });
    }

    if (btnAgregarFila) {
        btnAgregarFila.addEventListener('click', () => {
            productosLote.push({ nombre: 'Nuevo artículo', cantidad: 1, unidad: 'Pieza', precio_unitario: 0 });
            renderTablaLote();
        });
    }

    // Parseo de líneas OCR de ticket real
    function parsearLineasTicket(textoOCR) {
        const lineas = textoOCR.split(/\r?\n/).map(l => l.trim()).filter(l => l.length >= 4);
        const ignorar = /\b(subtotal|sub-total|total|iva|ieps|cambio|efectivo|tarjeta|transferencia|pago|recibido|rfc|folio|ticket|sucursal|caja|cajero|fecha|hora|gracias|cliente|domicilio|colonia|tel|telefono)\b/i;
        const lista = [];

        for (const linea of lineas) {
            if (ignorar.test(linea)) continue;

            const mPrecio = linea.match(/\$?\s*(\d{1,5}[.,]\d{2})\s*$/);
            if (!mPrecio) continue;

            const importe = parseFloat(mPrecio[1].replace(',', '.'));
            if (isNaN(importe) || importe <= 0) continue;

            let resto = linea.slice(0, mPrecio.index).trim();
            let cantidad = 1;
            const mCant = resto.match(/^(\d{1,3})\s*(?:x|pz|pza|pzas|uds?)?\s+(.+)$/i);
            if (mCant) {
                cantidad = Math.max(1, parseInt(mCant[1], 10));
                resto = mCant[2].trim();
            }

            resto = resto.replace(/^\d{6,}\s+/, '').replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ0-9\s./-]/g, '').trim();
            if (resto.length < 3 || !/[a-zA-ZáéíóúÁÉÍÓÚñÑ]{2,}/.test(resto)) continue;

            const nombre = resto.charAt(0).toUpperCase() + resto.slice(1).toLowerCase();
            const costoUnitario = cantidad > 1 ? round2(importe / cantidad) : importe;

            lista.push({
                nombre: nombre.slice(0, 90),
                cantidad,
                unidad: 'Pieza',
                precio_unitario: costoUnitario
            });
        }
        return lista;
    }

    function round2(n) { return Math.round(n * 100) / 100; }

    // Evento Subir / Escanear Ticket
    if (inputTicketOCR) {
        inputTicketOCR.addEventListener('change', async (e) => {
            const archivo = e.target.files[0];
            if (!archivo || !archivo.type.startsWith('image/')) return;

            const reader = new FileReader();
            reader.onload = (ev) => {
                if (previewTicket) {
                    previewTicket.src = ev.target.result;
                    previewTicket.style.display = 'block';
                }
            };
            reader.readAsDataURL(archivo);

            estadoAsistente.textContent = 'Analizando líneas y precios del ticket... espera un momento.';

            try {
                if (typeof Tesseract === 'undefined') throw new Error('Sin OCR');
                const res = await Tesseract.recognize(archivo, 'spa');
                const items = parsearLineasTicket(res.data.text || '');

                accionLote = 'entrada';
                if (items.length > 0) {
                    productosLote = items;
                    tituloLote.textContent = `Entrada desde Ticket (${items.length} artículo(s) detectados)`;
                    estadoAsistente.textContent = 'Ticket leído. Verifica nombres, cantidades o costos en la tabla y confirma.';
                } else {
                    productosLote = [{ nombre: 'Insumo de ticket', cantidad: 1, unidad: 'Pieza', precio_unitario: 0 }];
                    tituloLote.textContent = 'Captura manual desde comprobante';
                    estadoAsistente.textContent = 'Imagen borrosa o sin precios claros. Completa el renglón en la tabla.';
                }
                renderTablaLote();
            } catch (err) {
                estadoAsistente.textContent = 'No se pudo ejecutar OCR automático. Puedes agregar los renglones abajo.';
                productosLote = [{ nombre: '', cantidad: 1, unidad: 'Pieza', precio_unitario: 0 }];
                renderTablaLote();
            }
        });
    }

    // Evento Dictado por Voz en Lote (con precedencia de precios)
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (btnGrabarLote) {
        if (!SpeechRecognition) {
            btnGrabarLote.disabled = true;
            estadoAsistente.textContent = 'Tu navegador no soporta voz. Usa Chrome o Edge.';
        } else {
            const recLote = new SpeechRecognition();
            recLote.lang = 'es-MX';
            recLote.continuous = true;
            recLote.interimResults = true;
            let grabando = false;
            let textoVoz = '';

            btnGrabarLote.addEventListener('click', () => {
                if (!grabando) {
                    textoVoz = '';
                    recLote.start();
                    grabando = true;
                    btnGrabarLote.textContent = 'Detener y Procesar Dictado';
                    btnGrabarLote.style.background = '#B91C1C';
                    estadoAsistente.textContent = 'Escuchando... Ej: "10 cartones de leche 230 pesos y 5 cajas de huevo a 80 cada una"';
                } else {
                    recLote.stop();
                    grabando = false;
                    btnGrabarLote.textContent = 'Iniciar Dictado por Voz';
                    btnGrabarLote.style.background = 'var(--primary)';
                }
            });

            recLote.onresult = (e) => {
                let parcial = '';
                for (let i = e.resultIndex; i < e.results.length; ++i) {
                    e.results[i].isFinal ? (textoVoz += e.results[i][0].transcript + ' ') : (parcial += e.results[i][0].transcript);
                }
                estadoAsistente.textContent = 'Capturando: ' + (textoVoz + parcial);
            };

            recLote.onend = async () => {
                if (grabando || !textoVoz.trim()) return;
                const fd = new FormData();
                fd.append('texto_voz', textoVoz.trim());

                try {
                    const r = await fetch('index.php?accion=procesar_multimodal', { method: 'POST', body: fd });
                    const data = await r.json();
                    if (data.status === 'success' && data.productos?.length) {
                        productosLote = data.productos;
                        accionLote = data.accion || 'entrada';
                        tituloLote.textContent = (accionLote === 'salida' ? 'Salida / Venta dictada' : 'Entrada dictada') + ` (${productosLote.length} renglón(es))`;
                        estadoAsistente.textContent = `Dictado procesado: "${data.transcripcion_original}"`;
                        renderTablaLote();
                    }
                } catch (err) {
                    estadoAsistente.textContent = 'Error al interpretar el dictado.';
                }
            };
        }
    }

    // Confirmar y Guardar en MySQL + Generar Ticket PDF
    if (btnConfirmarLote) {
        btnConfirmarLote.addEventListener('click', async () => {
            if (!productosLote.length) return;
            btnConfirmarLote.disabled = true;
            btnConfirmarLote.textContent = 'Guardando en inventario...';

            try {
                const resp = await fetch('index.php?accion=guardar_lote_inventario', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ accion: accionLote, productos: productosLote })
                });
                const res = await resp.json();

                if (res.ok && res.ticket) {
                    estadoAsistente.textContent = res.mensaje;
                    productosLote = [];
                    contenedorLote.style.display = 'none';

                    // Llenar Comprobante / Ticket PDF
                    document.getElementById('pdfNegocio').textContent = res.ticket.negocio;
                    document.getElementById('pdfTipo').textContent    = res.ticket.tipo;
                    document.getElementById('pdfMeta').textContent    = `Folio: ${res.ticket.folio} · ${res.ticket.fecha} hrs`;
                    document.getElementById('pdfTotal').textContent   = '$' + Number(res.ticket.total).toFixed(2);

                    const contLineas = document.getElementById('pdfLineas');
                    contLineas.innerHTML = '';
                    res.ticket.items.forEach(it => {
                        const row = document.createElement('div');
                        row.style.cssText = 'display:flex; justify-content:space-between; padding:3px 0;';
                        row.innerHTML = `<span>${it.cantidad} ${it.unidad} x ${it.nombre} ($${Number(it.precio_unitario).toFixed(2)})</span><strong>$${Number(it.subtotal).toFixed(2)}</strong>`;
                        contLineas.appendChild(row);
                    });

                    ticketPdfArea.style.display = 'block';
                } else {
                    estadoAsistente.textContent = res.mensaje || 'No se pudo guardar.';
                }
            } catch (err) {
                estadoAsistente.textContent = 'Error de conexión al guardar en la base de datos.';
            } finally {
                btnConfirmarLote.disabled = false;
                btnConfirmarLote.textContent = 'Confirmar y Actualizar Inventario';
            }
        });
    }

    // ==========================================
    // 2. VOZ RÁPIDA EN CAJA (ventas.php)
    // ==========================================
    const btnVozCaja    = document.getElementById('btnVoz');
    const estadoVozCaja = document.getElementById('estadoVoz');

    if (btnVozCaja && SpeechRecognition) {
        const recCaja = new SpeechRecognition();
        recCaja.lang = 'es-MX';
        recCaja.interimResults = false;

        btnVozCaja.addEventListener('click', () => {
            estadoVozCaja.textContent = 'Escuchando venta... di por ejemplo: "Vendí 2 leche en efectivo"';
            recCaja.start();
        });

        recCaja.onresult = async (event) => {
            const texto = event.results[0][0].transcript;
            estadoVozCaja.textContent = `Escuchado: "${texto}" · Registrando...`;

            const fd = new FormData();
            fd.append('comando', texto);

            try {
                const resp = await fetch('index.php?accion=voz_venta', { method: 'POST', body: fd });
                const data = await resp.json();
                estadoVozCaja.textContent = data.mensaje;
                if (data.ok) setTimeout(() => window.location.reload(), 1100);
            } catch (err) {
                estadoVozCaja.textContent = 'Error al procesar venta por voz.';
            }
        };
    }
});