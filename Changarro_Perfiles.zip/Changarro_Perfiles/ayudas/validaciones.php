<?php
// ayudas/validaciones.php

/**
 * Limpia espacios, etiquetas HTML y recorta a la longitud máxima en UTF-8.
 */
function limpiarTexto(string $valor, int $max = 100): string {
    return mb_substr(strip_tags(trim($valor)), 0, $max, 'UTF-8');
}

/**
 * Valida teléfono mexicano de 10 dígitos numéricos (RF-01, RF-11, RF-14, RF-15).
 */
function validarTelefono(string $telefono): ?string {
    $digitos = preg_replace('/\D/', '', $telefono);
    return (strlen($digitos) === 10) ? $digitos : null;
}

/**
 * Valida y normaliza correo electrónico en minúsculas (RF-01, RF-11).
 */
function validarCorreo(string $correo): ?string {
    $correo = mb_strtolower(trim($correo), 'UTF-8');
    if ($correo === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    return mb_substr($correo, 0, 100, 'UTF-8');
}

/**
 * Valida que el giro del negocio sea uno de los soportados (RF-02).
 */
function validarGiro(string $giro): string {
    $permitidos = ['abarrotes', 'estetica', 'plantilla'];
    return in_array($giro, $permitidos, true) ? $giro : 'abarrotes';
}

/**
 * Valida precios, costos y precios de mercado (RF-03, RF-09, RF-10, RF-16).
 * Devuelve float redondeado a 2 decimales o null si es inválido/fuera de rango.
 */
function validarMonto($valor, float $min = 0.0, float $max = 999999.99): ?float {
    if ($valor === null || trim((string)$valor) === '' || !is_numeric($valor)) {
        return null;
    }
    $num = round((float)$valor, 2);
    if ($num < $min || $num > $max) {
        return null;
    }
    return $num;
}

/**
 * Valida cantidades enteras como stock o unidades vendidas (RF-03, RF-04, RF-05).
 */
function validarEntero($valor, int $min = 0, int $max = 100000): ?int {
    if ($valor === null || trim((string)$valor) === '' || filter_var($valor, FILTER_VALIDATE_INT) === false) {
        return null;
    }
    $num = (int)$valor;
    if ($num < $min || $num > $max) {
        return null;
    }
    return $num;
}

/**
 * Convierte y valida un input HTML datetime-local (YYYY-MM-DDTHH:MM) a formato MySQL DATETIME (RF-13, RF-14).
 */
function validarFechaHora(string $fechaInput): ?string {
    $fechaInput = trim($fechaInput);
    if ($fechaInput === '') {
        return null;
    }
    $normalizada = str_replace('T', ' ', $fechaInput);
    if (strlen($normalizada) === 16) {
        $normalizada .= ':00';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $normalizada);
    if (!$dt || $dt->format('Y-m-d H:i:s') !== $normalizada) {
        return null;
    }
    return $normalizada;
}

/**
 * Valida valores contra una lista cerrada (métodos de pago, estados de pedido, periodos de reporte).
 */
function validarOpcion(string $valor, array $permitidos, string $porDefecto): string {
    return in_array($valor, $permitidos, true) ? $valor : $porDefecto;
}

/**
 * Devuelve la paleta de colores y etiquetas según el giro del negocio (RF-02).
 */
function obtenerTemaNegocio(string $tipo): array {
    $temas = [
        'abarrotes' => ['bg' => '#F2F8F4', 'primary' => '#1B5E3A', 'soft' => '#E1F2E8', 'etiqueta' => 'Producto'],
        'estetica'  => ['bg' => '#FDF4F7', 'primary' => '#B83B68', 'soft' => '#FCE7EF', 'etiqueta' => 'Servicio / Insumo'],
        'plantilla' => ['bg' => '#F4F6F8', 'primary' => '#334155', 'soft' => '#E2E8F0', 'etiqueta' => 'Artículo']
    ];
    return $temas[$tipo] ?? $temas['plantilla'];
}
?>