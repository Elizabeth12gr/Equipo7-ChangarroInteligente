<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso · El Changarro Inteligente</title>
    <link rel="stylesheet" href="css/global.css">
</head>
<body class="login-body">

<div class="login-card">
    <h1>Tu negocio, listo</h1>
    <p class="login-sub">Ingresa con tu correo y contraseña. Si eres nuevo, completa tus datos.</p>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?accion=procesar_acceso" novalidate>
        <div class="field">
            <label for="correo">Correo electrónico *</label>
            <input type="email" id="correo" name="correo" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($datos['correo'] ?? '') ?>" placeholder="dueno@negocio.mx" required>
        </div>

        <div class="field">
            <label for="password">Contraseña (mínimo 6 caracteres) *</label>
            <input type="password" id="password" name="password" class="input-txt" minlength="6"
                   placeholder="••••••••" required>
        </div>

        <div class="field">
            <label for="nombre">Tu nombre (solo si es tu primera vez)</label>
            <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($datos['nombre'] ?? '') ?>" placeholder="Ej. Sofía Hernández">
        </div>

        <div class="field">
            <label for="telefono">Teléfono de 10 dígitos (solo si es tu primera vez)</label>
            <input type="tel" id="telefono" name="telefono" class="input-txt" maxlength="10"
                   value="<?= htmlspecialchars($datos['telefono'] ?? '') ?>" placeholder="Ej. 2291234567">
        </div>

        <button type="submit" class="btn-enter">Entrar</button>
    </form>
</div>

</body>
</html>