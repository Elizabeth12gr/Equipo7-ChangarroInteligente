<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
</head>
<body class="login-body">

<div class="login-card" style="max-width: 480px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span class="badge" style="margin:0;">RF-02 · Configuración</span>
        <a href="index.php?accion=espacio" style="font-size:13px; font-weight:700; color:var(--ink); text-decoration:none;">&larr; Volver al espacio</a>
    </div>

    <h1>Ajustes del Local</h1>
    <p class="login-sub">Actualiza la información o cambia el giro para adaptar los módulos.</p>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?accion=editar_negocio">
        <div class="field">
            <label>Giro comercial *</label>
            <div class="giro-grid">
                <label class="giro-opt">
                    <input type="radio" name="tipo" value="abarrotes" <?= $negocio['tipo'] === 'abarrotes' ? 'checked' : '' ?>>
                    <span class="giro-pill">Abarrotes</span>
                </label>
                <label class="giro-opt">
                    <input type="radio" name="tipo" value="estetica" <?= $negocio['tipo'] === 'estetica' ? 'checked' : '' ?>>
                    <span class="giro-pill">Estética</span>
                </label>
            </div>
            <label class="giro-plantilla">
                <input type="radio" name="tipo" value="plantilla" <?= $negocio['tipo'] === 'plantilla' ? 'checked' : '' ?>>
                <span>Otro giro (Plantilla adaptable)</span>
            </label>
        </div>

        <div class="field">
            <label for="nombre">Nombre del local *</label>
            <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($negocio['nombre']) ?>" required>
        </div>

        <div class="field">
            <label for="ubicacion">Ubicación / Colonia</label>
            <input type="text" id="ubicacion" name="ubicacion" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($negocio['ubicacion'] ?? '') ?>">
        </div>

        <div class="giro-grid" style="margin-bottom: 16px;">
            <div>
                <label for="telefono_contacto" class="lbl-small">Tel. del local</label>
                <input type="tel" id="telefono_contacto" name="telefono_contacto" class="input-txt" maxlength="10"
                       value="<?= htmlspecialchars($negocio['telefono_contacto'] ?? '') ?>">
            </div>
            <div>
                <label for="horario" class="lbl-small">Horario</label>
                <input type="text" id="horario" name="horario" class="input-txt" maxlength="100"
                       value="<?= htmlspecialchars($negocio['horario'] ?? '') ?>">
            </div>
        </div>

        <div class="field">
            <label for="mensaje_bienvenida">Mensaje de bienvenida</label>
            <input type="text" id="mensaje_bienvenida" name="mensaje_bienvenida" class="input-txt" maxlength="250"
                   value="<?= htmlspecialchars($negocio['mensaje_bienvenida'] ?? '') ?>">
        </div>

        <button type="submit" class="btn-enter">Guardar cambios</button>
    </form>

    <hr style="border:none; border-top:1px solid var(--border); margin:20px 0 14px;">

    <a href="index.php?accion=eliminar_negocio"
       onclick="return confirm('¿Seguro que deseas eliminar este negocio y todos sus datos?');"
       style="display:block; text-align:center; font-size:13px; font-weight:700; color:#B91C1C; text-decoration:none;">
        Eliminar este negocio
    </a>
</div>

</body>
</html>