<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proveedores y Referencias · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=productos" class="btn-exit">Catálogo</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <!-- RF-16: COMPARATIVA REAL CONTRA PRECIO DE MERCADO -->
    <section class="list-card" style="border-left: 4px solid var(--primary);">
        <span class="badge">RF-16 · Precios de Referencia</span>
        <h2 class="sec-title">Comparativa con Precio de Mercado (<?= count($comparativaMercado) ?>)</h2>

        <?php if (empty($comparativaMercado)): ?>
            <p style="font-size:13.5px; color:var(--muted);">
                Aún no has capturado precios de referencia. Edita un producto en <a href="index.php?accion=productos" style="color:var(--primary); font-weight:700;">Catálogo</a> y llena el campo <strong>Precio mercado ($)</strong> para compararlo aquí.
            </p>
        <?php else: ?>
            <?php foreach ($comparativaMercado as $item): ?>
                <?php
                    $miPrecio      = (float)$item['precio'];
                    $precioMercado = (float)$item['precio_mercado'];
                    $diferencia    = $miPrecio - $precioMercado;
                    $competitivo   = ($miPrecio <= $precioMercado);
                ?>
                <div class="row-item">
                    <div>
                        <strong><?= htmlspecialchars($item['nombre']) ?></strong>
                        <span>
                            Tu precio: <strong>$<?= number_format($miPrecio, 2) ?></strong> ·
                            Referencia mercado: <strong>$<?= number_format($precioMercado, 2) ?></strong>
                        </span>
                    </div>
                    <span class="tag-st <?= $competitivo ? 'st-ok' : 'st-warn' ?>">
                        <?= $competitivo
                            ? 'Competitivo (' . ($diferencia < 0 ? '-$' . number_format(abs($diferencia), 2) : 'Igual') . ')'
                            : '+$' . number_format($diferencia, 2) . ' sobre mercado' ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <!-- RF-15: ALTA DE PROVEEDORES (TABLA: id_proveedores, negocio_id, nombre, telefono) -->
    <section class="hero">
        <span class="badge">RF-15 · Gestión de Proveedores</span>
        <h1>Nuevo Proveedor</h1>
        <p>Guarda tus contactos de surtido para levantar pedidos con un toque.</p>

        <form method="POST" action="index.php?accion=guardar_proveedor" style="margin-top: 16px;">
            <div class="form-row-2">
                <div class="field">
                    <label for="nombre">Nombre del proveedor *</label>
                    <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                           placeholder="<?= $negocio['tipo'] === 'estetica' ? 'Ej. Distribuidora Belleza Centro' : 'Ej. Abarrotera Veracruz / Don Pepe' ?>" required>
                </div>

                <div class="field">
                    <label for="telefono">Teléfono / WhatsApp (10 dígitos)</label>
                    <input type="tel" id="telefono" name="telefono" class="input-txt" maxlength="10" placeholder="Ej. 2299123456">
                </div>
            </div>

            <button type="submit" class="btn-enter" style="background: var(--primary);">Guardar proveedor</button>
        </form>
    </section>

    <!-- DIRECTORIO DE PROVEEDORES -->
    <section class="list-card">
        <h2 class="sec-title">Mis Proveedores (<?= count($proveedores) ?>)</h2>

        <?php if (empty($proveedores)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no tienes proveedores registrados.</p>
        <?php else: ?>
            <?php foreach ($proveedores as $prov): ?>
                <?php
                    $tel = preg_replace('/\D/', '', $prov['telefono'] ?? '');
                    $msg = rawurlencode("Hola {$prov['nombre']}, te contacto de {$negocio['nombre']} para levantar un pedido de resurtido.");
                ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong><?= htmlspecialchars($prov['nombre']) ?></strong>
                        <span><?= !empty($prov['telefono']) ? 'Teléfono: ' . htmlspecialchars($prov['telefono']) : 'Sin teléfono registrado' ?></span>
                    </div>

                    <div class="item-controls">
                        <?php if (strlen($tel) === 10): ?>
                            <a href="https://wa.me/52<?= $tel ?>?text=<?= $msg ?>" target="_blank" rel="noopener" class="btn-mini">Pedir por WhatsApp</a>
                        <?php endif; ?>
                        <a href="index.php?accion=eliminar_proveedor&id=<?= (int)$prov['id_proveedores'] ?>"
                           class="btn-mini btn-del"
                           onclick="return confirm('¿Eliminar este proveedor?');">Eliminar</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>