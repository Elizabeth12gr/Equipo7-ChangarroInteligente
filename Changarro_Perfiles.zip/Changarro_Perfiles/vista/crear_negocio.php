<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Negocio · El Changarro Inteligente</title>
    <link rel="stylesheet" href="css/global.css">
</head>
<body class="login-body">

<div class="login-card" style="max-width: 460px;">
    <h1>Configura tu local</h1>
    <p class="login-sub">Hola <strong><?= htmlspecialchars($_SESSION['dueno_nombre']) ?></strong>, elige tu giro.</p>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?accion=guardar_negocio">
        <div class="field">
            <label>Tipo de negocio *</label>
            <div class="giro-grid">
                <label class="giro-opt">
                    <input type="radio" name="tipo" value="abarrotes" checked>
                    <span class="giro-pill">Abarrotes</span>
                </label>
                <label class="giro-opt">
                    <input type="radio" name="tipo" value="estetica">
                    <span class="giro-pill">Estética</span>
                </label>
            </div>
            <label class="giro-plantilla">
                <input type="radio" name="tipo" value="plantilla">
                <span>Otro giro (Plantilla adaptable)</span>
            </label>
        </div>

        <div class="field">
            <label for="nombre">Nombre del local *</label>
            <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($datos['nombre'] ?? '') ?>" placeholder="Ej. Estética Glam / Abarrotes El Puerto" required>
        </div>

        <div class="field">
            <label for="ubicacion">Ubicación / Colonia</label>
            <input type="text" id="ubicacion" name="ubicacion" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($datos['ubicacion'] ?? '') ?>" placeholder="Ej. Col. Centro, Veracruz">
        </div>

        <div class="giro-grid" style="margin-bottom: 16px;">
            <div>
                <label for="telefono_contacto" class="lbl-small">Tel. del local</label>
                <input type="tel" id="telefono_contacto" name="telefono_contacto" class="input-txt" maxlength="10"
                       value="<?= htmlspecialchars($datos['telefono_contacto'] ?? '') ?>" placeholder="2299876543">
            </div>
            <div>
                <label for="horario" class="lbl-small">Horario</label>
                <input type="text" id="horario" name="horario" class="input-txt" maxlength="100"
                       value="<?= htmlspecialchars($datos['horario'] ?? '') ?>" placeholder="9:00 AM - 8:00 PM">
            </div>
        </div>

        <div class="field">
            <label for="mensaje_bienvenida">Mensaje de bienvenida</label>
            <input type="text" id="mensaje_bienvenida" name="mensaje_bienvenida" class="input-txt" maxlength="250"
                   value="<?= htmlspecialchars($datos['mensaje_bienvenida'] ?? '') ?>" placeholder="Ej. ¡Bienvenido! Pregunta por nuestras promociones">
        </div>

        <button type="submit" class="btn-enter">Guardar y abrir espacio</button>
    </form>
</div>

</body>
</html>