<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo e Inventario · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
        .tabla-lote { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 12px; }
        .tabla-lote th {
            background: var(--primary-soft); color: var(--primary);
            font-size: 11px; text-transform: uppercase; padding: 8px 10px; text-align: left;
        }
        .tabla-lote td { padding: 8px 6px; border-bottom: 1px solid var(--border); }
        .celda-lote {
            width: 100%; padding: 6px 8px; border: 1px solid var(--border);
            border-radius: 6px; font-family: inherit; font-size: 13px;
        }
        .ticket-pdf-box {
            display: none;
            background: #FFF;
            border: 1.5px dashed var(--primary);
            border-radius: 12px;
            padding: 18px;
            margin-top: 14px;
            max-width: 440px;
        }
        @media print {
            body * { visibility: hidden; }
            #ticketPdfArea, #ticketPdfArea * { visibility: visible; }
            #ticketPdfArea {
                position: absolute; left: 0; top: 0; width: 100%; max-width: 100%;
                border: none; box-shadow: none;
            }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=ventas" class="btn-exit">Caja</a>
            <a href="index.php?accion=finanzas" class="btn-exit">Finanzas</a>
            <a href="index.php?accion=proveedores" class="btn-exit">Proveedores</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($alertas)): ?>
        <div class="alert-error" style="border-left: 4px solid #B91C1C;">
            <strong>Alerta de inventario:</strong> Tienes <?= count($alertas) ?>
            <?= count($alertas) === 1 ? 'artículo con existencia baja' : 'artículos con existencias bajas' ?> (5 o menos unidades).
        </div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <?php if (!$productoEditar): ?>
        <!-- ASISTENTE MULTIMODAL: ESCANEO DE TICKET OCR Y DICTADO EN LOTE -->
        <section class="hero">
            <span class="badge">Asistente Inteligente · Ticket y Voz</span>
            <h1>Surtir por Ticket o Voz</h1>
            <p>Sube la foto de un ticket de compra o dicta varios productos seguidos; revisa la tabla y guarda todo junto.</p>

            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                <button type="button" id="btnGrabarLote" class="btn-mini" style="padding:10px 14px; font-size:13px;">
                    Iniciar Dictado por Voz
                </button>
                <label for="inputTicketOCR" class="btn-mini btn-edit" style="padding:10px 14px; font-size:13px; cursor:pointer;">
                    Escanear Ticket / Nota (Foto)
                </label>
                <input type="file" id="inputTicketOCR" accept="image/*" capture="environment" style="display:none;">
            </div>

            <p id="estadoAsistente" style="font-size:12.5px; color:var(--primary); font-weight:600; margin-top:8px;"></p>
            <img id="previewTicket" alt="Vista previa" style="display:none; max-height:130px; border-radius:8px; margin-top:8px; border:1px solid var(--border);">

            <!-- TABLA EDITABLE DE REVISIÓN ANTES DE GUARDAR -->
            <div id="contenedorLote" style="display:none; margin-top:14px; overflow-x:auto;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                    <strong id="tituloLote" style="font-size:14px; color:var(--primary);">Detalle extraído (editable)</strong>
                    <button type="button" id="btnAgregarFila" class="btn-mini btn-edit">+ Agregar renglón</button>
                </div>

                <table class="tabla-lote">
                    <thead>
                        <tr>
                            <th>Producto / Insumo</th>
                            <th style="width:75px;">Cant.</th>
                            <th style="width:95px;">Unidad</th>
                            <th style="width:105px;">Costo Unit. ($)</th>
                            <th style="width:90px;">Subtotal</th>
                            <th style="width:65px;"></th>
                        </tr>
                    </thead>
                    <tbody id="cuerpoTablaLote"></tbody>
                </table>

                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-top:14px;">
                    <div>
                        <span style="font-size:12px; color:var(--muted);">Total del comprobante:</span>
                        <strong id="totalLoteTexto" style="font-size:18px; color:var(--primary); display:block;">$0.00</strong>
                    </div>
                    <button type="button" id="btnConfirmarLote" class="btn-enter" style="background:var(--primary); width:auto; padding:11px 22px;">
                        Confirmar y Actualizar Inventario
                    </button>
                </div>
            </div>

            <!-- COMPROBANTE / TICKET GENERADO PARA GUARDAR COMO PDF -->
            <div id="ticketPdfArea" class="ticket-pdf-box">
                <div style="text-align:center; border-bottom:1px dashed var(--border); padding-bottom:8px; margin-bottom:10px;">
                    <strong id="pdfNegocio" style="font-size:16px; display:block;"></strong>
                    <span id="pdfTipo" style="font-size:12px; color:var(--muted); display:block;"></span>
                    <small id="pdfMeta" style="font-size:11px; color:var(--muted);"></small>
                </div>
                <div id="pdfLineas" style="font-size:12.5px;"></div>
                <div style="border-top:1px dashed var(--border); margin-top:10px; padding-top:8px; display:flex; justify-content:space-between; font-weight:700;">
                    <span>TOTAL:</span>
                    <span id="pdfTotal"></span>
                </div>
                <div class="no-print" style="display:flex; gap:8px; margin-top:12px;">
                    <button type="button" onclick="window.print()" class="btn-mini" style="flex:1; padding:8px;">
                        Guardar Ticket en PDF
                    </button>
                    <button type="button" onclick="window.location.reload()" class="btn-mini btn-edit">
                        Actualizar lista
                    </button>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- FORMULARIO MANUAL INDIVIDUAL (ALTA / EDICIÓN) -->
    <section class="hero">
        <span class="badge"><?= $productoEditar ? 'Editando Registro' : 'Registro Individual' ?></span>
        <h1><?= $productoEditar ? 'Editar: ' . htmlspecialchars($productoEditar['nombre']) : 'Nuevo ' . $t['etiqueta'] ?></h1>
        <p><?= $productoEditar ? 'Modifica el nombre, costo, precio de venta o precio de referencia de mercado.' : 'Registra manualmente un artículo con su costo, precio al público y precio de referencia.' ?></p>

        <?php if ($productoEditar): ?>
            <form method="POST" action="index.php?accion=editar_producto" style="margin-top: 16px;">
                <input type="hidden" name="id_productos" value="<?= (int)$productoEditar['id_productos'] ?>">

                <div class="field">
                    <label for="nombre">Nombre *</label>
                    <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                           value="<?= htmlspecialchars($productoEditar['nombre']) ?>" required>
                </div>

                <div class="form-row-3">
                    <div class="field">
                        <label for="costo">Costo hacer / compra ($) *</label>
                        <input type="number" step="0.01" min="0" id="costo" name="costo" class="input-txt"
                               value="<?= htmlspecialchars($productoEditar['costo'] ?? '0.00') ?>" required>
                    </div>
                    <div class="field">
                        <label for="precio">Tu precio venta ($) *</label>
                        <input type="number" step="0.01" min="0.01" id="precio" name="precio" class="input-txt"
                               value="<?= htmlspecialchars($productoEditar['precio']) ?>" required>
                    </div>
                    <div class="field">
                        <label for="precio_mercado">Precio mercado ($)</label>
                        <input type="number" step="0.01" min="0" id="precio_mercado" name="precio_mercado" class="input-txt"
                               value="<?= htmlspecialchars($productoEditar['precio_mercado'] ?? '') ?>" placeholder="Opcional">
                    </div>
                </div>

                <div class="field">
                    <label for="descripcion">Descripción / Unidad</label>
                    <input type="text" id="descripcion" name="descripcion" class="input-txt" maxlength="200"
                           value="<?= htmlspecialchars($productoEditar['descripcion'] ?? '') ?>">
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn-enter" style="background: var(--primary); flex:1;">Guardar cambios</button>
                    <a href="index.php?accion=productos" class="btn-exit btn-neutral" style="display:flex; align-items:center; padding:0 18px;">Cancelar</a>
                </div>
            </form>
        <?php else: ?>
            <form method="POST" action="index.php?accion=guardar_producto" style="margin-top: 16px;">
                <div class="form-row-2">
                    <div class="field">
                        <label for="nombre">Nombre del <?= strtolower($t['etiqueta']) ?> *</label>
                        <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                               placeholder="<?= $negocio['tipo'] === 'estetica' ? 'Ej. Tinte Rubio 7.1 / Corte Dama' : 'Ej. Leche Entera 1L' ?>" required>
                    </div>

                    <div class="field">
                        <label for="unidad">Unidad de medida *</label>
                        <select id="unidad" name="unidad" class="input-txt">
                            <option value="Pieza">Pieza</option>
                            <option value="Kilo">Kilo (kg)</option>
                            <option value="Litro">Litro (L)</option>
                            <option value="Caja / Paquete">Caja / Paquete</option>
                            <option value="Servicio">Servicio</option>
                        </select>
                    </div>
                </div>

                <div class="form-row-2">
                    <div class="field">
                        <label for="costo">Costo hacer / compra ($) *</label>
                        <input type="number" step="0.01" min="0" id="costo" name="costo" class="input-txt" placeholder="0.00" required>
                    </div>

                    <div class="field">
                        <label for="precio">Tu precio de venta ($) *</label>
                        <input type="number" step="0.01" min="0.01" id="precio" name="precio" class="input-txt" placeholder="0.00" required>
                    </div>
                </div>

                <div class="form-row-2">
                    <div class="field">
                        <label for="precio_mercado">Precio referencia mercado ($)</label>
                        <input type="number" step="0.01" min="0" id="precio_mercado" name="precio_mercado" class="input-txt" placeholder="Ej. Central de abasto / competencia">
                    </div>

                    <div class="field">
                        <label for="stock">Existencia inicial *</label>
                        <input type="number" min="0" id="stock" name="stock" class="input-txt" value="10" required>
                    </div>
                </div>

                <div class="field">
                    <label for="descripcion">Nota adicional (opcional)</label>
                    <input type="text" id="descripcion" name="descripcion" class="input-txt" maxlength="120"
                           placeholder="Ej. Marca o detalle rápido">
                </div>

                <button type="submit" class="btn-enter" style="background: var(--primary);">Guardar en catálogo</button>
            </form>
        <?php endif; ?>
    </section>

    <!-- LISTADO DE INVENTARIO ACTUAL -->
    <section class="list-card">
        <h2 class="sec-title">Inventario Actual (<?= count($productos) ?>)</h2>

        <?php if (empty($productos)): ?>
            <p style="font-size: 13.5px; color: var(--muted);">Aún no hay registros. Agrega tu primer producto o servicio arriba.</p>
        <?php else: ?>
            <?php foreach ($productos as $p): ?>
                <?php
                    $bajoStock    = ((int)$p['stock'] <= 5);
                    $costoItem    = (float)($p['costo'] ?? 0);
                    $precioItem   = (float)$p['precio'];
                    $mercadoItem  = isset($p['precio_mercado']) ? (float)$p['precio_mercado'] : 0;
                    $gananciaUnit = $precioItem - $costoItem;
                ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong><?= htmlspecialchars($p['nombre']) ?> — Venta: $<?= number_format($precioItem, 2) ?></strong>
                        <span>
                            Costo: $<?= number_format($costoItem, 2) ?> ·
                            Ganancia: $<?= number_format($gananciaUnit, 2) ?>
                            <?php if ($mercadoItem > 0): ?>
                                · Ref. Mercado: <strong>$<?= number_format($mercadoItem, 2) ?></strong>
                            <?php endif; ?>
                            <?= !empty($p['descripcion']) ? ' · ' . htmlspecialchars($p['descripcion']) : '' ?>
                        </span>
                    </div>

                    <div class="item-controls">
                        <form method="POST" action="index.php?accion=actualizar_stock" class="stock-form">
                            <input type="hidden" name="id_productos" value="<?= (int)$p['id_productos'] ?>">
                            <span class="tag-st <?= $bajoStock ? 'st-warn' : 'st-ok' ?>">Stock:</span>
                            <input type="number" name="stock" min="0" value="<?= (int)$p['stock'] ?>" class="input-stock" aria-label="Cantidad en stock">
                            <button type="submit" class="btn-mini">OK</button>
                        </form>

                        <a href="index.php?accion=productos&editar=<?= (int)$p['id_productos'] ?>" class="btn-mini btn-edit">Editar</a>
                        <a href="index.php?accion=eliminar_producto&id=<?= (int)$p['id_productos'] ?>"
                           class="btn-mini btn-del"
                           onclick="return confirm('¿Seguro que deseas eliminar este registro?');">Eliminar</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script src="js/asistente_multimodal.js"></script>
</body>
</html>