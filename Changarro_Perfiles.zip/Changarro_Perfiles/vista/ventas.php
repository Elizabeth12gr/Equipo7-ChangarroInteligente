<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caja y Ventas · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=productos" class="btn-exit">Catálogo</a>
            <a href="index.php?accion=reportes" class="btn-exit">Reportes</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <!-- RF-04: REGISTRO RÁPIDO DE VENTA CON DESCUENTO DE INVENTARIO -->
    <section class="hero">
        <span class="badge">RF-04 · Caja Rápida</span>
        <h1>Registrar Venta</h1>
        <p>Al cobrar, el sistema guarda el recibo y descuenta el inventario automáticamente.</p>
        <div style="margin-top:12px;">
            <button type="button" id="btnVoz" data-modo="venta" class="btn-mini" style="padding:9px 14px; font-size:13px;">
                Registrar Venta por Voz (RF-07)
            </button>
            <p id="estadoVoz" style="font-size:12.5px; color:var(--primary); font-weight:600; margin-top:8px;"></p>
        </div>

        <?php if (empty($productos)): ?>
            <p style="margin-top:14px; font-weight:600; color:#B91C1C;">
                Primero agrega al menos un producto o servicio en <a href="index.php?accion=productos" style="color:var(--primary);">tu catálogo</a>.
            </p>
        <?php else: ?>
            <form method="POST" action="index.php?accion=guardar_venta" style="margin-top: 16px;">
                <div class="form-row-2">
                    <div class="field">
                        <label for="producto_id">Producto o Servicio *</label>
                        <select id="producto_id" name="producto_id" class="input-txt" required>
                            <?php foreach ($productos as $prod): ?>
                                <option value="<?= (int)$prod['id_productos'] ?>">
                                    <?= htmlspecialchars($prod['nombre']) ?> — $<?= number_format((float)$prod['precio'], 2) ?> (Disp: <?= (int)$prod['stock'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label for="cantidad">Cantidad *</label>
                        <input type="number" id="cantidad" name="cantidad" class="input-txt" min="1" value="1" required>
                    </div>
                </div>

                <div class="form-row-2">
                    <div class="field">
                        <label for="metodo_pago">Método de pago *</label>
                        <select id="metodo_pago" name="metodo_pago" class="input-txt">
                            <option value="Efectivo">Efectivo</option>
                            <option value="Transferencia">Transferencia</option>
                            <option value="Tarjeta">Tarjeta</option>
                        </select>
                    </div>

                    <div class="field">
                        <label for="cliente_id">Cliente (opcional)</label>
                        <select id="cliente_id" name="cliente_id" class="input-txt">
                            <option value="">Venta en mostrador (General)</option>
                            <?php foreach ($clientes as $cli): ?>
                                <option value="<?= (int)$cli['id_clientes'] ?>">
                                    <?= htmlspecialchars($cli['nombre_cliente']) ?> (<?= htmlspecialchars($cli['telefono_whatsapp']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-enter" style="background: var(--primary);">Cobrar y descontar stock</button>
            </form>
        <?php endif; ?>
    </section>

    <!-- TOP MÁS VENDIDOS (RF-18) -->
    <?php if (!empty($masVendidos)): ?>
        <section class="list-card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                <h2 class="sec-title" style="margin-bottom:0;">Más vendidos (RF-18)</h2>
                <a href="index.php?accion=analisis" style="font-size:13px; font-weight:700; color:var(--primary); text-decoration:none;">
                    Ver análisis completo &rarr;
                </a>
            </div>
            <?php foreach ($masVendidos as $top): ?>
                <div class="row-item">
                    <div>
                        <strong><?= htmlspecialchars($top['nombre']) ?></strong>
                        <span>Total acumulado: $<?= number_format((float)$top['total_dinero'], 2) ?></span>
                    </div>
                    <span class="tag-st st-ok"><?= (int)$top['total_unidades'] ?> vendidos</span>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <!-- HISTORIAL DE VENTAS Y RECIBO DETALLADO -->
    <section class="list-card">
        <h2 class="sec-title">Ventas y Pedidos (<?= count($pedidos) ?>)</h2>

        <?php if (empty($pedidos)): ?>
            <p style="font-size: 13.5px; color: var(--muted);">Aún no hay ventas registradas en este negocio.</p>
        <?php else: ?>
            <?php foreach ($pedidos as $ped): ?>
                <?php $estadoActual = $ped['estado'] ?? 'entregado'; ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong>Venta #<?= (int)$ped['id_pedidos'] ?> — $<?= number_format((float)$ped['total'], 2) ?></strong>
                        <span>
                            Pago: <?= htmlspecialchars($ped['metodo_pago']) ?>
                            <?= !empty($ped['nombre_cliente']) ? ' · Cliente: ' . htmlspecialchars($ped['nombre_cliente']) : ' · Mostrador' ?>
                        </span>
                        <?php if (!empty($ped['detalles'])): ?>
                            <span style="color: var(--primary); font-weight: 600; margin-top: 2px;">
                                <?php
                                $lineas = [];
                                foreach ($ped['detalles'] as $det) {
                                    $lineas[] = (int)$det['cantidad'] . 'x ' . htmlspecialchars($det['nombre']) . ' ($' . number_format((float)$det['precio_unitario'], 2) . ')';
                                }
                                echo implode(' · ', $lineas);
                                ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="item-controls">
                        <form method="POST" action="index.php?accion=estado_venta" class="stock-form">
                            <input type="hidden" name="id_pedidos" value="<?= (int)$ped['id_pedidos'] ?>">
                            <select name="estado" class="input-stock" style="width: auto;">
                                <option value="pendiente" <?= $estadoActual === 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                <option value="entregado" <?= $estadoActual === 'entregado' ? 'selected' : '' ?>>Entregado</option>
                                <option value="cancelado" <?= $estadoActual === 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                            </select>
                            <button type="submit" class="btn-mini">OK</button>
                        </form>

                        <a href="index.php?accion=eliminar_venta&id=<?= (int)$ped['id_pedidos'] ?>"
                           class="btn-mini btn-del"
                           onclick="return confirm('¿Eliminar este registro de venta y su detalle?');">Eliminar</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<script src="js/asistente_multimodal.js"></script>
</body>
</html>