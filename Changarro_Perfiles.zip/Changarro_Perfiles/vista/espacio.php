<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
        .action-link {
            text-decoration: none;
            color: inherit;
            display: block;
            transition: transform 0.15s, border-color 0.2s;
        }
        .action-link:hover {
            border-color: var(--primary);
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user">
            Dueño: <a href="index.php?accion=perfil" style="color:inherit; text-decoration:underline;"><strong><?= htmlspecialchars($negocio['dueno_nombre']) ?></strong></a>
        </span>
        <div class="nav-actions">
            <a href="index.php?accion=agenda" class="btn-exit">Agenda</a>
            <a href="index.php?accion=finanzas" class="btn-exit">Finanzas</a>
            <a href="index.php?accion=clientes" class="btn-exit">Clientes</a>
            <a href="index.php?accion=nuevo_negocio" class="btn-exit">+ Otro negocio</a>
            <a href="index.php?accion=salir" class="btn-exit btn-neutral">Salir</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (count($misNegocios) > 1): ?>
        <div class="switcher-bar">
            <?php foreach ($misNegocios as $itemNeg): ?>
                <a href="index.php?accion=espacio&id=<?= $itemNeg['id_negocios'] ?>"
                   class="sw-chip <?= ($itemNeg['id_negocios'] == $negocio['id_negocios']) ? 'active' : '' ?>">
                    <?= htmlspecialchars($itemNeg['nombre']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <section class="hero">
        <span class="badge"><?= $t['badge'] ?></span>
        <h1><?= htmlspecialchars($negocio['nombre']) ?></h1>
        <p>
            <?= $negocio['ubicacion'] ? htmlspecialchars($negocio['ubicacion']) . ' · ' : '' ?>
            <?= $negocio['horario'] ? 'Horario: ' . htmlspecialchars($negocio['horario']) : 'Espacio listo para operar' ?>
        </p>
        <?php if (!empty($negocio['mensaje_bienvenida'])): ?>
            <p class="welcome-quote">"<?= htmlspecialchars($negocio['mensaje_bienvenida']) ?>"</p>
        <?php endif; ?>
    </section>

    <section class="kpis">
        <?php foreach ($t['kpis'] as $k): ?>
            <div class="kpi">
                <span><?= $k[0] ?></span>
                <strong><?= $k[1] ?></strong>
                <small><?= $k[2] ?></small>
            </div>
        <?php endforeach; ?>
    </section>

    <h2 class="sec-title">Acciones rápidas</h2>
    <section class="actions-grid">
        <?php foreach ($t['acciones'] as $a): ?>
            <a href="<?= $a[3] ?>" class="action-card action-link">
                <span class="action-tag"><?= $a[0] ?></span>
                <h3><?= $a[1] ?></h3>
                <p><?= $a[2] ?></p>
            </a>
        <?php endforeach; ?>
    </section>

    <section class="list-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <h2 class="sec-title" style="margin-bottom:0;">Estado del día (RF-08)</h2>
            <a href="index.php?accion=productos" style="font-size:13px; font-weight:700; color:var(--primary); text-decoration:none;">
                + Agregar producto
            </a>
        </div>

        <?php if (!empty($productosReales)): ?>
            <?php foreach ($productosReales as $prod): ?>
                <?php $esBajo = ((int)$prod['stock'] <= 5); ?>
                <div class="row-item">
                    <div>
                        <strong><?= htmlspecialchars($prod['nombre']) ?> — $<?= number_format((float)$prod['precio'], 2) ?></strong>
                        <span><?= htmlspecialchars($prod['descripcion'] ?? '') ?></span>
                    </div>
                    <span class="tag-st <?= $esBajo ? 'st-warn' : 'st-ok' ?>">
                        <?= $esBajo ? 'Stock bajo: ' : 'Stock: ' ?><?= (int)$prod['stock'] ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <?php foreach ($t['items_demo'] as $item): ?>
                <div class="row-item">
                    <div>
                        <strong><?= $item[0] ?></strong>
                        <span><?= $item[1] ?></span>
                    </div>
                    <span class="tag-st <?= $item[3] ? 'st-warn' : 'st-ok' ?>"><?= $item[2] ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>