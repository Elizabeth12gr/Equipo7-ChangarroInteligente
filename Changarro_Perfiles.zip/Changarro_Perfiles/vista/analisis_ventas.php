<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análisis de Ventas · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=ventas" class="btn-exit">Caja</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <section class="hero">
        <span class="badge">RF-18 · Inteligencia Comercial</span>
        <h1>Análisis de Demanda</h1>
        <p>Descubre qué productos se venden más, en qué horarios tienes más flujo y tus días más fuertes.</p>
    </section>

    <!-- 1. PRODUCTOS DE MAYOR DEMANDA -->
    <section class="list-card">
        <h2 class="sec-title">1. Productos / Servicios Estrella</h2>
        <?php if (empty($masVendidos)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Registra algunas ventas para ver tu ranking automático.</p>
        <?php else: ?>
            <?php foreach ($masVendidos as $idx => $item): ?>
                <div class="row-item">
                    <div>
                        <strong>#<?= $idx + 1 ?> · <?= htmlspecialchars($item['nombre']) ?></strong>
                        <span>Ingreso generado: $<?= number_format((float)$item['total_dinero'], 2) ?></span>
                    </div>
                    <span class="tag-st st-ok"><?= (int)$item['total_unidades'] ?> uds.</span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <!-- 2. HORARIOS DE MAYOR DEMANDA -->
    <section class="list-card">
        <h2 class="sec-title">2. Horarios Pico</h2>
        <?php if (empty($horarios)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no hay suficientes ventas para calcular horarios.</p>
        <?php else: ?>
            <?php foreach ($horarios as $h): ?>
                <?php $horaFmt = str_pad((string)$h['hora'], 2, '0', STR_PAD_LEFT) . ':00 hrs'; ?>
                <div class="row-item">
                    <div>
                        <strong>Franja de las <?= $horaFmt ?></strong>
                        <span>Monto acumulado: $<?= number_format((float)$h['monto'], 2) ?></span>
                    </div>
                    <span class="tag-st st-ok"><?= (int)$h['total_ventas'] ?> ventas</span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <!-- 3. DÍAS DE MAYOR DEMANDA -->
    <section class="list-card">
        <h2 class="sec-title">3. Días de la Semana con Mayor Flujo</h2>
        <?php if (empty($dias)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no hay datos semanales suficientes.</p>
        <?php else: ?>
            <?php foreach ($dias as $d): ?>
                <div class="row-item">
                    <div>
                        <strong><?= $nombresDias[(int)$d['dia_num']] ?? 'Día' ?></strong>
                        <span><?= (int)$d['total_ventas'] ?> operaciones registradas</span>
                    </div>
                    <span class="tag-st st-ok">$<?= number_format((float)$d['monto'], 2) ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>