<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=ventas" class="btn-exit">Caja</a>
            <a href="index.php?accion=agenda" class="btn-exit">Agenda</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <!-- RF-11: ALTA O EDICIÓN DE CLIENTES Y PREFERENCIAS -->
    <section class="hero">
        <span class="badge"><?= $clienteEditar ? 'Editando Cliente' : 'RF-11 · Control de Clientes' ?></span>
        <h1><?= $clienteEditar ? 'Editar: ' . htmlspecialchars($clienteEditar['nombre_cliente']) : 'Nuevo Cliente' ?></h1>
        <p><?= $clienteEditar ? 'Actualiza el nombre o las preferencias autorizadas del cliente.' : 'Guarda su WhatsApp y preferencias para dar seguimiento personalizado.' ?></p>

        <?php if ($clienteEditar): ?>
            <form method="POST" action="index.php?accion=editar_cliente" style="margin-top: 16px;">
                <input type="hidden" name="id_clientes" value="<?= (int)$clienteEditar['id_clientes'] ?>">

                <div class="form-row-2">
                    <div class="field">
                        <label for="nombre_cliente">Nombre del cliente *</label>
                        <input type="text" id="nombre_cliente" name="nombre_cliente" class="input-txt" maxlength="100"
                               value="<?= htmlspecialchars($clienteEditar['nombre_cliente']) ?>" required>
                    </div>
                    <div class="field">
                        <label for="nombre_perfil">Perfil WhatsApp / Preferencias</label>
                        <input type="text" id="nombre_perfil" name="nombre_perfil" class="input-txt" maxlength="100"
                               value="<?= htmlspecialchars($clienteEditar['nombre_perfil'] ?? '') ?>">
                    </div>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn-enter" style="background: var(--primary); flex:1;">Guardar cambios</button>
                    <a href="index.php?accion=clientes" class="btn-exit btn-neutral" style="display:flex; align-items:center; padding:0 18px;">Cancelar</a>
                </div>
            </form>
        <?php else: ?>
            <form method="POST" action="index.php?accion=guardar_cliente" style="margin-top: 16px;">
                <div class="form-row-2">
                    <div class="field">
                        <label for="nombre_cliente">Nombre del cliente *</label>
                        <input type="text" id="nombre_cliente" name="nombre_cliente" class="input-txt" maxlength="100"
                               placeholder="Ej. Laura Méndez" required>
                    </div>

                    <div class="field">
                        <label for="telefono_whatsapp">WhatsApp (10 dígitos) *</label>
                        <input type="tel" id="telefono_whatsapp" name="telefono_whatsapp" class="input-txt" maxlength="10"
                               placeholder="Ej. 2291456789" required>
                    </div>
                </div>

                <div class="field">
                    <label for="nombre_perfil">Alias WhatsApp / Preferencias autorizadas</label>
                    <input type="text" id="nombre_perfil" name="nombre_perfil" class="input-txt" maxlength="100"
                           placeholder="<?= $negocio['tipo'] === 'estetica' ? 'Ej. Tinte 7.1, prefiere citas por la tarde' : 'Ej. Pide a domicilio los viernes' ?>">
                </div>

                <button type="submit" class="btn-enter" style="background: var(--primary);">Registrar cliente</button>
            </form>
        <?php endif; ?>
    </section>

    <!-- DIRECTORIO Y BUSCADOR POR WHATSAPP -->
    <section class="list-card">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
            <h2 class="sec-title" style="margin-bottom:0;">Directorio (<?= count($clientes) ?>)</h2>

            <form method="GET" action="index.php" class="stock-form">
                <input type="hidden" name="accion" value="clientes">
                <input type="tel" name="buscar" maxlength="10" value="<?= htmlspecialchars($_GET['buscar'] ?? '') ?>"
                       placeholder="Buscar WhatsApp..." class="input-stock" style="width: 150px; text-align:left;">
                <button type="submit" class="btn-mini">Buscar</button>
                <?php if (!empty($_GET['buscar'])): ?>
                    <a href="index.php?accion=clientes" class="btn-mini btn-edit">Ver todos</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if (empty($clientes)): ?>
            <p style="font-size: 13.5px; color: var(--muted);">No se encontraron clientes registrados.</p>
        <?php else: ?>
            <?php foreach ($clientes as $cli): ?>
                <?php
                    $tel = preg_replace('/\D/', '', $cli['telefono_whatsapp'] ?? '');
                    $promoBase = !empty($negocio['mensaje_bienvenida'])
                        ? $negocio['mensaje_bienvenida']
                        : "Tenemos promociones y disponibilidad hoy en {$negocio['nombre']}.";
                    $msgPromo = rawurlencode("Hola {$cli['nombre_cliente']}, te saludamos de {$negocio['nombre']}. {$promoBase}");
                ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong><?= htmlspecialchars($cli['nombre_cliente']) ?> — <?= htmlspecialchars($cli['telefono_whatsapp']) ?></strong>
                        <span><?= !empty($cli['nombre_perfil']) ? 'Nota / Perfil: ' . htmlspecialchars($cli['nombre_perfil']) : 'Sin preferencias registradas' ?></span>
                    </div>

                    <div class="item-controls">
                        <?php if (strlen($tel) === 10): ?>
                            <a href="https://wa.me/52<?= $tel ?>?text=<?= $msgPromo ?>" target="_blank" rel="noopener" class="btn-mini">WhatsApp</a>
                        <?php endif; ?>
                        <a href="index.php?accion=clientes&editar=<?= (int)$cli['id_clientes'] ?>" class="btn-mini btn-edit">Editar</a>
                        <a href="index.php?accion=eliminar_cliente&id=<?= (int)$cli['id_clientes'] ?>"
                           class="btn-mini btn-del"
                           onclick="return confirm('¿Eliminar este cliente por privacidad de datos?');">Eliminar</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>