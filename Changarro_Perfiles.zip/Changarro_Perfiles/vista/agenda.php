<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda y Recordatorios · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=ventas" class="btn-exit">Caja</a>
            <a href="index.php?accion=clientes" class="btn-exit">Clientes</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <section class="list-card" style="border-left: 4px solid var(--primary);">
        <span class="badge">RF-14 · Recordatorios y Seguimiento</span>
        <h2 class="sec-title">Próximas citas y entregas (48 hrs)</h2>

        <?php if (empty($recordatorios)): ?>
            <p style="font-size:13.5px; color:var(--muted);">No hay entregas ni citas pendientes en las próximas 48 horas.</p>
        <?php else: ?>
            <?php foreach ($recordatorios as $rec): ?>
                <?php
                    $fechaFmt = date('d/m/Y H:i', strtotime($rec['fecha_entrega']));
                    $tel      = preg_replace('/\D/', '', $rec['telefono_whatsapp'] ?? '');
                    $nomCli   = $rec['nombre_cliente'] ?: 'Cliente';
                    $servicio = !empty($rec['detalles'][0]['nombre']) ? $rec['detalles'][0]['nombre'] : 'tu pedido';
                    $msg      = rawurlencode("Hola {$nomCli}, te recordamos tu cita/entrega de {$servicio} en {$negocio['nombre']} el {$fechaFmt} hrs. ¡Te esperamos!");
                ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong>#<?= (int)$rec['id_pedidos'] ?> · <?= htmlspecialchars($nomCli) ?> — <?= htmlspecialchars($servicio) ?></strong>
                        <span>Fecha programada: <strong><?= $fechaFmt ?> hrs</strong> · Total: $<?= number_format((float)$rec['total'], 2) ?></span>
                    </div>

                    <div class="item-controls">
                        <?php if (strlen($tel) === 10): ?>
                            <a href="https://wa.me/52<?= $tel ?>?text=<?= $msg ?>" target="_blank" rel="noopener" class="btn-mini">
                                Enviar recordatorio
                            </a>
                        <?php else: ?>
                            <span class="tag-st st-warn">Sin teléfono</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <section class="hero">
        <span class="badge">RF-13 · Agenda de Citas y Entregas</span>
        <h1><?= $negocio['tipo'] === 'estetica' ? 'Agendar Cita o Servicio' : 'Agendar Pedido o Entrega' ?></h1>
        <p>Programa la fecha y hora de entrega o atención vinculada a tu catálogo y clientes.</p>

        <?php if (empty($productos)): ?>
            <p style="margin-top:14px; font-weight:600; color:#B91C1C;">
                Agrega primero servicios o productos en <a href="index.php?accion=productos" style="color:var(--primary);">tu catálogo</a>.
            </p>
        <?php else: ?>
            <form method="POST" action="index.php?accion=guardar_agenda" style="margin-top: 16px;">
                <div class="form-row-2">
                    <div class="field">
                        <label for="producto_id"><?= $negocio['tipo'] === 'estetica' ? 'Servicio / Tratamiento *' : 'Producto / Pedido *' ?></label>
                        <select id="producto_id" name="producto_id" class="input-txt" required>
                            <?php foreach ($productos as $prod): ?>
                                <option value="<?= (int)$prod['id_productos'] ?>">
                                    <?= htmlspecialchars($prod['nombre']) ?> — $<?= number_format((float)$prod['precio'], 2) ?> (Disp: <?= (int)$prod['stock'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label for="fecha_entrega">Fecha y hora programada *</label>
                        <input type="datetime-local" id="fecha_entrega" name="fecha_entrega" class="input-txt" required>
                    </div>
                </div>

                <div class="form-row-3">
                    <div class="field">
                        <label for="cliente_id">Cliente (para recordatorio)</label>
                        <select id="cliente_id" name="cliente_id" class="input-txt">
                            <option value="">-- Cliente general --</option>
                            <?php foreach ($clientes as $cli): ?>
                                <option value="<?= (int)$cli['id_clientes'] ?>">
                                    <?= htmlspecialchars($cli['nombre_cliente']) ?> (<?= htmlspecialchars($cli['telefono_whatsapp']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="field">
                        <label for="cantidad">Cantidad *</label>
                        <input type="number" id="cantidad" name="cantidad" class="input-txt" min="1" value="1" required>
                    </div>

                    <div class="field">
                        <label for="metodo_pago">Método de pago *</label>
                        <select id="metodo_pago" name="metodo_pago" class="input-txt">
                            <option value="Efectivo">Efectivo</option>
                            <option value="Transferencia">Transferencia</option>
                            <option value="Tarjeta">Tarjeta</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-enter" style="background: var(--primary);">Agendar cita / entrega</button>
            </form>
        <?php endif; ?>
    </section>

    <section class="list-card">
        <h2 class="sec-title">Agenda Programada (<?= count($agendados) ?>)</h2>

        <?php if (empty($agendados)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no hay citas ni entregas programadas con fecha.</p>
        <?php else: ?>
            <?php foreach ($agendados as $ag): ?>
                <?php
                    $fechaFmt = date('d/m/Y H:i', strtotime($ag['fecha_entrega']));
                    $estado   = $ag['estado'] ?? 'pendiente';
                ?>
                <div class="row-item item-crud">
                    <div class="item-info">
                        <strong><?= $fechaFmt ?> hrs — #<?= (int)$ag['id_pedidos'] ?> ($<?= number_format((float)$ag['total'], 2) ?>)</strong>
                        <span>
                            <?= !empty($ag['nombre_cliente']) ? 'Cliente: ' . htmlspecialchars($ag['nombre_cliente']) : 'Cliente general' ?>
                            <?php if (!empty($ag['detalles'])): ?>
                                · <?= (int)$ag['detalles'][0]['cantidad'] ?>x <?= htmlspecialchars($ag['detalles'][0]['nombre']) ?>
                            <?php endif; ?>
                        </span>
                    </div>

                    <div class="item-controls">
                        <form method="POST" action="index.php?accion=estado_venta" class="stock-form">
                            <input type="hidden" name="id_pedidos" value="<?= (int)$ag['id_pedidos'] ?>">
                            <select name="estado" class="input-stock" style="width: auto;">
                                <option value="pendiente" <?= $estado === 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                <option value="entregado" <?= $estado === 'entregado' ? 'selected' : '' ?>>Completado</option>
                                <option value="cancelado" <?= $estado === 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                            </select>
                            <button type="submit" class="btn-mini">OK</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

</body>
</html>