<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil · El Changarro Inteligente</title>
    <link rel="stylesheet" href="css/global.css">
</head>
<body class="login-body">

<div class="login-card" style="max-width: 440px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span class="badge" style="margin:0;">Cuenta del Dueño</span>
        <a href="index.php?accion=espacio" style="font-size:13px; font-weight:700; color:var(--ink); text-decoration:none;">&larr; Volver al panel</a>
    </div>

    <h1>Mis Datos</h1>
    <p class="login-sub">Actualiza tu información de contacto o cambia tu contraseña.</p>

    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?accion=editar_perfil">
        <div class="field">
            <label for="nombre">Nombre completo *</label>
            <input type="text" id="nombre" name="nombre" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($dueno['nombre']) ?>" required>
        </div>

        <div class="field">
            <label for="telefono">Teléfono (10 dígitos) *</label>
            <input type="tel" id="telefono" name="telefono" class="input-txt" maxlength="10"
                   value="<?= htmlspecialchars($dueno['telefono']) ?>" required>
        </div>

        <div class="field">
            <label for="correo">Correo electrónico *</label>
            <input type="email" id="correo" name="correo" class="input-txt" maxlength="100"
                   value="<?= htmlspecialchars($dueno['correo']) ?>" required>
        </div>

        <div class="field">
            <label for="nueva_password">Nueva contraseña (dejar en blanco para mantener actual)</label>
            <input type="password" id="nueva_password" name="nueva_password" class="input-txt" minlength="6"
                   placeholder="Mínimo 6 caracteres">
        </div>

        <button type="submit" class="btn-enter">Guardar cambios</button>
    </form>

    <hr style="border:none; border-top:1px solid var(--border); margin:20px 0 14px;">

    <a href="index.php?accion=eliminar_cuenta"
       onclick="return confirm('¿Seguro que deseas eliminar permanentemente tu cuenta de dueño?');"
       style="display:block; text-align:center; font-size:13px; font-weight:700; color:#B91C1C; text-decoration:none;">
        Eliminar mi cuenta
    </a>
</div>

</body>
</html>