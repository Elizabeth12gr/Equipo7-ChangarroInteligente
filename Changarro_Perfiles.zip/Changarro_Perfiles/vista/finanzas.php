<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finanzas y Precios · <?= htmlspecialchars($negocio['nombre']) ?></title>
    <link rel="stylesheet" href="css/global.css">
    <style>
        :root {
            --bg: <?= $t['bg'] ?>;
            --primary: <?= $t['primary'] ?>;
            --primary-soft: <?= $t['soft'] ?>;
        }
        .fin-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 12px;
            margin-bottom: 18px;
        }
        @media (min-width: 768px) {
            .fin-grid { grid-template-columns: repeat(3, 1fr); }
        }
        .calc-box {
            background: var(--primary-soft);
            border-radius: 10px;
            padding: 14px 16px;
            margin: 12px 0 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="nav-inner">
        <span class="nav-user"><strong><?= htmlspecialchars($negocio['nombre']) ?></strong></span>
        <div class="nav-actions">
            <a href="index.php?accion=productos" class="btn-exit">Catálogo</a>
            <a href="index.php?accion=ventas" class="btn-exit">Caja</a>
            <a href="index.php?accion=espacio" class="btn-exit btn-neutral">&larr; Panel</a>
        </div>
    </div>
</nav>

<main class="wrap">
    <?php if (!empty($error)): ?>
        <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($exito)): ?>
        <div class="alert-ok"><?= htmlspecialchars($exito) ?></div>
    <?php endif; ?>

    <!-- RF-09: CÁLCULO DE INGRESOS, COSTOS Y UTILIDAD ESTIMADA -->
    <section class="fin-grid">
        <div class="kpi">
            <span>Ingresos Totales</span>
            <strong style="color: #166534;">$<?= number_format($totalIngresos, 2) ?></strong>
            <small>Ventas concretadas en caja</small>
        </div>

        <div class="kpi">
            <span>Costos de Producción / Compra</span>
            <strong style="color: #B91C1C;">$<?= number_format($totalCostos, 2) ?></strong>
            <small>Calculado desde costo unitario</small>
        </div>

        <div class="kpi">
            <span>Utilidad Estimada</span>
            <strong style="color: <?= $utilidadEstimada >= 0 ? 'var(--primary)' : '#B91C1C' ?>;">
                $<?= number_format($utilidadEstimada, 2) ?>
            </strong>
            <small>Margen real: <?= number_format($margenGlobal, 1) ?>%</small>
        </div>
    </section>

    <!-- RF-10: CALCULADORA DE PRECIOS CON MARGEN OBJETIVO -->
    <section class="hero">
        <span class="badge">RF-10 · Cálculo de Precios</span>
        <h1>Recomendador de Precio</h1>
        <p>Selecciona un artículo (carga su costo guardado) o ingresa un costo para calcular el precio ideal.</p>

        <form method="POST" action="index.php?accion=aplicar_precio" style="margin-top: 14px;">
            <div class="field">
                <label for="selectProducto">Producto o servicio del catálogo (opcional para actualizar directo)</label>
                <select id="selectProducto" name="producto_id" class="input-txt">
                    <option value="0" data-costo="100">-- Solo simular cálculo --</option>
                    <?php foreach ($productos as $p): ?>
                        <option value="<?= (int)$p['id_productos'] ?>" data-costo="<?= (float)($p['costo'] ?? 0) ?>">
                            <?= htmlspecialchars($p['nombre']) ?> (Costo actual: $<?= number_format((float)($p['costo'] ?? 0), 2) ?> · Venta: $<?= number_format((float)$p['precio'], 2) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row-2">
                <div class="field">
                    <label for="calcCosto">Costo de hacer / adquirir ($) *</label>
                    <input type="number" step="0.01" min="0" id="calcCosto" name="costo" class="input-txt" value="100.00" required>
                </div>

                <div class="field">
                    <label for="calcMargen">Margen de ganancia objetivo (%) *</label>
                    <input type="number" step="1" min="1" max="500" id="calcMargen" class="input-txt" value="35" required>
                </div>
            </div>

            <input type="hidden" id="precioSugeridoInput" name="precio_sugerido" value="135.00">

            <div class="calc-box">
                <div>
                    <span style="font-size:12px; color:var(--muted); display:block;">Precio de venta recomendado</span>
                    <strong id="resPrecio" style="font-size:24px; color:var(--primary);">$135.00</strong>
                </div>
                <div>
                    <span style="font-size:12px; color:var(--muted); display:block;">Utilidad neta por pieza</span>
                    <strong id="resGanancia" style="font-size:18px; color:var(--ink);">+$35.00</strong>
                </div>
            </div>

            <button type="submit" id="btnAplicarPrecio" class="btn-enter" style="background: var(--primary); display:none;">
                Aplicar este precio al producto seleccionado
            </button>
        </form>
    </section>

    <!-- RF-09: RENTABILIDAD POR PRODUCTO -->
    <section class="list-card">
        <h2 class="sec-title">Rentabilidad por Producto (RF-09)</h2>

        <?php if (empty($balance)): ?>
            <p style="font-size:13.5px; color:var(--muted);">Aún no hay productos registrados.</p>
        <?php else: ?>
            <?php foreach ($balance as $item): ?>
                <?php $utilProd = (float)$item['utilidad_producto']; ?>
                <div class="row-item">
                    <div>
                        <strong><?= htmlspecialchars($item['nombre']) ?> (<?= (int)$item['unidades_vendidas'] ?> vendidos)</strong>
                        <span>
                            Costo unit.: $<?= number_format((float)$item['costo_unitario'], 2) ?> ·
                            Ingresos: $<?= number_format((float)$item['ingresos_producto'], 2) ?> ·
                            Costos: $<?= number_format((float)$item['costos_producto'], 2) ?>
                        </span>
                    </div>
                    <span class="tag-st <?= $utilProd >= 0 ? 'st-ok' : 'st-warn' ?>">
                        Utilidad: $<?= number_format($utilProd, 2) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<script>
    const selectProd  = document.getElementById('selectProducto');
    const inputCosto  = document.getElementById('calcCosto');
    const inputMargen = document.getElementById('calcMargen');
    const resPrecio   = document.getElementById('resPrecio');
    const resGanancia = document.getElementById('resGanancia');
    const hiddenInput = document.getElementById('precioSugeridoInput');
    const btnAplicar  = document.getElementById('btnAplicarPrecio');

    function recalcularPrecio() {
        const costo       = parseFloat(inputCosto.value) || 0;
        const margen      = parseFloat(inputMargen.value) || 0;
        const ganancia    = costo * (margen / 100);
        const precioFinal = costo + ganancia;

        resPrecio.textContent   = '$' + precioFinal.toFixed(2);
        resGanancia.textContent = '+$' + ganancia.toFixed(2);
        hiddenInput.value       = precioFinal.toFixed(2);
    }

    selectProd.addEventListener('change', () => {
        const opt = selectProd.options[selectProd.selectedIndex];
        const costoGuardado = parseFloat(opt.dataset.costo) || 0;
        inputCosto.value = costoGuardado.toFixed(2);
        btnAplicar.style.display = (selectProd.value !== '0') ? 'block' : 'none';
        recalcularPrecio();
    });

    inputCosto.addEventListener('input', recalcularPrecio);
    inputMargen.addEventListener('input', recalcularPrecio);
    recalcularPrecio();
</script>

</body>
</html>