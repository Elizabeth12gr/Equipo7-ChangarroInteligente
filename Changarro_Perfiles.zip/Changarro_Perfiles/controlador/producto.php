<?php
require_once __DIR__ . '/../modelo/productos.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class ProductoController {
    private $productoModel;
    private $negocioModel;

    public function __construct() {
        $this->productoModel = new Producto();
        $this->negocioModel  = new Negocio();
    }

    private function obtenerContextoNegocio() {
        if (!isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            header('Location: index.php');
            exit;
        }
        $negocio = $this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        return $negocio;
    }

    public function mostrarCatalogo($error = '', $exito = '') {
        $negocio   = $this->obtenerContextoNegocio();
        $t         = obtenerTemaNegocio($negocio['tipo']);
        $productos = $this->productoModel->obtenerPorNegocio($negocio['id_negocios']);
        $alertas   = $this->productoModel->obtenerStockBajo($negocio['id_negocios'], 5);

        $productoEditar = null;
        if (isset($_GET['editar'])) {
            $candidato = $this->productoModel->obtenerProducto((int)$_GET['editar']);
            if ($candidato && (int)$candidato['negocio_id'] === (int)$negocio['id_negocios']) {
                $productoEditar = $candidato;
            }
        }

        require __DIR__ . '/../vista/productos.php';
    }

    public function guardarProducto() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $nombre     = limpiarTexto($_POST['nombre'] ?? '', 100);
        $unidad     = limpiarTexto($_POST['unidad'] ?? 'Pieza', 30);
        $costo      = validarMonto($_POST['costo'] ?? 0, 0.0);
        $precio     = validarMonto($_POST['precio'] ?? null, 0.01);
        $mercadoRaw = trim($_POST['precio_mercado'] ?? '');
        $stock      = validarEntero($_POST['stock'] ?? 0, 0);
        $notas      = limpiarTexto($_POST['descripcion'] ?? '', 120);

        $precioMercado = null;
        if ($mercadoRaw !== '') {
            $precioMercado = validarMonto($mercadoRaw, 0.01);
            if ($precioMercado === null) {
                $this->mostrarCatalogo('El precio de mercado debe ser un monto válido mayor a $0.');
                return;
            }
        }

        if (mb_strlen($nombre) < 2) {
            $this->mostrarCatalogo('Escribe el nombre del producto o servicio (mínimo 2 letras).');
            return;
        }
        if ($precio === null) {
            $this->mostrarCatalogo('El precio de venta debe ser mayor a $0.');
            return;
        }
        if ($stock === null || $costo === null) {
            $this->mostrarCatalogo('El costo y la existencia deben ser números válidos no negativos.');
            return;
        }

        // Si el producto/insumo ya existe exactamente con ese nombre en este negocio, sumamos su stock y actualizamos costo/precio
        $existentes = $this->productoModel->buscarPorNombre($negocioId, $nombre);
        foreach ($existentes as $ex) {
            if (mb_strtolower(trim($ex['nombre']), 'UTF-8') === mb_strtolower($nombre, 'UTF-8')) {
                $idEx = (int)$ex['id_productos'];
                $this->productoModel->sumarStock($idEx, $stock);
                $this->productoModel->actualizarProducto(
                    $idEx,
                    $ex['nombre'],
                    $ex['descripcion'] ?? "Unidad: {$unidad}",
                    $precio,
                    $costo > 0 ? $costo : (float)$ex['costo'],
                    $precioMercado ?? ($ex['precio_mercado'] ?? null)
                );
                $this->mostrarCatalogo('', "¡Resurtido aplicado! Se sumaron +{$stock} unidades a '{$ex['nombre']}' en tu inventario.");
                return;
            }
        }

        $descCompleta = "Unidad: {$unidad}";
        if ($notas !== '') {
            $descCompleta .= " · " . $notas;
        }

        $creado = $this->productoModel->registrarProducto($negocioId, $nombre, $descCompleta, $precio, $stock, $costo, $precioMercado);
        if (!$creado) {
            $this->mostrarCatalogo('No se pudo guardar el registro en la base de datos.');
            return;
        }

        $this->mostrarCatalogo('', '¡Registrado correctamente en tu catálogo!');
    }

    public function actualizarProducto() {
        $negocio    = $this->obtenerContextoNegocio();
        $idProd     = (int)($_POST['id_productos'] ?? 0);
        $nombre     = limpiarTexto($_POST['nombre'] ?? '', 100);
        $costo      = validarMonto($_POST['costo'] ?? 0, 0.0);
        $precio     = validarMonto($_POST['precio'] ?? null, 0.01);
        $mercadoRaw = trim($_POST['precio_mercado'] ?? '');
        $desc       = limpiarTexto($_POST['descripcion'] ?? '', 200);

        $precioMercado = null;
        if ($mercadoRaw !== '') {
            $precioMercado = validarMonto($mercadoRaw, 0.01);
            if ($precioMercado === null) {
                $this->mostrarCatalogo('El precio de mercado debe ser un monto válido.');
                return;
            }
        }

        $actual = $this->productoModel->obtenerProducto($idProd);
        if (!$actual || (int)$actual['negocio_id'] !== (int)$negocio['id_negocios']) {
            $this->mostrarCatalogo('El producto no existe o no pertenece a tu negocio.');
            return;
        }
        if (mb_strlen($nombre) < 2 || $precio === null || $costo === null) {
            $this->mostrarCatalogo('Verifica que el nombre, costo y precio sean válidos.');
            return;
        }

        $this->productoModel->actualizarProducto($idProd, $nombre, $desc, $precio, $costo, $precioMercado);
        $this->mostrarCatalogo('', '¡Producto actualizado correctamente!');
    }

    public function actualizarStock() {
        $negocio    = $this->obtenerContextoNegocio();
        $idProd     = (int)($_POST['id_productos'] ?? 0);
        $nuevoStock = validarEntero($_POST['stock'] ?? null, 0);

        $actual = $this->productoModel->obtenerProducto($idProd);
        if (!$actual || (int)$actual['negocio_id'] !== (int)$negocio['id_negocios'] || $nuevoStock === null) {
            $this->mostrarCatalogo('No se pudo actualizar el inventario.');
            return;
        }

        $this->productoModel->actualizarStock($idProd, $nuevoStock);
        $this->mostrarCatalogo('', 'Existencia actualizada.');
    }

    public function eliminarProducto() {
        $negocio = $this->obtenerContextoNegocio();
        $idProd  = (int)($_GET['id'] ?? 0);

        $actual = $this->productoModel->obtenerProducto($idProd);
        if (!$actual || (int)$actual['negocio_id'] !== (int)$negocio['id_negocios']) {
            $this->mostrarCatalogo('No se pudo eliminar el registro.');
            return;
        }

        $this->productoModel->eliminarProducto($idProd);
        $this->mostrarCatalogo('', 'Registro eliminado del catálogo.');
    }

    public function procesarVozInventario() {
        header('Content-Type: application/json; charset=utf-8');
        if (!isset($_SESSION['id_negocios'])) {
            echo json_encode(['ok' => false, 'mensaje' => 'Sesión no válida.']);
            exit;
        }

        $negocioId = (int)$_SESSION['id_negocios'];
        $comando   = mb_strtolower(trim($_POST['comando'] ?? ''), 'UTF-8');

        if ($comando === '') {
            echo json_encode(['ok' => false, 'mensaje' => 'No se recibió texto de voz.']);
            exit;
        }

        $cantidad = 1;
        if (preg_match('/(\d+)/', $comando, $mCant)) {
            $cantidad = max(1, (int)$mCant[1]);
        }

        $precio = 10.00;
        if (preg_match('/(?:a|en|precio)\s*(\d+(?:\.\d+)?)/', $comando, $mPrecio)) {
            $precio = (float)$mPrecio[1];
        }

        $nombreLimpio = preg_replace('/\b(agregar|añadir|sumar|registrar|meter|entrada|de|del|la|el|los|las|piezas|cajas|unidades|a|en|precio|pesos)\b/u', ' ', $comando);
        $nombreLimpio = preg_replace('/\d+(?:\.\d+)?/', '', $nombreLimpio);
        $nombreLimpio = trim(preg_replace('/\s+/', ' ', $nombreLimpio));

        if (mb_strlen($nombreLimpio) < 2) {
            echo json_encode(['ok' => false, 'mensaje' => 'No identifiqué el nombre del producto. Intenta: "Agregar 5 leche".']);
            exit;
        }

        $coincidencias = $this->productoModel->buscarPorNombre($negocioId, $nombreLimpio);

        if (!empty($coincidencias)) {
            $prod = $coincidencias[0];
            $this->productoModel->sumarStock((int)$prod['id_productos'], $cantidad);
            echo json_encode([
                'ok' => true,
                'mensaje' => "Se sumaron +{$cantidad} unidades a '{$prod['nombre']}'."
            ]);
        } else {
            $nombreCapital = mb_convert_case($nombreLimpio, MB_CASE_TITLE, 'UTF-8');
            $this->productoModel->registrarProducto(
                $negocioId,
                $nombreCapital,
                'Registrado por voz · Unidad: Pieza',
                $precio,
                $cantidad
            );
            echo json_encode([
                'ok' => true,
                'mensaje' => "Producto nuevo '{$nombreCapital}' creado con {$cantidad} uds. a $" . number_format($precio, 2)
            ]);
        }
        exit;
    }

    /**
     * RF-06 y RF-07: Motor unificado de voz con precedencia de precios (unitario vs total)
     */
    public function procesarMultimodal() {
        header('Content-Type: application/json; charset=utf-8');
        if (!isset($_SESSION['id_negocios'])) {
            echo json_encode(['status' => 'error', 'message' => 'Sesión expirada.']);
            exit;
        }

        $textoOriginal = trim($_POST['texto_voz'] ?? '');
        if ($textoOriginal === '') {
            echo json_encode(['status' => 'error', 'message' => 'No se recibió dictado de voz.']);
            exit;
        }

        $textoLimpio = mb_strtolower($textoOriginal, 'UTF-8');
        $esSalida    = (stristr($textoLimpio, 'vend') !== false || stristr($textoLimpio, 'salid') !== false || stristr($textoLimpio, 'menos') !== false);
        $accion      = $esSalida ? 'salida' : 'entrada';

        $mapaNumeros = [
            'un ' => '1 ', 'uno ' => '1 ', 'una ' => '1 ',
            'dos ' => '2 ', 'tres ' => '3 ', 'cuatro ' => '4 ',
            'cinco ' => '5 ', 'seis ' => '6 ', 'siete ' => '7 ',
            'ocho ' => '8 ', 'nueve ' => '9 ', 'diez ' => '10 '
        ];
        $textoNormalizado = strtr($textoLimpio, $mapaNumeros);

        $unidadesComunes = ['cartones', 'carton', 'cajas', 'caja', 'rejas', 'reja', 'kilos', 'kg', 'kilo', 'piezas', 'pieza', 'bolsas', 'bolsa', 'latas', 'lata', 'botellas', 'botella', 'paquetes', 'paquete'];
        $stopwords       = ['llegaron', 'compre', 'compré', 'se', 'vendieron', 'vendi', 'vendí', 'de', 'del', 'los', 'las', 'un', 'una', 'unos', 'unas', 'en', 'por', 'pesos', 'total', 'costo'];

        $productosParseados = [];
        $segmentos = preg_split('/(,|\by\b)/u', $textoNormalizado);

        foreach ($segmentos as $segmento) {
            $segmento = trim($segmento);
            if ($segmento === '') continue;

            $cantidad = 1;
            if (preg_match('/(\d+)/', $segmento, $mCant)) {
                $cantidad = max(1, (int)$mCant[1]);
            }

            $montoDetectado = null;
            if (preg_match_all('/\$?\d+(?:\.\d+)?/', $segmento, $mPrecios)) {
                $nums = $mPrecios[0];
                if (count($nums) > 1) {
                    $montoDetectado = (float)str_replace('$', '', $nums[1]);
                } elseif (count($nums) === 1 && $cantidad === 1) {
                    $montoDetectado = (float)str_replace('$', '', $nums[0]);
                }
            }

            $precioUnitario = 0.0;
            if ($montoDetectado !== null) {
                $esUnitario = (
                    preg_match('/(cada\s*un[ao]|c\/u|por\s*pieza|a\s*\$?\d+)/u', $segmento) ||
                    strpos($segmento, ' a ') !== false
                );
                $esTotal = (bool)preg_match('/(total|en\s*total|costo\s*total)/u', $segmento);

                if ($cantidad === 1 || ($esUnitario && !$esTotal)) {
                    $precioUnitario = $montoDetectado;
                } else {
                    $precioUnitario = round($montoDetectado / $cantidad, 2);
                }
            }

            $unidad = 'Pieza';
            foreach ($unidadesComunes as $u) {
                if (preg_match('/\b' . preg_quote($u, '/') . '\b/u', $segmento)) {
                    $unidad = ucfirst($u);
                    break;
                }
            }

            $limpio = preg_replace('/\$?\d+(?:\.\d+)?\s*(total|costo|pesos|cada\s*un[ao]|c\/u)?/u', '', $segmento);
            $limpio = preg_replace('/(total|costo|en|a|por)\s*\$?\d+(?:\.\d+)?/u', '', $limpio);
            $limpio = preg_replace('/\b\d+\b/', '', $limpio);

            $palabrasNombre = [];
            foreach (explode(' ', $limpio) as $p) {
                $pLimpia = trim($p, " \t\n\r\0\x0B.,$");
                if ($pLimpia === '' || is_numeric($pLimpia)) continue;
                if (in_array($pLimpia, $unidadesComunes, true) || in_array($pLimpia, $stopwords, true)) continue;
                $palabrasNombre[] = mb_convert_case($pLimpia, MB_CASE_TITLE, 'UTF-8');
            }

            $nombreProducto = !empty($palabrasNombre) ? implode(' ', $palabrasNombre) : 'Producto General';

            $productosParseados[] = [
                'nombre'          => $nombreProducto,
                'cantidad'        => $cantidad,
                'unidad'          => $unidad,
                'precio_unitario' => $precioUnitario
            ];
        }

        echo json_encode([
            'status'                => 'success',
            'origen'                => 'dictado_voz',
            'transcripcion_original'=> $textoOriginal,
            'accion'                => $accion,
            'productos'             => $productosParseados
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * RF-03, RF-05, RF-06, RF-07: Guarda lote verificado (desde Ticket OCR o Voz) en MySQL y devuelve datos para el Ticket PDF
     */
    public function guardarLoteInventario() {
        header('Content-Type: application/json; charset=utf-8');
        if (!isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            echo json_encode(['ok' => false, 'mensaje' => 'Sesión no válida.']);
            exit;
        }

        $negocio = $this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            echo json_encode(['ok' => false, 'mensaje' => 'Negocio no encontrado.']);
            exit;
        }

        $payload = json_decode(file_get_contents('php://input'), true);
        $accion  = ($payload['accion'] ?? 'entrada') === 'salida' ? 'salida' : 'entrada';
        $items   = $payload['productos'] ?? [];

        if (empty($items) || !is_array($items)) {
            echo json_encode(['ok' => false, 'mensaje' => 'No hay productos en la lista para guardar.']);
            exit;
        }

        $negocioId      = (int)$negocio['id_negocios'];
        $procesados     = [];
        $totalOperacion = 0.0;

        foreach ($items as $item) {
            $nombre   = limpiarTexto((string)($item['nombre'] ?? ''), 100);
            $cantidad = max(1, (int)($item['cantidad'] ?? 1));
            $unidad   = limpiarTexto((string)($item['unidad'] ?? 'Pieza'), 30) ?: 'Pieza';
            $costoU   = max(0.0, round((float)($item['precio_unitario'] ?? 0), 2));

            if (mb_strlen($nombre) < 2) continue;

            // Buscar si ya existe en el catálogo del negocio
            $coincidencias = $this->productoModel->buscarPorNombre($negocioId, $nombre);
            $existente = null;
            foreach ($coincidencias as $c) {
                if (mb_strtolower(trim($c['nombre']), 'UTF-8') === mb_strtolower($nombre, 'UTF-8')) {
                    $existente = $c;
                    break;
                }
            }

            if ($existente) {
                $idProd     = (int)$existente['id_productos'];
                $stockAct   = (int)$existente['stock'];
                $nuevoStock = ($accion === 'salida') ? max(0, $stockAct - $cantidad) : ($stockAct + $cantidad);
                $this->productoModel->actualizarStock($idProd, $nuevoStock);

                if ($accion === 'entrada' && $costoU > 0) {
                    $precioVentaActual = (float)$existente['precio'] > 0 ? (float)$existente['precio'] : round($costoU * 1.35, 2);
                    $this->productoModel->actualizarProducto(
                        $idProd,
                        $existente['nombre'],
                        $existente['descripcion'] ?? "Unidad: {$unidad}",
                        $precioVentaActual,
                        $costoU,
                        $existente['precio_mercado'] ?? null
                    );
                }
            } else {
                // Producto nuevo desde ticket o voz
                $stockInicial = ($accion === 'entrada') ? $cantidad : 0;
                $precioVenta  = ($costoU > 0) ? round($costoU * 1.35, 2) : 10.00;
                $this->productoModel->registrarProducto(
                    $negocioId,
                    $nombre,
                    "Unidad: {$unidad} · Alta rápida",
                    $precioVenta,
                    $stockInicial,
                    $costoU,
                    null
                );
            }

            $subtotal = round($cantidad * $costoU, 2);
            $totalOperacion += $subtotal;
            $procesados[] = [
                'nombre'          => $nombre,
                'cantidad'        => $cantidad,
                'unidad'          => $unidad,
                'precio_unitario' => $costoU,
                'subtotal'        => $subtotal
            ];
        }

        echo json_encode([
            'ok'      => true,
            'mensaje' => 'Se actualizaron ' . count($procesados) . ' artículo(s) en tu inventario.',
            'ticket'  => [
                'folio'   => 'MOV-' . date('Ymd-His'),
                'fecha'   => date('d/m/Y H:i'),
                'negocio' => $negocio['nombre'],
                'tipo'    => $accion === 'salida' ? 'Salida / Venta Rápida' : 'Entrada de Mercancía / Compra',
                'items'   => $procesados,
                'total'   => $totalOperacion
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
?>