<?php
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../modelo/productos.php';
require_once __DIR__ . '/../modelo/pedido.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class NegocioController {
    private $negocioModel;
    private $productoModel;
    private $pedidoModel;

    public function __construct() {
        $this->negocioModel  = new Negocio();
        $this->productoModel = new Producto();$this->pedidoModel   = new Pedido();
    }

    private function verificarSesion() {
        if (!isset($_SESSION['id_duenos'])) {
            header('Location: index.php');
            exit;
        }
    }

    public function mostrarFormulario($error = '', $datos = []) {$this->verificarSesion();
        require __DIR__ . '/../vista/crear_negocio.php';
    }

    public function guardarNegocio() {
        $this->verificarSesion();

        $duenoId   = (int)$_SESSION['id_duenos'];
        $nombre    = limpiarTexto($_POST['nombre'] ?? '', 100);
        $tipo      = validarGiro($_POST['tipo'] ?? 'abarrotes');
        $ubicacion = limpiarTexto($_POST['ubicacion'] ?? '', 100) ?: null;
        $horario   = limpiarTexto($_POST['horario'] ?? '', 100) ?: null;
        $mensaje   = limpiarTexto($_POST['mensaje_bienvenida'] ?? '', 250) ?: null;

        $telRaw = trim($_POST['telefono_contacto'] ?? '');$telLocal = null;
        if ($telRaw !== '') {
            $telLocal = validarTelefono($telRaw);
            if ($telLocal === null) {$this->mostrarFormulario('El teléfono del local debe tener 10 dígitos.', $_POST);
                return;
            }
        }

        if (mb_strlen($nombre) < 2) {$this->mostrarFormulario('Escribe el nombre de tu negocio (mínimo 2 letras).', $_POST);
            return;
        }

        $idNegocio = $this->negocioModel->registrarNegocio($duenoId, $nombre,$tipo, $telLocal,$ubicacion, $mensaje,$horario
        );

        if (!$idNegocio) {
            $this->mostrarFormulario('Error al guardar el negocio en la base de datos.',$_POST);
            return;
        }

        $_SESSION['id_negocios'] = (int)$idNegocio;
        header('Location: index.php?accion=espacio');
        exit;
    }

    public function mostrarConfiguracion($error = '', $exito = '') {$this->verificarSesion();
        $idDueno   = (int)$_SESSION['id_duenos'];
        $idNegocio = (int)($_SESSION['id_negocios'] ?? 0);

        $negocio =$this->negocioModel->obtenerPorIdYDueno($idNegocio,$idDueno);
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }

        require __DIR__ . '/../vista/configurar_negocio.php';
    }

    public function editarNegocio() {
        $this->verificarSesion();
        $idDueno   = (int)$_SESSION['id_duenos'];
        $idNegocio = (int)($_SESSION['id_negocios'] ?? 0);

        $actual =$this->negocioModel->obtenerPorIdYDueno($idNegocio,$idDueno);
        if (!$actual) {
            header('Location: index.php?accion=espacio');
            exit;
        }

        $nombre    = limpiarTexto($_POST['nombre'] ?? '', 100);$tipo      = validarGiro($_POST['tipo'] ?? $actual['tipo']);
        $ubicacion = limpiarTexto($_POST['ubicacion'] ?? '', 100) ?: null;
        $horario   = limpiarTexto($_POST['horario'] ?? '', 100) ?: null;
        $mensaje   = limpiarTexto($_POST['mensaje_bienvenida'] ?? '', 250) ?: null;

        $telRaw   = trim($_POST['telefono_contacto'] ?? '');$telLocal = null;
        if ($telRaw !== '') {
            $telLocal = validarTelefono($telRaw);
            if ($telLocal === null) {$this->mostrarConfiguracion('El teléfono del local debe tener 10 dígitos.');
                return;
            }
        }

        if (mb_strlen($nombre) < 2) {$this->mostrarConfiguracion('El nombre del negocio debe tener al menos 2 letras.');
            return;
        }

        $ok = $this->negocioModel->actualizarNegocio($idNegocio, $nombre,$tipo, $telLocal,$ubicacion, $mensaje,$horario
        );

        if (!$ok) {$this->mostrarConfiguracion('No se pudieron guardar los cambios.');
            return;
        }

        $this->mostrarConfiguracion('', '¡Configuración del negocio actualizada!');
    }

    public function eliminarNegocio() {
        $this->verificarSesion();
        $idDueno   = (int)$_SESSION['id_duenos'];
        $idNegocio = (int)($_SESSION['id_negocios'] ?? 0);

        $actual =$this->negocioModel->obtenerPorIdYDueno($idNegocio,$idDueno);
        if ($actual) {
            $this->negocioModel->eliminarNegocio($idNegocio);
        }

        unset($_SESSION['id_negocios']);$restantes = $this->negocioModel->obtenerNegociosPorDueno($idDueno);

        if (!empty($restantes)) {
            $_SESSION['id_negocios'] = (int)$restantes[0]['id_negocios'];
            header('Location: index.php?accion=espacio');
        } else {
            header('Location: index.php?accion=nuevo_negocio');
        }
        exit;
    }

    public function mostrarEspacio() {
        $this->verificarSesion();
        $idDueno = (int)$_SESSION['id_duenos'];

        if (isset($_GET['id'])) {
            $_SESSION['id_negocios'] = (int)$_GET['id'];
        }

        $misNegocios = $this->negocioModel->obtenerNegociosPorDueno($idDueno);
        if (empty($misNegocios)) {
            header('Location: index.php?accion=nuevo_negocio');
            exit;
        }

        $idActivo = (int)($_SESSION['id_negocios'] ?? $misNegocios[0]['id_negocios']);
        $negocio  =$this->negocioModel->obtenerPorIdYDueno($idActivo,$idDueno);

        if (!$negocio) {
            $negocio =$misNegocios[0];
        }

        $idNegocioActivo = (int)$negocio['id_negocios'];
        $productosReales =$this->productoModel->obtenerPorNegocio($idNegocioActivo);$ventasHoyLista  = $this->pedidoModel->obtenerPorPeriodo($idNegocioActivo, 'diario');

        $totalVentasHoy = 0.0;
        $ticketsHoy     = 0;
        foreach ($ventasHoyLista as$vHoy) {
            if (($vHoy['estado'] ?? '') !== 'cancelado') {$totalVentasHoy += (float)$vHoy['total'];$ticketsHoy++;
            }
        }
        $montoHoyFmt = '$' . number_format($totalVentasHoy, 2);

        $temas = [
            'abarrotes' => [
                'badge' => 'Abarrotes',
                'bg' => '#F2F8F4', 'primary' => '#1B5E3A', 'soft' => '#E1F2E8',
                'kpis' => [
                    ['Ventas de Hoy', $montoHoyFmt,$ticketsHoy . ' ticket(s) cobrados hoy'],
                    ['Productos en Catálogo', count($productosReales) . ' registrados', 'Inventario activo']
                ],
                'acciones' => [
                    ['Catálogo y Stock (RF-03)', 'Gestionar Productos', 'Agrega artículos, costos, precios y revisa existencias.', 'index.php?accion=productos'],
                    ['Caja Rápida (RF-04)', 'Registrar Venta', 'Cobra productos y descuenta el inventario al instante.', 'index.php?accion=ventas'],
                    ['Finanzas (RF-09/10)', 'Utilidad y Precios', 'Calcula márgenes reales y precios recomendados.', 'index.php?accion=finanzas'],
                    ['Agenda (RF-13/14)', 'Entregas y Avisos', 'Programa pedidos con fecha de entrega y recordatorios.', 'index.php?accion=agenda'],
                    ['Surtido (RF-15/16)', 'Proveedores y Mercado', 'Gestiona proveedores y compara precios de referencia.', 'index.php?accion=proveedores'],
                    ['Cortes (RF-17/20)', 'Reportes y Exportar', 'Descarga reportes diarios, semanales o mensuales en CSV/PDF.', 'index.php?accion=reportes'],
                    ['Ajustes (RF-02)', 'Configurar Negocio', 'Edita giro, horarios, mensaje de bienvenida o ubicación.', 'index.php?accion=configurar_negocio']
                ],
                'items_demo' => [
                    ['Leche Entera 1L (Caja)', 'Quedan 4 piezas · Alta demanda', 'Resurtir hoy', true],
                    ['Refresco Cola 600ml', '24 piezas en enfriador', 'Buen nivel', false],
                    ['Huevo Blanco (Cartón)', 'Quedan 2 cartones', 'Stock bajo', true]
                ]
            ],
            'estetica' => [
                'badge' => 'Estética',
                'bg' => '#FDF4F7', 'primary' => '#B83B68', 'soft' => '#FCE7EF',
                'kpis' => [
                    ['Ingresos del Día', $montoHoyFmt,$ticketsHoy . ' servicio(s) cobrados hoy'],
                    ['Servicios e Insumos', count($productosReales) . ' registrados', 'Catálogo activo']
                ],
                'acciones' => [
                    ['Catálogo y Gama (RF-03)', 'Servicios e Insumos', 'Registra cortes, tintes, costos y existencias.', 'index.php?accion=productos'],
                    ['Caja Rápida (RF-04)', 'Cobrar Servicio / Venta', 'Registra servicios atendidos y descuenta insumos.', 'index.php?accion=ventas'],
                    ['Finanzas (RF-09/10)', 'Utilidad y Tarifas', 'Calcula ganancias por servicio y tarifas sugeridas.', 'index.php?accion=finanzas'],
                    ['Agenda (RF-13/14)', 'Citas y Recordatorios', 'Agenda citas de clientas y manda recordatorio WhatsApp.', 'index.php?accion=agenda'],
                    ['Surtido (RF-15/16)', 'Distribuidores y Mercado', 'Controla proveedores de belleza y precios de mercado.', 'index.php?accion=proveedores'],
                    ['Cortes (RF-17/20)', 'Reportes y Exportar', 'Genera cortes de caja en Excel/CSV o PDF.', 'index.php?accion=reportes'],
                    ['Ajustes (RF-02)', 'Configurar Negocio', 'Edita giro, horarios, mensaje de bienvenida o ubicación.', 'index.php?accion=configurar_negocio']
                ],
                'items_demo' => [
                    ['Tinte Rubio Cenizo 7.1', 'Quedan 2 tubos · Alta demanda', 'Pedir tono', true],
                    ['Peróxido 20 Vol. (1L)', '2 botellas disponibles', 'Disponible', false],
                    ['Gelish Base y Top', 'Queda 1 frasco de cada uno', 'Por agotarse', true]
                ]
            ],
            'plantilla' => [
                'badge' => 'Plantilla Adaptable',
                'bg' => '#F4F6F8', 'primary' => '#334155', 'soft' => '#E2E8F0',
                'kpis' => [
                    ['Movimiento Hoy', $montoHoyFmt,$ticketsHoy . ' operación(es) hoy'],
                    ['Artículos', count($productosReales) . ' registrados', 'Listo para operar']
                ],
                'acciones' => [
                    ['Catálogo (RF-03)', 'Gestionar Artículos', 'Da de alta tus productos o servicios con costo y precio.', 'index.php?accion=productos'],
                    ['Caja Rápida (RF-04)', 'Registrar Venta', 'Cobra movimientos y actualiza existencias.', 'index.php?accion=ventas'],
                    ['Finanzas (RF-09/10)', 'Utilidad y Precios', 'Analiza ganancias y calcula precios con margen.', 'index.php?accion=finanzas'],
                    ['Agenda (RF-13/14)', 'Agenda y Recordatorios', 'Programa citas o entregas con avisos por WhatsApp.', 'index.php?accion=agenda'],
                    ['Surtido (RF-15/16)', 'Proveedores y Mercado', 'Administra proveedores y precios de referencia.', 'index.php?accion=proveedores'],
                    ['Cortes (RF-17/20)', 'Reportes y Exportar', 'Consulta reportes periódicos y exporta CSV/PDF.', 'index.php?accion=reportes'],
                    ['Ajustes (RF-02)', 'Configurar Negocio', 'Edita giro, horarios, mensaje de bienvenida o ubicación.', 'index.php?accion=configurar_negocio']
                ],
                'items_demo' => [
                    ['Insumo Principal #1', 'Configurado en plantilla base', 'Activo', false],
                    ['Insumo Principal #2', 'Listo para recibir movimientos', 'Activo', false]
                ]
            ]
        ];

        $t =$temas[$negocio['tipo']] ?? $temas['plantilla'];
        require __DIR__ . '/../vista/espacio.php';
    }
}
?>