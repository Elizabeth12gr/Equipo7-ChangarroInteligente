<?php
require_once __DIR__ . '/../modelo/proveedor.php';
require_once __DIR__ . '/../modelo/productos.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class ProveedorController {
    private $proveedorModel;
    private $productoModel;
    private $negocioModel;

    public function __construct() {
        $this->proveedorModel = new Proveedor();
        $this->productoModel  = new Producto();
        $this->negocioModel   = new Negocio();
    }

    private function obtenerContextoNegocio() {
        if (!isset($_SESSION['id_duenos'], $_SESSION['id_negocios'])) {
            header('Location: index.php');
            exit;
        }
        $negocio = $this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        return $negocio;
    }

    public function mostrarProveedores($error = '', $exito = '') {
        $negocio     = $this->obtenerContextoNegocio();
        $negocioId   = (int)$negocio['id_negocios'];
        $t           = obtenerTemaNegocio($negocio['tipo']);
        $proveedores = $this->proveedorModel->obtenerPorNegocio($negocioId);
        $productos   = $this->productoModel->obtenerPorNegocio($negocioId);

        $comparativaMercado = array_filter($productos, function ($p) {
            return isset($p['precio_mercado']) && $p['precio_mercado'] !== null && (float)$p['precio_mercado'] > 0;
        });

        require __DIR__ . '/../vista/proveedores.php';
    }

    public function guardarProveedor() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];

        $nombre = limpiarTexto($_POST['nombre'] ?? '', 100);
        $telRaw = trim($_POST['telefono'] ?? '');

        $telefono = null;
        if ($telRaw !== '') {
            $telefono = validarTelefono($telRaw);
            if ($telefono === null) {
                $this->mostrarProveedores('El teléfono del proveedor debe tener 10 dígitos.');
                return;
            }
        }

        if (mb_strlen($nombre) < 2) {
            $this->mostrarProveedores('Escribe el nombre del proveedor (mínimo 2 letras).');
            return;
        }

        $ok = $this->proveedorModel->registrarProveedor($negocioId, $nombre, $telefono);
        if (!$ok) {
            $this->mostrarProveedores('No se pudo guardar el proveedor.');
            return;
        }

        $this->mostrarProveedores('', '¡Proveedor registrado correctamente!');
    }

    public function eliminarProveedor() {
        $negocio   = $this->obtenerContextoNegocio();
        $negocioId = (int)$negocio['id_negocios'];
        $idProv    = (int)($_GET['id'] ?? 0);

        if ($idProv > 0) {
            $this->proveedorModel->eliminarProveedor($idProv, $negocioId);
        }

        $this->mostrarProveedores('', 'Proveedor eliminado.');
    }
}
?>