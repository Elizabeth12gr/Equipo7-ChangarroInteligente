<?php
require_once __DIR__ . '/../modelo/cliente.php';
require_once __DIR__ . '/../modelo/negocios.php';
require_once __DIR__ . '/../ayudas/validaciones.php';

class ClienteController {
    private $clienteModel;
    private $negocioModel;

    public function __construct() {
        $this->clienteModel = new Cliente();$this->negocioModel = new Negocio();
    }

    private function obtenerContextoNegocio() {
        if (!isset($_SESSION['id_duenos'],$_SESSION['id_negocios'])) {
            header('Location: index.php');
            exit;
        }
        $negocio =$this->negocioModel->obtenerPorIdYDueno(
            (int)$_SESSION['id_negocios'],
            (int)$_SESSION['id_duenos']
        );
        if (!$negocio) {
            header('Location: index.php?accion=espacio');
            exit;
        }
        return $negocio;
    }

    public function mostrarClientes($error = '',$exito = '') {
        $negocio  =$this->obtenerContextoNegocio();
        $t        = obtenerTemaNegocio($negocio['tipo']);
        $clientes =$this->clienteModel->obtenerTodos();

        $terminoBusqueda = trim($_GET['buscar'] ?? '');
        if ($terminoBusqueda !== '') {
            $encontrado =$this->clienteModel->buscarCliente($terminoBusqueda);$clientes = $encontrado ? [$encontrado] : [];
        }

        $clienteEditar = null;
        if (isset($_GET['editar'])) {$clienteEditar = $this->clienteModel->obtenerCliente((int)$_GET['editar']);
        }

        require __DIR__ . '/../vista/clientes.php';
    }

    public function guardarCliente() {
        $this->obtenerContextoNegocio();

        $telefono     = validarTelefono($_POST['telefono_whatsapp'] ?? '');
        $nombreReal   = limpiarTexto($_POST['nombre_cliente'] ?? '', 100);
        $preferencias = limpiarTexto($_POST['nombre_perfil'] ?? '', 100);

        if ($telefono === null) {$this->mostrarClientes('El número de WhatsApp debe tener exactamente 10 dígitos.');
            return;
        }
        if (mb_strlen($nombreReal) < 2) {$this->mostrarClientes('Ingresa el nombre del cliente (mínimo 2 letras).');
            return;
        }

        $creado = $this->clienteModel->registrarCliente($telefono, $preferencias,$nombreReal);
        if (!$creado) {$this->mostrarClientes('Ese número de WhatsApp ya está registrado en tu directorio.');
            return;
        }

        $this->mostrarClientes('', '¡Cliente registrado correctamente!');
    }

    public function actualizarCliente() {
        $this->obtenerContextoNegocio();

        $idCliente    = (int)($_POST['id_clientes'] ?? 0);
        $nombreReal   = limpiarTexto($_POST['nombre_cliente'] ?? '', 100);
        $preferencias = limpiarTexto($_POST['nombre_perfil'] ?? '', 100);

        if ($idCliente <= 0 || mb_strlen($nombreReal) < 2) {$this->mostrarClientes('Verifica que el nombre del cliente sea válido.');
            return;
        }

        $this->clienteModel->actualizarCliente($idCliente,$nombreReal, $preferencias);$this->mostrarClientes('', '¡Datos del cliente actualizados!');
    }

    public function eliminarCliente() {
        $this->obtenerContextoNegocio();
        $idCliente = (int)($_GET['id'] ?? 0);

        if ($idCliente > 0) {
            $this->clienteModel->eliminarCliente($idCliente);
        }

        $this->mostrarClientes('', 'Cliente eliminado del directorio.');
    }
}
?>