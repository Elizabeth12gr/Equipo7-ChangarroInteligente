<?php
require_once __DIR__ . '/../conexion.php';

class Negocio {
    private $conn;

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function registrarNegocio($dueno_id, $nombre, $tipo, $telefono_contacto = null, $ubicacion = null, $mensaje_bienvenida = null, $horario = null) {
        try {
            $query = "INSERT INTO negocios (dueno_id, nombre, tipo, telefono_contacto, ubicacion, mensaje_bienvenida, horario) 
                      VALUES (:dueno_id, :nombre, :tipo, :telefono_contacto, :ubicacion, :mensaje_bienvenida, :horario)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":dueno_id", $dueno_id);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":tipo", $tipo);
            $stmt->bindParam(":telefono_contacto", $telefono_contacto);
            $stmt->bindParam(":ubicacion", $ubicacion);
            $stmt->bindParam(":mensaje_bienvenida", $mensaje_bienvenida);
            $stmt->bindParam(":horario", $horario);

            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
        } catch (PDOException $e) {
            return false;
        }
        return false;
    }

    public function obtenerNegocio($id_negocios) {
        $query = "SELECT * FROM negocios WHERE id_negocios = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id_negocios);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerNegociosPorDueno($dueno_id) {
        $query = "SELECT * FROM negocios WHERE dueno_id = :dueno_id ORDER BY id_negocios ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":dueno_id", $dueno_id);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorDueno($dueno_id) {
        return $this->obtenerNegociosPorDueno($dueno_id);
    }

    public function obtenerPorIdYDueno($id_negocios, $dueno_id) {
        $query = "SELECT n.*, d.nombre AS dueno_nombre 
                  FROM negocios n
                  INNER JOIN duenos d ON n.dueno_id = d.id_duenos
                  WHERE n.id_negocios = :id_negocios AND n.dueno_id = :dueno_id 
                  LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id_negocios", $id_negocios);
        $stmt->bindParam(":dueno_id", $dueno_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function actualizarNegocio($id_negocios, $nombre, $tipo, $telefono_contacto, $ubicacion, $mensaje_bienvenida, $horario) {
        try {
            $query = "UPDATE negocios SET nombre = :nombre, tipo = :tipo, telefono_contacto = :tel, 
                      ubicacion = :ubi, mensaje_bienvenida = :msj, horario = :horario 
                      WHERE id_negocios = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":tipo", $tipo);
            $stmt->bindParam(":tel", $telefono_contacto);
            $stmt->bindParam(":ubi", $ubicacion);
            $stmt->bindParam(":msj", $mensaje_bienvenida);
            $stmt->bindParam(":horario", $horario);
            $stmt->bindParam(":id", $id_negocios);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarNegocio($id_negocios) {
        try {
            $query = "DELETE FROM negocios WHERE id_negocios = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id_negocios);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>