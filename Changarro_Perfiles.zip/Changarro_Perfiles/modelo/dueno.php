<?php
require_once __DIR__ . '/../conexion.php';

class Dueno {
    private $conn;

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function registrarDueno($nombre, $telefono, $correo, $passwordHash) {
        try {
            $query = "INSERT INTO duenos (nombre, telefono, correo, password) 
                      VALUES (:nombre, :telefono, :correo, :password)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":telefono", $telefono);
            $stmt->bindParam(":correo", $correo);
            $stmt->bindParam(":password", $passwordHash);

            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
        } catch (PDOException $e) {
            return false;
        }
        return false;
    }

    public function buscarPorCorreo($correo) {
        $query = "SELECT * FROM duenos WHERE correo = :correo LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":correo", $correo);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerDueno($id_duenos) {
        $query = "SELECT * FROM duenos WHERE id_duenos = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id_duenos);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function actualizarDueno($id_duenos, $nombre, $telefono, $correo) {
        try {
            $query = "UPDATE duenos SET nombre = :nombre, telefono = :telefono, correo = :correo 
                      WHERE id_duenos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":telefono", $telefono);
            $stmt->bindParam(":correo", $correo);
            $stmt->bindParam(":id", $id_duenos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function actualizarPassword($id_duenos, $passwordHash) {
        try {
            $query = "UPDATE duenos SET password = :password WHERE id_duenos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":password", $passwordHash);
            $stmt->bindParam(":id", $id_duenos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarDueno($id_duenos) {
        try {
            $query = "DELETE FROM duenos WHERE id_duenos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id_duenos);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>