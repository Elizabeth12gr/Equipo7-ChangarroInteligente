<?php
require_once __DIR__ . '/../conexion.php';

class Producto {
    private $conn;

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function registrarProducto($negocio_id, $nombre, $descripcion, $precio, $stock, $costo = 0, $precio_mercado = null) {
        try {
            $query = "INSERT INTO productos (negocio_id, nombre, descripcion, costo, precio, precio_mercado, stock) 
                      VALUES (:negocio_id, :nombre, :descripcion, :costo, :precio, :precio_mercado, :stock)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":negocio_id", $negocio_id);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":descripcion", $descripcion);
            $stmt->bindParam(":costo", $costo);
            $stmt->bindParam(":precio", $precio);
            $stmt->bindParam(":precio_mercado", $precio_mercado);
            $stmt->bindParam(":stock", $stock);

            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
        } catch (PDOException $e) {
            return false;
        }
        return false;
    }

    public function obtenerProducto($id_productos) {
        $query = "SELECT * FROM productos WHERE id_productos = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id_productos);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPorNegocio($negocio_id) {
        $query = "SELECT * FROM productos WHERE negocio_id = :negocio_id ORDER BY id_productos DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":negocio_id", $negocio_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerStockBajo($negocio_id, $limite = 5) {
        $query = "SELECT * FROM productos 
                  WHERE negocio_id = :negocio_id AND stock <= :limite 
                  ORDER BY stock ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":negocio_id", $negocio_id);
        $stmt->bindParam(":limite", $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorNombre($negocio_id, $termino) {
        $query = "SELECT * FROM productos 
                  WHERE negocio_id = :negocio_id AND nombre LIKE :termino 
                  ORDER BY nombre ASC";
        $stmt = $this->conn->prepare($query);
        $busqueda = "%" . $termino . "%";
        $stmt->bindParam(":negocio_id", $negocio_id);
        $stmt->bindParam(":termino", $busqueda);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function actualizarProducto($id_productos, $nombre, $descripcion, $precio, $costo = 0, $precio_mercado = null) {
        try {
            $query = "UPDATE productos SET nombre = :nombre, descripcion = :desc, costo = :costo, precio = :precio, precio_mercado = :precio_mercado 
                      WHERE id_productos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nombre", $nombre);
            $stmt->bindParam(":desc", $descripcion);
            $stmt->bindParam(":costo", $costo);
            $stmt->bindParam(":precio", $precio);
            $stmt->bindParam(":precio_mercado", $precio_mercado);
            $stmt->bindParam(":id", $id_productos);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function actualizarStock($id_productos, $nuevo_stock) {
        try {
            $query = "UPDATE productos SET stock = :stock WHERE id_productos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":stock", $nuevo_stock);
            $stmt->bindParam(":id", $id_productos);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function sumarStock($id_productos, $cantidad) {
        try {
            $query = "UPDATE productos SET stock = stock + :cantidad WHERE id_productos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":cantidad", $cantidad);
            $stmt->bindParam(":id", $id_productos);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarProducto($id_productos) {
        try {
            $query = "DELETE FROM productos WHERE id_productos = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id_productos);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>