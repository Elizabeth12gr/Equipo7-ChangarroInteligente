<?php
require_once __DIR__ . '/../conexion.php';

class Cliente {
    private $conn;
    private $table_name = "clientes";

    public function __construct() {
        $database = new Conexion();
        $this->conn =$database->getConnection();
    }

    public function buscarCliente($telefono_whatsapp) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE telefono_whatsapp = :telefono_whatsapp LIMIT 1";
        $stmt =$this->conn->prepare($query);$stmt->bindParam(':telefono_whatsapp', $telefono_whatsapp);$stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerCliente($id_clientes) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id_clientes = :id LIMIT 1";
        $stmt =$this->conn->prepare($query);$stmt->bindParam(":id", $id_clientes);$stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerTodos() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY id_clientes DESC";
        $stmt =$this->conn->prepare($query);$stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function registrarCliente($telefono_whatsapp, $nombre_perfil,$nombre_cliente) {
        try {
            $query = "INSERT INTO " . $this->table_name . " (telefono_whatsapp, nombre_perfil, nombre_cliente) 
                      VALUES (:telefono_whatsapp, :nombre_perfil, :nombre_cliente)";
            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(":telefono_whatsapp", $telefono_whatsapp);
            $stmt->bindParam(":nombre_perfil", $nombre_perfil);
            $stmt->bindParam(":nombre_cliente", $nombre_cliente);

            if ($stmt->execute()) {
                return $this->conn->lastInsertId();
            }
        } catch (PDOException $e) {
            return false;
        }
        return false;
    }

    public function actualizarCliente($id_clientes, $nombre_cliente,$nombre_perfil) {
        try {
            $query = "UPDATE " . $this->table_name . " SET nombre_cliente = :nom_cli, nombre_perfil = :nom_perfil 
                      WHERE id_clientes = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":nom_cli", $nombre_cliente);
            $stmt->bindParam(":nom_perfil", $nombre_perfil);
            $stmt->bindParam(":id", $id_clientes);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarCliente($id_clientes) {
        try {
            $query = "DELETE FROM " . $this->table_name . " WHERE id_clientes = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $id_clientes);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>