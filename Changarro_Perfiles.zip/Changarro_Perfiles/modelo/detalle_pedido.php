<?php
require_once __DIR__ . '/../conexion.php';

class DetallePedido {
    private $conn;
    private $table_name = "detalles_pedido";

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function registrarDetalle($pedido_id, $producto_id, $cantidad, $precio_unitario) {
        try {
            $query = "INSERT INTO " . $this->table_name . " (pedido_id, producto_id, cantidad, precio_unitario) 
                      VALUES (:pedido_id, :producto_id, :cantidad, :precio_unitario)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":pedido_id", $pedido_id);
            $stmt->bindParam(":producto_id", $producto_id);
            $stmt->bindParam(":cantidad", $cantidad);
            $stmt->bindParam(":precio_unitario", $precio_unitario);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function obtenerDetallesPorPedido($pedido_id) {
        try {
            $query = "SELECT dp.cantidad, dp.precio_unitario, p.nombre 
                      FROM " . $this->table_name . " dp
                      INNER JOIN productos p ON dp.producto_id = p.id_productos
                      WHERE dp.pedido_id = :pedido_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":pedido_id", $pedido_id);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function obtenerVentasPorProducto($producto_id) {
        $query = "SELECT COALESCE(SUM(cantidad), 0) AS total_vendido 
                  FROM " . $this->table_name . " 
                  WHERE producto_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $producto_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerMasVendidosPorNegocio($negocio_id, $limite = 5) {
        try {
            $query = "SELECT p.nombre, SUM(dp.cantidad) AS total_unidades, SUM(dp.cantidad * dp.precio_unitario) AS total_dinero
                      FROM " . $this->table_name . " dp
                      INNER JOIN productos p ON dp.producto_id = p.id_productos
                      INNER JOIN pedidos ped ON dp.pedido_id = ped.id_pedidos
                      WHERE ped.negocio_id = :negocio_id
                        AND (ped.estado IS NULL OR ped.estado != 'cancelado')
                      GROUP BY p.id_productos, p.nombre
                      ORDER BY total_unidades DESC
                      LIMIT :limite";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":negocio_id", $negocio_id);
            $stmt->bindParam(":limite", $limite, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function eliminarDetallesDePedido($pedido_id) {
        try {
            $query = "DELETE FROM " . $this->table_name . " WHERE pedido_id = :pedido_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":pedido_id", $pedido_id);

            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function obtenerBalanceFinanciero($negocio_id) {
        try {
            $query = "SELECT 
                        p.id_productos,
                        p.nombre,
                        p.costo AS costo_unitario,
                        p.precio AS precio_actual,
                        COALESCE(SUM(dp.cantidad), 0) AS unidades_vendidas,
                        COALESCE(SUM(dp.cantidad * dp.precio_unitario), 0) AS ingresos_producto,
                        COALESCE(SUM(dp.cantidad * p.costo), 0) AS costos_producto
                      FROM productos p
                      LEFT JOIN detalles_pedido dp ON p.id_productos = dp.producto_id
                      LEFT JOIN pedidos ped ON dp.pedido_id = ped.id_pedidos 
                           AND (ped.estado IS NULL OR ped.estado != 'cancelado')
                      WHERE p.negocio_id = :negocio_id
                      GROUP BY p.id_productos, p.nombre, p.costo, p.precio
                      ORDER BY ingresos_producto DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}
?>