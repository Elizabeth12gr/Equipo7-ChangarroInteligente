<?php
require_once __DIR__ . '/../conexion.php';

class Proveedor {
    private $conn;

    public function __construct() {
        $database = new Conexion();
        $this->conn = $database->getConnection();
    }

    public function registrarProveedor($negocio_id, $nombre, $telefono) {
        try {
            $query = "INSERT INTO proveedores (negocio_id, nombre, telefono) 
                      VALUES (:negocio_id, :nombre, :telefono)";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':telefono', $telefono);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function obtenerPorNegocio($negocio_id) {
        try {
            $query = "SELECT * FROM proveedores WHERE negocio_id = :negocio_id ORDER BY id_proveedores DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':negocio_id', $negocio_id);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function actualizarProveedor($id_proveedores, $negocio_id, $nombre, $telefono) {
        try {
            $query = "UPDATE proveedores SET nombre = :nombre, telefono = :telefono 
                      WHERE id_proveedores = :id AND negocio_id = :negocio_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':telefono', $telefono);
            $stmt->bindParam(':id', $id_proveedores);
            $stmt->bindParam(':negocio_id', $negocio_id);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function eliminarProveedor($id_proveedores, $negocio_id) {
        try {
            $query = "DELETE FROM proveedores WHERE id_proveedores = :id AND negocio_id = :negocio_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id_proveedores);
            $stmt->bindParam(':negocio_id', $negocio_id);
            return $stmt->execute();
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>