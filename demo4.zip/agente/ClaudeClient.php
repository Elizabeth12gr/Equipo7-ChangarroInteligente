<?php
// agente/ClaudeClient.php — llamada a la API de Anthropic (Messages + tool use)

class ClaudeClient {
    private array $cfg;

    public function __construct(array $cfg) {
        $this->cfg = $cfg;
    }

    /** @throws Exception si la API falla */
    public function mensaje(string $system, array $messages, array $tools): array {
        if ($this->cfg['anthropic_key'] === '') {
            throw new Exception('Falta anthropic_key en config_agente.');
        }
        $body = [
            'model'      => $this->cfg['modelo'],
            'max_tokens' => $this->cfg['max_tokens'],
            'system'     => $system,
            'messages'   => $messages,
            'tools'      => $tools,
        ];
        $ch = curl_init($this->cfg['anthropic_url']);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_HTTPHEADER     => [
                'x-api-key: ' . $this->cfg['anthropic_key'],
                'anthropic-version: 2023-06-01',
                'content-type: application/json',
            ],
            CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
        ]);
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($resp === false) {
            throw new Exception("cURL: {$err}");
        }
        $data = json_decode($resp, true);
        if ($code !== 200 || !is_array($data)) {
            throw new Exception("Anthropic HTTP {$code}: " . mb_substr((string)$resp, 0, 300));
        }
        return $data;
    }
}
