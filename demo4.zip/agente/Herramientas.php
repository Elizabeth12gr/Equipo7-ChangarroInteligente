<?php
// agente/Herramientas.php — herramientas (tool use) que el agente puede ejecutar.
// IMPORTANTE: el negocio y el cliente los fija el SERVIDOR; el modelo nunca los elige.
require_once __DIR__ . '/Citas.php';
require_once __DIR__ . '/../conexion.php';

class Herramientas {
    private PDO $db;
    private array $negocio;
    private int $clienteId;
    private int $conversacionId;
    private Citas $citas;
    private $notificarDueno; // callable(string $texto): void

    public function __construct(array $negocio, int $clienteId, int $conversacionId, int $maxDias, callable $notificarDueno) {
        $this->db             = (new Conexion())->getConnection();
        $this->negocio        = $negocio;
        $this->clienteId      = $clienteId;
        $this->conversacionId = $conversacionId;
        $this->citas          = new Citas($negocio, $maxDias);
        $this->notificarDueno = $notificarDueno;
    }

    public static function definiciones(): array {
        return [
            [
                'name' => 'consultar_catalogo',
                'description' => 'Busca productos o servicios del negocio con su precio y disponibilidad. Úsala SIEMPRE antes de dar precios o confirmar que algo existe. Sin "busqueda" devuelve el catálogo (máx. 25).',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => ['busqueda' => ['type' => 'string', 'description' => 'Texto a buscar en el nombre (opcional).']],
                ],
            ],
            [
                'name' => 'ver_disponibilidad',
                'description' => 'Devuelve los horarios libres de un día para un servicio/producto. Úsala antes de proponer horas.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'fecha'       => ['type' => 'string', 'description' => 'Fecha en formato YYYY-MM-DD.'],
                        'producto_id' => ['type' => 'integer', 'description' => 'id del servicio/producto (opcional; define la duración).'],
                    ],
                    'required' => ['fecha'],
                ],
            ],
            [
                'name' => 'agendar_cita',
                'description' => 'Agenda una cita (servicio) o una entrega/recolección (producto). Llámala SOLO cuando el cliente ya confirmó servicio/producto, fecha y hora.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'producto_id'    => ['type' => 'integer'],
                        'fecha_hora'     => ['type' => 'string', 'description' => 'YYYY-MM-DD HH:MM (hora local del negocio).'],
                        'cantidad'       => ['type' => 'integer', 'description' => 'Solo para productos; para servicios es 1.'],
                        'tipo_pedido'    => ['type' => 'string', 'enum' => ['tienda', 'a domicilio'], 'description' => 'Por defecto "tienda".'],
                        'notas'          => ['type' => 'string', 'description' => 'Dirección de entrega o detalles relevantes.'],
                        'nombre_cliente' => ['type' => 'string', 'description' => 'Nombre que dio el cliente, si lo dijo.'],
                    ],
                    'required' => ['producto_id', 'fecha_hora'],
                ],
            ],
            [
                'name' => 'mis_citas',
                'description' => 'Lista las citas/entregas próximas de ESTE cliente.',
                'input_schema' => ['type' => 'object', 'properties' => new stdClass()],
            ],
            [
                'name' => 'cancelar_cita',
                'description' => 'Cancela una cita vigente de este cliente (pide confirmación antes).',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => ['id_cita' => ['type' => 'integer']],
                    'required' => ['id_cita'],
                ],
            ],
            [
                'name' => 'reprogramar_cita',
                'description' => 'Cambia la fecha/hora de una cita vigente de este cliente.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => [
                        'id_cita'    => ['type' => 'integer'],
                        'fecha_hora' => ['type' => 'string', 'description' => 'YYYY-MM-DD HH:MM'],
                    ],
                    'required' => ['id_cita', 'fecha_hora'],
                ],
            ],
            [
                'name' => 'pasar_con_humano',
                'description' => 'Transfiere la conversación al dueño/encargado (quejas, negociación de precios, temas fuera de tu alcance, o si el cliente lo pide). El agente deja de responder después.',
                'input_schema' => [
                    'type' => 'object',
                    'properties' => ['motivo' => ['type' => 'string', 'description' => 'Resumen breve para el encargado.']],
                    'required' => ['motivo'],
                ],
            ],
        ];
    }

    public function ejecutar(string $nombre, array $in): array {
        try {
            switch ($nombre) {
                case 'consultar_catalogo':  return $this->consultarCatalogo((string)($in['busqueda'] ?? ''));
                case 'ver_disponibilidad':  return $this->verDisponibilidad($in);
                case 'agendar_cita':        return $this->agendarCita($in);
                case 'mis_citas':           return ['citas' => $this->citas->misCitas($this->clienteId)];
                case 'cancelar_cita':       return $this->citas->cancelar($this->clienteId, (int)($in['id_cita'] ?? 0));
                case 'reprogramar_cita':    return $this->reprogramarCita($in);
                case 'pasar_con_humano':    return $this->pasarConHumano((string)($in['motivo'] ?? ''));
            }
        } catch (Throwable $e) {
            agente_log("Herramienta {$nombre}: " . $e->getMessage());
            return ['ok' => false, 'error' => 'Error interno ejecutando la herramienta.'];
        }
        return ['ok' => false, 'error' => 'Herramienta desconocida.'];
    }

    /** Quita de la descripción cualquier dato interno (costo, mercado, proveedor...). */
    private function descripcionPublica(?string $desc): string {
        if (!$desc) return '';
        $partes = preg_split('/\s*[|·]\s*/u', $desc);
        $ok = [];
        foreach ($partes as $p) {
            if ($p === '' || preg_match('/costo|mercado|proveedor|margen|ganancia|utilidad/iu', $p)) continue;
            $ok[] = $p;
        }
        return implode(' · ', $ok);
    }

    private function consultarCatalogo(string $busqueda): array {
        $busqueda = mb_substr(trim($busqueda), 0, 60, 'UTF-8');
        $sql = "SELECT id_productos, nombre, descripcion, precio, stock, duracion_min
                FROM productos WHERE negocio_id = :n";
        $par = [':n' => $this->negocio['id_negocios']];
        if ($busqueda !== '') {
            $sql .= " AND nombre LIKE :b";
            $par[':b'] = '%' . $busqueda . '%';
        }
        $sql .= " ORDER BY nombre ASC LIMIT 25";
        $st = $this->db->prepare($sql);
        $st->execute($par);

        $items = [];
        foreach ($st->fetchAll() as $r) {
            $servicio = $r['duracion_min'] !== null;
            $item = [
                'id'          => (int)$r['id_productos'],
                'nombre'      => $r['nombre'],
                'detalle'     => $this->descripcionPublica($r['descripcion']),
                'precio_mxn'  => (float)$r['precio'],
                'tipo'        => $servicio ? 'servicio' : 'producto',
                'disponible'  => $servicio ? true : ((int)$r['stock'] > 0),
            ];
            if ($servicio) $item['duracion_min'] = (int)$r['duracion_min'];
            elseif ((int)$r['stock'] > 0 && (int)$r['stock'] <= 5) $item['quedan'] = (int)$r['stock'];
            $items[] = $item;
        }
        return ['resultados' => $items, 'nota' => $items ? null : 'No hay coincidencias.'];
    }

    private function verDisponibilidad(array $in): array {
        $fecha = $this->citas->parseFecha((string)($in['fecha'] ?? ''));
        if (!$fecha) return ['ok' => false, 'error' => 'Fecha inválida; usa YYYY-MM-DD.'];

        $dur = (int)$this->negocio['duracion_default_min'];
        $serv = null;
        if (!empty($in['producto_id'])) {
            $prod = $this->citas->producto((int)$in['producto_id']);
            if (!$prod) return ['ok' => false, 'error' => 'Ese producto/servicio no existe.'];
            $dur  = $this->citas->duracion($prod);
            $serv = $prod['nombre'];
        }
        $libres = $this->citas->horariosLibres($fecha, $dur);
        return [
            'fecha'          => Citas::DIAS[(int)$fecha->format('N')] . ' ' . $fecha->format('Y-m-d'),
            'servicio'       => $serv,
            'duracion_min'   => $dur,
            'horarios_libres'=> $libres,
            'nota'           => $libres ? null : 'Sin horarios libres ese día (cerrado, lleno o ya pasó).',
        ];
    }

    private function agendarCita(array $in): array {
        $prod = $this->citas->producto((int)($in['producto_id'] ?? 0));
        if (!$prod) return ['ok' => false, 'error' => 'Ese producto/servicio no existe en este negocio.'];

        $ini = $this->citas->parseFechaHora((string)($in['fecha_hora'] ?? ''));
        if (!$ini) return ['ok' => false, 'error' => 'Fecha/hora inválida; usa YYYY-MM-DD HH:MM.'];

        $tipo  = (($in['tipo_pedido'] ?? 'tienda') === 'a domicilio') ? 'a domicilio' : 'tienda';
        $notas = isset($in['notas']) ? trim(strip_tags((string)$in['notas'])) : null;
        if ($tipo === 'a domicilio' && ($notas === null || mb_strlen($notas) < 5)) {
            return ['ok' => false, 'error' => 'Para entrega a domicilio falta la dirección (campo notas).'];
        }

        $res = $this->citas->agendar($this->clienteId, $prod, (int)($in['cantidad'] ?? 1), $ini, $tipo, $notas);

        if (!empty($res['ok']) && !empty($in['nombre_cliente'])) {
            $nombre = mb_substr(trim(strip_tags((string)$in['nombre_cliente'])), 0, 100, 'UTF-8');
            if (mb_strlen($nombre) >= 2) {
                $this->db->prepare("UPDATE clientes SET nombre_cliente = :n WHERE id_clientes = :id")
                         ->execute([':n' => $nombre, ':id' => $this->clienteId]);
            }
        }
        return $res;
    }

    private function reprogramarCita(array $in): array {
        $ini = $this->citas->parseFechaHora((string)($in['fecha_hora'] ?? ''));
        if (!$ini) return ['ok' => false, 'error' => 'Fecha/hora inválida; usa YYYY-MM-DD HH:MM.'];
        return $this->citas->reprogramar($this->clienteId, (int)($in['id_cita'] ?? 0), $ini);
    }

    private function pasarConHumano(string $motivo): array {
        $motivo = mb_substr(trim(strip_tags($motivo)), 0, 255, 'UTF-8');
        $this->db->prepare("UPDATE conversaciones SET estado = 'humano', motivo_humano = :m WHERE id_conversaciones = :id")
                 ->execute([':m' => $motivo, ':id' => $this->conversacionId]);
        try {
            ($this->notificarDueno)("Un cliente necesita atención personal: {$motivo}");
        } catch (Throwable $e) {
            agente_log('notificarDueno: ' . $e->getMessage());
        }
        return ['ok' => true, 'nota' => 'Conversación transferida. Avisa al cliente que el encargado le responderá en cuanto pueda.'];
    }
}
