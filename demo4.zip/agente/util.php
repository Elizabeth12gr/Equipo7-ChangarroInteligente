<?php
// agente/util.php — registro de eventos del agente (NO registra llaves ni tokens)
function agente_log(string $msg): void {
    static $archivo = null;
    if ($archivo === null) {
        $cfg = require __DIR__ . '/../config_agente.php';
        $archivo = $cfg['log'];
    }
    @file_put_contents($archivo, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}
