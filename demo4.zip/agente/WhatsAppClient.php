<?php
// agente/WhatsAppClient.php — envío de mensajes por la WhatsApp Cloud API

class WhatsAppClient {
    private array $cfg;

    public function __construct(array $cfg) {
        $this->cfg = $cfg;
    }

    public function enviarTexto(string $phoneId, string $to, string $texto): bool {
        $texto = mb_substr($texto, 0, 4000, 'UTF-8');
        return $this->post($phoneId, [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'text',
            'text'              => ['preview_url' => false, 'body' => $texto],
        ]);
    }

    public function marcarLeido(string $phoneId, string $messageId): void {
        $this->post($phoneId, [
            'messaging_product' => 'whatsapp',
            'status'            => 'read',
            'message_id'        => $messageId,
        ]);
    }

    private function post(string $phoneId, array $payload): bool {
        if ($this->cfg['wa_token'] === '') {
            agente_log('WA: falta wa_token en config_agente.');
            return false;
        }
        $url = "{$this->cfg['graph_base']}/{$this->cfg['graph_version']}/" . rawurlencode($phoneId) . '/messages';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $this->cfg['wa_token'],
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]);
        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code < 200 || $code >= 300) {
            agente_log("WA: error HTTP {$code}: " . mb_substr((string)$resp, 0, 300));
            return false;
        }
        return true;
    }
}
