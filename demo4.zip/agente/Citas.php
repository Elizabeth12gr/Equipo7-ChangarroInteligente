<?php
// agente/Citas.php — disponibilidad y gestión de citas/entregas (usa pedidos.fecha_entrega)
require_once __DIR__ . '/../conexion.php';

class Citas {
    private PDO $db;
    private array $negocio;
    private int $maxDias;

    const DIAS  = ['', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
    const MESES = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto',
                   'septiembre', 'octubre', 'noviembre', 'diciembre'];

    public function __construct(array $negocio, int $maxDias = 90) {
        $this->db      = (new Conexion())->getConnection();
        $this->negocio = $negocio;
        $this->maxDias = $maxDias;
    }

    public static function fechaBonita(DateTime $d): string {
        return self::DIAS[(int)$d->format('N')] . ' ' . $d->format('j') . ' de '
             . self::MESES[(int)$d->format('n')] . ' a las ' . $d->format('H:i');
    }

    public function parseFechaHora(string $s): ?DateTime {
        $s  = trim(str_replace('T', ' ', $s));
        $dt = DateTime::createFromFormat('Y-m-d H:i', $s);
        $er = DateTime::getLastErrors();
        if (!$dt || ($er && ($er['warning_count'] > 0 || $er['error_count'] > 0))) {
            return null;
        }
        return $dt;
    }

    public function parseFecha(string $s): ?DateTime {
        $dt = DateTime::createFromFormat('Y-m-d H:i', trim($s) . ' 00:00');
        $er = DateTime::getLastErrors();
        if (!$dt || ($er && ($er['warning_count'] > 0 || $er['error_count'] > 0))) {
            return null;
        }
        return $dt;
    }

    public function esServicio(array $prod): bool {
        return $prod['duracion_min'] !== null && $prod['duracion_min'] !== '';
    }

    public function duracion(array $prod): int {
        return $this->esServicio($prod) ? max(5, (int)$prod['duracion_min'])
                                        : max(5, (int)$this->negocio['duracion_default_min']);
    }

    public function producto(int $id): ?array {
        $st = $this->db->prepare("SELECT * FROM productos WHERE id_productos = :id AND negocio_id = :n LIMIT 1");
        $st->execute([':id' => $id, ':n' => $this->negocio['id_negocios']]);
        $r = $st->fetch();
        return $r ?: null;
    }

    private static function minutos(string $hhmmss): int {
        [$h, $m] = array_map('intval', explode(':', $hhmmss));
        return $h * 60 + $m;
    }

    private function nombresDiasAtencion(): string {
        $n = [];
        foreach (explode(',', $this->negocio['dias_atencion']) as $d) {
            $d = (int)$d;
            if ($d >= 1 && $d <= 7) $n[] = self::DIAS[$d];
        }
        return implode(', ', $n);
    }

    /** Devuelve null si el horario es válido, o el motivo en texto. */
    public function validarHorario(DateTime $ini, int $dur, ?int $excluirId = null): ?string {
        $ahora = new DateTime();
        $minimo = (clone $ahora)->modify('+' . (int)$this->negocio['anticipacion_min'] . ' minutes');
        if ($ini < $minimo) {
            return 'Esa hora ya pasó o es muy pronto (se necesita al menos '
                 . (int)$this->negocio['anticipacion_min'] . ' minutos de anticipación).';
        }
        if ($ini > (clone $ahora)->modify("+{$this->maxDias} days")) {
            return "Solo se puede agendar con máximo {$this->maxDias} días de anticipación.";
        }

        $dias = array_map('intval', explode(',', $this->negocio['dias_atencion']));
        if (!in_array((int)$ini->format('N'), $dias, true)) {
            return 'Ese día no hay atención. Días de atención: ' . $this->nombresDiasAtencion() . '.';
        }

        $apertura = self::minutos($this->negocio['hora_apertura']);
        $cierre   = self::minutos($this->negocio['hora_cierre']);
        $inicio   = (int)$ini->format('G') * 60 + (int)$ini->format('i');
        if ($inicio < $apertura || $inicio + $dur > $cierre) {
            return 'Fuera de horario. Se atiende de ' . substr($this->negocio['hora_apertura'], 0, 5)
                 . ' a ' . substr($this->negocio['hora_cierre'], 0, 5)
                 . " y este servicio dura {$dur} min.";
        }
        $paso = max(5, (int)$this->negocio['intervalo_min']);
        if (($inicio - $apertura) % $paso !== 0) {
            return "Las citas se dan cada {$paso} minutos a partir de las "
                 . substr($this->negocio['hora_apertura'], 0, 5) . '.';
        }

        $fin = (clone $ini)->modify("+{$dur} minutes");
        if ($this->contarOcupados($ini, $fin, $excluirId) >= (int)$this->negocio['capacidad_simultanea']) {
            return 'Ese horario ya está ocupado.';
        }
        return null;
    }

    private function contarOcupados(DateTime $ini, DateTime $fin, ?int $excluirId): int {
        $sql = "SELECT COUNT(*) FROM pedidos p
                WHERE p.negocio_id = :n
                  AND p.fecha_entrega IS NOT NULL
                  AND p.estado IN ('pendiente','confirmado')
                  AND p.id_pedidos <> :ex
                  AND p.fecha_entrega < :fin
                  AND DATE_ADD(p.fecha_entrega, INTERVAL COALESCE(
                        (SELECT MAX(COALESCE(pr.duracion_min, :def1))
                           FROM detalles_pedido dp
                           JOIN productos pr ON pr.id_productos = dp.producto_id
                          WHERE dp.pedido_id = p.id_pedidos), :def2) MINUTE) > :ini";
        $st = $this->db->prepare($sql);
        $st->execute([
            ':n'    => $this->negocio['id_negocios'],
            ':ex'   => $excluirId ?? 0,
            ':fin'  => $fin->format('Y-m-d H:i:s'),
            ':ini'  => $ini->format('Y-m-d H:i:s'),
            ':def1' => (int)$this->negocio['duracion_default_min'],
            ':def2' => (int)$this->negocio['duracion_default_min'],
        ]);
        return (int)$st->fetchColumn();
    }

    /** Horas de inicio libres ('HH:MM') para una fecha y duración. */
    public function horariosLibres(DateTime $fecha, int $dur): array {
        $libres   = [];
        $apertura = self::minutos($this->negocio['hora_apertura']);
        $cierre   = self::minutos($this->negocio['hora_cierre']);
        $paso     = max(5, (int)$this->negocio['intervalo_min']);

        for ($t = $apertura; $t + $dur <= $cierre; $t += $paso) {
            $ini = (clone $fecha)->setTime(intdiv($t, 60), $t % 60);
            if ($this->validarHorario($ini, $dur) === null) {
                $libres[] = $ini->format('H:i');
            }
        }
        return $libres;
    }

    public function agendar(int $clienteId, array $prod, int $cant, DateTime $ini, string $tipo, ?string $notas): array {
        $servicio = $this->esServicio($prod);
        $cant     = $servicio ? 1 : max(1, min(100, $cant));
        $dur      = $this->duracion($prod);

        try {
            $this->db->beginTransaction();
            // Serializa las reservas del mismo negocio para evitar dobles citas.
            $this->db->prepare("SELECT id_negocios FROM negocios WHERE id_negocios = :n FOR UPDATE")
                     ->execute([':n' => $this->negocio['id_negocios']]);

            $motivo = $this->validarHorario($ini, $dur);
            if ($motivo !== null) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => $motivo];
            }

            if (!$servicio) {
                $st = $this->db->prepare("UPDATE productos SET stock = stock - :c
                                          WHERE id_productos = :id AND stock >= :c2");
                $st->execute([':c' => $cant, ':c2' => $cant, ':id' => $prod['id_productos']]);
                if ($st->rowCount() === 0) {
                    $this->db->rollBack();
                    return ['ok' => false, 'error' => 'No hay existencias suficientes de ese producto.'];
                }
            }

            $total = round((float)$prod['precio'] * $cant, 2);
            $st = $this->db->prepare("INSERT INTO pedidos
                (negocio_id, cliente_id, total, metodo_pago, tipo_pedido, estado, fecha_entrega, notas)
                VALUES (:n, :c, :t, 'efectivo', :tp, 'pendiente', :f, :no)");
            $st->execute([
                ':n'  => $this->negocio['id_negocios'],
                ':c'  => $clienteId,
                ':t'  => $total,
                ':tp' => $tipo,
                ':f'  => $ini->format('Y-m-d H:i:s'),
                ':no' => $notas !== null ? mb_substr($notas, 0, 255, 'UTF-8') : null,
            ]);
            $pedidoId = (int)$this->db->lastInsertId();

            $this->db->prepare("INSERT INTO detalles_pedido (pedido_id, producto_id, cantidad, precio_unitario)
                                VALUES (:p, :pr, :c, :pu)")
                     ->execute([':p' => $pedidoId, ':pr' => $prod['id_productos'], ':c' => $cant, ':pu' => $prod['precio']]);

            $this->db->commit();
            return [
                'ok'        => true,
                'id_cita'   => $pedidoId,
                'servicio'  => $prod['nombre'],
                'cantidad'  => $cant,
                'total_mxn' => $total,
                'cuando'    => self::fechaBonita($ini),
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            agente_log('Citas::agendar ' . $e->getMessage());
            return ['ok' => false, 'error' => 'Error interno al guardar la cita.'];
        }
    }

    public function misCitas(int $clienteId): array {
        $st = $this->db->prepare("SELECT p.id_pedidos, p.fecha_entrega, p.total, p.estado, p.tipo_pedido,
                    GROUP_CONCAT(CONCAT(dp.cantidad, ' x ', pr.nombre) SEPARATOR ', ') AS detalle
                FROM pedidos p
                LEFT JOIN detalles_pedido dp ON dp.pedido_id = p.id_pedidos
                LEFT JOIN productos pr ON pr.id_productos = dp.producto_id
                WHERE p.negocio_id = :n AND p.cliente_id = :c
                  AND p.fecha_entrega >= :ahora
                  AND p.estado IN ('pendiente','confirmado')
                GROUP BY p.id_pedidos
                ORDER BY p.fecha_entrega ASC
                LIMIT 10");
        $st->execute([
            ':n' => $this->negocio['id_negocios'], ':c' => $clienteId,
            ':ahora' => (new DateTime())->format('Y-m-d H:i:s'),
        ]);
        $out = [];
        foreach ($st->fetchAll() as $r) {
            $out[] = [
                'id_cita'   => (int)$r['id_pedidos'],
                'cuando'    => self::fechaBonita(new DateTime($r['fecha_entrega'])),
                'detalle'   => $r['detalle'],
                'total_mxn' => (float)$r['total'],
                'estado'    => $r['estado'],
            ];
        }
        return $out;
    }

    /** Cita futura, activa y que pertenezca a este cliente y negocio. */
    private function citaPropia(int $clienteId, int $pedidoId, bool $bloquear = false): ?array {
        $st = $this->db->prepare("SELECT * FROM pedidos
                WHERE id_pedidos = :id AND negocio_id = :n AND cliente_id = :c
                  AND fecha_entrega IS NOT NULL AND fecha_entrega >= :ahora
                  AND estado IN ('pendiente','confirmado')" . ($bloquear ? ' FOR UPDATE' : ''));
        $st->execute([
            ':id' => $pedidoId, ':n' => $this->negocio['id_negocios'], ':c' => $clienteId,
            ':ahora' => (new DateTime())->format('Y-m-d H:i:s'),
        ]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public function cancelar(int $clienteId, int $pedidoId): array {
        try {
            $this->db->beginTransaction();
            $ped = $this->citaPropia($clienteId, $pedidoId, true);
            if (!$ped) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => 'No encontré una cita vigente tuya con ese número.'];
            }
            $this->db->prepare("UPDATE pedidos SET estado = 'cancelado' WHERE id_pedidos = :id")
                     ->execute([':id' => $pedidoId]);
            // Regresa existencias solo de productos físicos (los servicios no descuentan stock).
            $this->db->prepare("UPDATE productos pr
                                JOIN detalles_pedido dp ON dp.producto_id = pr.id_productos
                                SET pr.stock = pr.stock + dp.cantidad
                                WHERE dp.pedido_id = :id AND pr.duracion_min IS NULL")
                     ->execute([':id' => $pedidoId]);
            $this->db->commit();
            return ['ok' => true, 'id_cita' => $pedidoId];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            agente_log('Citas::cancelar ' . $e->getMessage());
            return ['ok' => false, 'error' => 'Error interno al cancelar.'];
        }
    }

    public function reprogramar(int $clienteId, int $pedidoId, DateTime $nuevo): array {
        try {
            $this->db->beginTransaction();
            $this->db->prepare("SELECT id_negocios FROM negocios WHERE id_negocios = :n FOR UPDATE")
                     ->execute([':n' => $this->negocio['id_negocios']]);

            $ped = $this->citaPropia($clienteId, $pedidoId, true);
            if (!$ped) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => 'No encontré una cita vigente tuya con ese número.'];
            }
            $st = $this->db->prepare("SELECT MAX(COALESCE(pr.duracion_min, :def)) FROM detalles_pedido dp
                                      JOIN productos pr ON pr.id_productos = dp.producto_id
                                      WHERE dp.pedido_id = :id");
            $st->execute([':def' => (int)$this->negocio['duracion_default_min'], ':id' => $pedidoId]);
            $dur = max(5, (int)($st->fetchColumn() ?: $this->negocio['duracion_default_min']));

            $motivo = $this->validarHorario($nuevo, $dur, $pedidoId);
            if ($motivo !== null) {
                $this->db->rollBack();
                return ['ok' => false, 'error' => $motivo];
            }
            $this->db->prepare("UPDATE pedidos SET fecha_entrega = :f WHERE id_pedidos = :id")
                     ->execute([':f' => $nuevo->format('Y-m-d H:i:s'), ':id' => $pedidoId]);
            $this->db->commit();
            return ['ok' => true, 'id_cita' => $pedidoId, 'cuando' => self::fechaBonita($nuevo)];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            agente_log('Citas::reprogramar ' . $e->getMessage());
            return ['ok' => false, 'error' => 'Error interno al reprogramar.'];
        }
    }
}
